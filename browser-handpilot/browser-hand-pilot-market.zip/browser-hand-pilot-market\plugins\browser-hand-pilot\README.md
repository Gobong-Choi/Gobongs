# 브라우저파일럿 — 다른 컴퓨터 설치 안내

브라우저파일럿은 Claude가 웹 브라우저(크롬, Tor 브라우저)의 탭 화면을 **사진으로만 보고**, 그 탭 안에서만 클릭·입력하게 하는 Claude 플러그인이다.
웹페이지 코드는 읽지 않고, 진짜 마우스·키보드는 움직이지 않아서 사용자는 그동안 다른 창을 그대로 쓸 수 있다.

## 크롬 두 가지
이 안내에서 "크롬"은 두 가지를 구분해서 쓴다.
- **평소 사용하는 크롬**: 사용자가 늘 쓰는 크롬. 북마크와 로그인 정보가 있다.
- **Claude 작업용 크롬**: 평소 크롬과 별도로 실행되는 크롬 창. Claude가 필요할 때 화면 오른쪽 아래에 띄운다. 북마크·로그인이 없고, 첫 탭 제목이 "브라우저파일럿 전용 크롬"이다. 설정은 `사용자 폴더\BrowserHandPilot\chrome-profile` 폴더에 따로 저장된다.

Claude는 기본으로 **Claude 작업용 크롬**에서 일한다. 평소 사용하는 크롬은 사용자가 따로 말했을 때만 쓴다.

## 들어 있는 것
| 이름 | 하는 일 |
|---|---|
| 스킬 `tor-hand` | Claude가 Tor 브라우저를 다루는 순서 |
| 스킬 `chrome-hand` | Claude가 크롬을 다루는 순서(Claude in Chrome이 안 될 때 Claude 작업용 크롬의 시크릿 창에서) |
| 도구 `tor-hand`, `chrome-hand` | Claude가 부르는 사진·클릭·입력 기능 |
| `extension/` | 크롬에 올리는 확장 프로그램(ID 고정: `kheofijbolmhdnfmplopdgkfcfbmkohn`). Claude 작업용 크롬에는 꼭 올리고, 평소 사용하는 크롬에는 로그인된 상태로 일을 시킬 때만 올린다 |
| `tools/setup.js` | 처음 설치(확장 프로그램 복사, 비밀 암호 만들기, Tor 브라우저 위치 찾기) |

## 준비물
- Windows, Claude 데스크톱 앱(Code 탭)
- Node.js 18 이상. 확인: 명령창에서 `node -v`
- 크롬. Tor 브라우저를 쓰려면 Tor Browser(설치 위치는 어디든 됨)

## 설치 순서
1. **사용자가 압축을 푼다**: `browser-hand-pilot-market-<버전>.zip`을 원하는 곳에 푼다. 예) `C:\Tools\browser-hand-pilot-market`
   - 구글 드라이브 동기화 폴더 안은 피한다(설정·암호가 다른 컴퓨터로 넘어갈 수 있음).
2. **사용자가 처음 설치 스크립트를 실행한다**: 명령창(PowerShell)에서 실행한다.
   ```
   node "C:\Tools\browser-hand-pilot-market\plugins\browser-hand-pilot\tools\setup.js"
   ```
   - `사용자 폴더\BrowserHandPilot` 에 크롬 확장 프로그램, 설정 파일(config.json), 비밀 암호가 만들어진다.
   - Tor 브라우저를 못 찾았다고 나오면, 시작 메뉴 '브라우저파일럿 관리' → 설정에서 Tor 브라우저 폴더 안의 `Browser\firefox.exe` 위치를 적는다(Tor 브라우저를 안 쓰면 무시).
3. **사용자가 Claude 플러그인으로 등록한다**: Claude 앱 안의 명령창이 아니라, 앱에 들어 있는 claude.exe로 실행한다
   (일반 설치판 `%APPDATA%\Claude\claude-code\<가장 높은 버전>\...\claude.exe`,
   스토어판 `%LOCALAPPDATA%\Claude-Data\<패키지>\claude-code\<가장 높은 버전>\...\claude.exe`. PATH에 있는 옛 claude는 쓰지 않는다).
   이 단계와 2단계는 **Claude 앱 밖의 PowerShell**에서 실행한다(스토어판은 앱 안에서 실행하면 폴더 위치가 앱 전용 사본으로 바뀜).
   ```
   claude plugin marketplace add "C:\Tools\browser-hand-pilot-market"
   claude plugin install browser-hand-pilot@browser-hand-pilot-market
   ```
4. **Claude 작업용 크롬에 확장 프로그램 올리기(처음 한 번)**
   1. 사용자가 Claude 앱에서 새 채팅을 열고 "크롬으로 구글 열어줘"라고 말한다. 권한 요청 창이 뜨면 허용한다.
   2. Claude가 화면 오른쪽 아래에 Claude 작업용 크롬 창을 띄우고, 그 창에 확장 프로그램 관리 화면(chrome://extensions)을 연다. 평소 사용하는 크롬에는 아무것도 열리지 않는다. 채팅에는 "확장이 연결되지 않았습니다"라는 안내가 나온다.
   3. 사용자가 그 Claude 작업용 크롬 창에서 오른쪽 위 **개발자 모드**를 켜고, **압축해제된 확장 프로그램을 로드합니다**를 눌러 `사용자 폴더\BrowserHandPilot\extension` 폴더를 고른다.
   4. 사용자가 같은 Claude 작업용 크롬 창에서 브라우저파일럿 확장 프로그램 카드의 **세부정보**를 열고 **시크릿 모드에서 허용**을 켠 뒤, 카드의 ID가 `kheofijbolmhdnfmplopdgkfcfbmkohn` 인지 확인한다.
   5. 사용자가 채팅에서 다시 "크롬으로 구글 열어줘"라고 말한다. Claude가 Claude 작업용 크롬에 "BrowserPilot 1" 같은 이름의 탭 그룹(크롬의 탭 묶음)을 만들고 구글 화면 사진을 보여 주면 성공이다.
   - (선택) 평소 사용하는 크롬에 로그인된 상태로도 일을 시키려면, 사용자가 평소 사용하는 크롬에서도 3~4번을 똑같이 한다.

## 쓰는 법
- 이 PC에 Claude in Chrome(Anthropic이 만든 크롬 확장 프로그램)이 있으면, Claude는 크롬 웹 작업을 Claude in Chrome으로 먼저 한다. Claude in Chrome이 연결되지 않았거나 그 사이트에서 막히면, 또는 사용자가 "브라우저파일럿으로", "기록 안 남게"라고 말하면 Claude가 한 줄로 알리고 브라우저파일럿으로 바꾼다. 아래는 브라우저파일럿으로 할 때의 모습이다.
- 사용자가 "크롬으로 구글에서 ○○ 검색해줘"라고 하면, Claude가 Claude 작업용 크롬의 시크릿 창(방문 기록이 남지 않는 창)에서 자기 탭 그룹 안의 탭만 조작한다. Claude 작업용 크롬 창은 다른 창 뒤에 가려져도 된다. 최소화되면 Claude가 원래 크기로 되돌린다.
- 로그인이 필요한 사이트: 사용자가 Claude 작업용 크롬의 일반 창(시크릿 창이 아닌 창)에서 그 사이트에 한 번 직접 로그인해 둔다. 그 뒤 "작업용 크롬의 로그인된 창으로 해줘"라고 하면 Claude가 그 로그인 상태를 쓴다.
- 평소 사용하는 크롬(로그인된 계정 그대로)이 꼭 필요하면 사용자가 "평소 크롬으로 해줘"라고 말한다. Claude가 한 번 확인한 뒤 바꾼다(평소 사용하는 크롬에 확장 프로그램이 있어야 함).
- 사용자가 "Tor 브라우저로 ○○ 찾아줘"라고 하면, Claude가 Tor 브라우저가 꺼져 있을 때 띄우고, 연결 화면이 나오면 Connect를 누른다.
- 크롬은 Claude 채팅 4개까지 동시에 쓸 수 있다(채팅마다 탭 그룹 이름·색이 다름). Tor 브라우저는 한 채팅만.

## 알아 둘 점
- 비밀 암호 파일(`extension\secret.js`)은 컴퓨터마다 따로 만든다. 다른 사람·컴퓨터에 보내지 않는다.
- 한 크롬에 이 확장 프로그램을 두 개 올릴 수 없다(ID가 같아서). 이미 있으면 먼저 삭제한다.
- 확장 프로그램 오류 목록의 `ERR_CONNECTION_REFUSED`는 Claude 채팅이 크롬 기능을 쓰고 있지 않을 때 나는 정상 기록이다.
- 네이버 등 일부 사이트는 Tor 브라우저 접속을 막는다. 그때는 크롬을 쓴다.

## 업데이트
1. 사용자가 새 zip을 같은 곳에 덮어 푼다.
2. 사용자가 `node ...\tools\setup.js` 를 다시 실행한다(설정·암호는 그대로, 확장 프로그램 코드만 바뀜).
3. 사용자가 `claude plugin marketplace update browser-hand-pilot-market` 뒤 `claude plugin update browser-hand-pilot@browser-hand-pilot-market` 를 실행한다.
4. 확장 프로그램은 다음에 Claude가 크롬을 쓸 때 스스로 새 버전을 다시 불러온다(0.8 이상). 0.7 이하에서 올리는 경우에만 사용자가 크롬의 확장 프로그램 카드에서 새로고침(↻)을 누른다.

## 문제가 생기면
| 채팅에 나오는 문구 | 할 일 |
|---|---|
| "전용 크롬에 브라우저파일럿 확장이 연결되지 않았습니다" | 설치 4단계(Claude 작업용 크롬 창에 확장 프로그램 올리기). 이미 했으면 그 창의 확장 프로그램 카드에서 새로고침 |
| "사용자 크롬에 브라우저파일럿 확장이 연결되지 않았습니다" | 평소 사용하는 크롬이 켜져 있는지, 거기에 확장 프로그램이 올라가 있는지 확인 |
| 크롬(chrome.exe)을 찾지 못했다는 문구 | 시작 메뉴 '브라우저파일럿 관리' → 설정의 '크롬 위치'에 chrome.exe 위치를 적는다 |
| "비밀 암호 파일이 없습니다" | 설치 2단계(setup.js) 다시 실행 → 확장 프로그램 새로고침 |
| "시크릿 모드가 허용되지 않았습니다" | 설치 4단계의 4번 |
| "다른 프로그램이 토르 통로를 쓰고 있거나…" | 다른 Claude 채팅이 Tor 브라우저를 쓰는 중인지 확인. 아니면 Tor 브라우저 창을 닫고 다시 |
| "크롬 도구 포트가 모두 사용 중" | 크롬을 쓰는 Claude 채팅을 4개 아래로 줄인다 |
