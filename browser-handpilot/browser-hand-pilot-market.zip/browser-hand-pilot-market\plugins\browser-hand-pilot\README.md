# 브라우저 핸드파일럿 — 다른 컴퓨터 설치 안내

Claude가 토르·크롬 탭을 **사진으로만 보고**, 그 탭 안에서만 클릭·입력하게 하는 플러그인이다.
웹페이지 코드는 읽지 않고, 진짜 마우스·키보드는 움직이지 않아서 다른 창은 그대로 쓸 수 있다.

## 들어 있는 것
| 이름 | 하는 일 |
|---|---|
| 스킬 `tor-hand` | 토르 브라우저 조작 절차 |
| 스킬 `chrome-hand` | 크롬 조작 절차(기본 시크릿 창) |
| 도구 `tor-hand`, `chrome-hand` | Claude가 부르는 사진·클릭·입력 도구 |
| `extension/` | 크롬에 올리는 확장(ID 고정: `kheofijbolmhdnfmplopdgkfcfbmkohn`) |
| `tools/setup.js` | 최초 설치(확장 복사, 비밀 암호 만들기, 토르 찾기) |

## 준비물
- Windows, Claude 데스크톱 앱(Claude Code)
- Node.js 18 이상. 확인: 명령창에서 `node -v`
- 크롬. 토르를 쓰려면 Tor Browser(설치 위치는 어디든 됨)

## 설치 순서
1. **압축 풀기**: `browser-hand-pilot-market-<버전>.zip`을 원하는 곳에 푼다. 예) `C:\Tools\browser-hand-pilot-market`
   - 구글 드라이브 동기화 폴더 안은 피한다(설정·암호가 다른 컴퓨터로 넘어갈 수 있음).
2. **최초 설치 스크립트**: 명령창(PowerShell)에서 실행한다.
   ```
   node "C:\Tools\browser-hand-pilot-market\plugins\browser-hand-pilot\tools\setup.js"
   ```
   - `사용자 폴더\BrowserHandPilot` 에 크롬 확장, 설정(config.json), 비밀 암호가 만들어진다.
   - 토르를 못 찾았다고 나오면 `BrowserHandPilot\config.json` 의 `torExe` 에 토르 폴더의 `Browser\firefox.exe` 경로를 적는다(역슬래시는 `\\` 두 개).
3. **크롬에 확장 올리기**
   1. 크롬 주소창에 `chrome://extensions`
   2. 오른쪽 위 **개발자 모드** 켜기
   3. **압축해제된 확장 프로그램을 로드합니다** → `사용자 폴더\BrowserHandPilot\extension` 선택
   4. 카드의 **세부정보** → **시크릿 모드에서 허용** 켜기
   5. 카드의 ID가 `kheofijbolmhdnfmplopdgkfcfbmkohn` 인지 확인
4. **플러그인 설치**: Claude 앱 안의 명령창이 아니라, 앱에 들어 있는 claude.exe로 실행한다
   (`%APPDATA%\Claude\claude-code\<가장 높은 버전>\...\claude.exe`. PATH의 옛 claude는 쓰지 않는다).
   ```
   claude plugin marketplace add "C:\Tools\browser-hand-pilot-market"
   claude plugin install browser-hand-pilot@browser-hand-pilot-market
   ```
5. **확인**: Claude 앱에서 새 채팅을 열고 "크롬 탭 목록 보여줘"라고 한다.
   - 도구 허용 창이 뜨면 허용한다.
   - 결과 첫 줄에 `이 채팅의 탭 그룹: Hand-pilot N` 이 나오면 성공.

## 쓰는 법
- "크롬으로 구글에서 ○○ 검색해줘" → 시크릿 창에 "Hand-pilot N" 탭 그룹이 생기고 그 안에서만 조작한다.
- 로그인된 일반 크롬이 필요하면 "일반 크롬으로 해줘"라고 말한다. Claude가 한 번 확인한 뒤 바꾼다.
- "토르로 ○○ 찾아줘" → 토르가 꺼져 있으면 띄우고, 연결 화면이 나오면 Connect를 누른다.
- 크롬은 채팅 4개까지 동시에 쓸 수 있다(채팅마다 그룹·색이 다름). 토르는 한 채팅만.

## 알아 둘 점
- 비밀 암호(`extension\secret.js`)는 컴퓨터마다 따로 만든다. 다른 사람·컴퓨터에 보내지 않는다.
- 한 크롬에 이 확장을 두 벌 올릴 수 없다(ID가 같아서). 이미 있으면 먼저 삭제한다.
- 확장 오류 목록의 `ERR_CONNECTION_REFUSED`는 Claude 도구가 꺼져 있을 때 나는 정상 기록이다.
- 네이버 등 일부 사이트는 토르 접속을 막는다. 그때는 크롬을 쓴다.

## 업데이트
1. 새 zip을 같은 곳에 덮어 푼다.
2. `node ...\tools\setup.js` 를 다시 실행한다(설정·암호는 그대로, 확장 코드만 바뀜).
3. `claude plugin marketplace update browser-hand-pilot-market` 뒤 `claude plugin update browser-hand-pilot@browser-hand-pilot-market`
4. 크롬 확장 카드의 새로고침(↻)을 누른다.

## 문제가 생기면
| 증상 | 할 일 |
|---|---|
| "크롬 확장프로그램이 연결되지 않았습니다" | 크롬이 켜져 있는지, 확장이 켜져 있는지, 확장 새로고침 |
| "비밀 암호 파일이 없습니다" | 설치 2단계(setup.js) 다시 실행 → 확장 새로고침 |
| "시크릿 모드가 허용되지 않았습니다" | 설치 3-4단계 |
| "다른 프로그램이 토르 통로를 쓰고 있거나…" | 다른 채팅이 토르를 쓰는 중인지 확인, 아니면 토르 창을 닫고 다시 |
| "크롬 도구 포트가 모두 사용 중" | 크롬 도구를 쓰는 채팅을 4개 아래로 줄이기 |
