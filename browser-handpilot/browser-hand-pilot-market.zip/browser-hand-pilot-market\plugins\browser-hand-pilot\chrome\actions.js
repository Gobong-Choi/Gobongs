// 손(크롬): 확장프로그램에 명령을 보내 탭 목록, 탭 사진, 그 탭 안에서만 클릭·입력·키·스크롤을 한다.
// 토르판(tor/actions.js)과 같은 모양의 함수를 둔다. 좌표는 CSS 픽셀이다(사진 좌표 환산은 common/eyes.js).
// role: "dedicated" = Claude 전용 크롬(기본), "user" = 사용자 크롬(로그인 필요할 때만).
// 두 크롬의 탭 번호가 겹칠 수 있어, 사용자 크롬 탭은 Claude에게 앞에 u를 붙여 보여 준다(예: u123).
import { config } from "../tor/config.js";

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const stripPrefix = (dataUrl) => dataUrl.replace(/^data:image\/png;base64,/, "");

export class ChromeHand {
  constructor(link, role) {
    this.link = link;
    this.role = role;
    this.prefix = role === "user" ? "u" : "";
  }

  get connected() {
    return this.link.isConnected(this.role);
  }

  send(type, params = {}) {
    return this.link.send(type, params, this.role);
  }

  id(tab) {
    return Number(String(tab).replace(/^u/, ""));
  }

  async tabs() {
    return (await this.send("tabs")).map((t) => ({ ...t, id: this.prefix + t.id }));
  }

  // mode: "private"(전용 크롬 시크릿 창) | "saved"(전용 크롬 일반 창, 로그인 유지) | "user"(사용자 크롬)
  async newTab(url, mode) {
    const win = { width: config.chromeWindowWidth, height: config.chromeWindowHeight };
    return this.prefix + (await this.send("newTab", { url, mode, win }));
  }

  async navigate(tab, url) {
    await this.send("navigate", { tabId: this.id(tab), url });
  }

  async url(tab) {
    return this.send("tabUrl", { tabId: this.id(tab) });
  }

  // 페이지가 로딩 중인지(눈이 화면 멈춤 판정 때 본다)
  async isLoading(tab) {
    return (await this.send("tabStatus", { tabId: this.id(tab) })) === "loading";
  }

  async screenshot(tab) {
    return stripPrefix(await this.send("capture", { tabId: this.id(tab) }));
  }

  // 기기 픽셀 ÷ CSS 픽셀: 사진 폭과 화면 폭(CSS 픽셀)을 비교한다. 확대 비율을 바꾸면 이 값도 바뀐다.
  async devScale(tab, rawWidth) {
    const width = await this.send("viewportWidth", { tabId: this.id(tab) });
    return rawWidth / width || 1;
  }

  async click(tab, x, y, { button = "left", double = false } = {}) {
    await this.send("click", { tabId: this.id(tab), x, y, button, double });
    await sleep(config.settleMs);
  }

  async move(tab, x, y) {
    await this.send("move", { tabId: this.id(tab), x, y });
    await sleep(config.settleMs);
  }

  async type(tab, text) {
    await this.send("type", { tabId: this.id(tab), text });
    await sleep(config.settleMs);
  }

  async key(tab, combo) {
    await this.send("key", { tabId: this.id(tab), combo });
    await sleep(config.settleMs);
  }

  async scroll(tab, x, y, dy) {
    await this.send("scroll", { tabId: this.id(tab), x, y, dy });
    await sleep(config.settleMs);
  }
}
