// 눈과 손(크롬): 확장프로그램에 명령을 보내 탭 목록, 탭 사진, 그 탭 안에서만 클릭·입력·키·스크롤을 한다.
// 토르판(tor/actions.js)과 같은 모양의 함수를 둔다. 좌표는 사진 픽셀 기준이다.
import { config } from "../tor/config.js";
import { ExtensionLink } from "./wsserver.js";

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const stripPrefix = (dataUrl) => dataUrl.replace(/^data:image\/png;base64,/, "");
const id = (tab) => Number(tab);

export class ChromeHand {
  constructor() {
    this.link = new ExtensionLink(config.chromePort, config.chromePortCount, config.chromeExtensionId);
  }

  get connected() {
    return this.link.connected;
  }

  async close() {
    this.link.close();
  }

  async tabs() {
    return this.link.send("tabs");
  }

  // incognito가 true면 시크릿 창 안에 연다(확장의 '시크릿 모드에서 허용'이 켜져 있어야 함).
  async newTab(url, incognito = false) {
    return this.link.send("newTab", { url, incognito });
  }

  async navigate(tab, url) {
    await this.link.send("navigate", { tabId: id(tab), url });
  }

  async screenshot(tab) {
    return stripPrefix(await this.link.send("capture", { tabId: id(tab) }));
  }

  // 사진 픽셀 ÷ 입력 좌표 배율: 사진 폭과 화면 폭(CSS 픽셀)을 비교한다.
  async scale(tab) {
    const png = Buffer.from(await this.screenshot(tab), "base64");
    const width = await this.link.send("viewportWidth", { tabId: id(tab) });
    return png.readUInt32BE(16) / width || 1;
  }

  async stableScreenshot(tab) {
    const deadline = Date.now() + config.stableTimeoutMs;
    let prev = await this.screenshot(tab);
    while (Date.now() < deadline) {
      await sleep(config.stableIntervalMs);
      const next = await this.screenshot(tab);
      if (next === prev) return next;
      prev = next;
    }
    return prev;
  }

  async click(tab, x, y, { button = "left", double = false } = {}) {
    const s = await this.scale(tab);
    await this.link.send("click", { tabId: id(tab), x: x / s, y: y / s, button, double });
    await sleep(config.settleMs + config.clickSettleMs);
  }

  async move(tab, x, y) {
    const s = await this.scale(tab);
    await this.link.send("move", { tabId: id(tab), x: x / s, y: y / s });
    await sleep(config.settleMs);
  }

  async type(tab, text) {
    await this.link.send("type", { tabId: id(tab), text });
    await sleep(config.settleMs);
  }

  async key(tab, combo) {
    await this.link.send("key", { tabId: id(tab), combo });
    await sleep(config.settleMs);
    // Enter는 새 페이지를 여는 일이 많아 링크 클릭처럼 더 기다린다.
    if (/(^|\+)\s*enter\s*$/i.test(combo)) await sleep(config.clickSettleMs);
  }

  async scroll(tab, x, y, dy) {
    const s = await this.scale(tab);
    await this.link.send("scroll", { tabId: id(tab), x: x / s, y: y / s, dy: dy / s });
    await sleep(config.settleMs);
  }
}
