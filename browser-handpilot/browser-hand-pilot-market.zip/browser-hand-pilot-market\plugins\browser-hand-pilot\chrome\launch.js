// 전용 크롬 띄우기: Claude 전용 프로필(설정 chromeProfileDir, 기본 설치 폴더\chrome-profile)로
// 사용자 크롬과 따로 도는 크롬을 띄운다. 조작은 그 안에 올린 브라우저파일럿 확장이 한다.
// - 다른 창에 가려져도 계속 그리도록 크롬 설정을 켜서 띄운다(2026-10-27 시험: 가려져도 사진 0.07초, 화면 정상 속도).
// - 크롬을 직접 조종하는 통로 옵션(--remote-debugging-*)은 쓰지 않는다. 쓰면 웹사이트에 '자동화된 브라우저' 표시가 생겨
//   구글 등이 로봇 확인을 띄운다(2026-10-27 시험). 확장 방식은 이 표시가 없다.
// - 첫 창에 '전용 크롬 확인 페이지'를 연다. 확장이 그 주소의 암호를 확인하고 "나는 전용 크롬 쪽"이라고 기억한다.
import { spawn, execFileSync } from "node:child_process";
import { existsSync, mkdirSync } from "node:fs";
import { join } from "node:path";
import { config, homeDir } from "../tor/config.js";
import { log } from "../common/log.js";

const FLAGS = [
  "--disable-backgrounding-occluded-windows",
  "--disable-renderer-backgrounding",
  "--disable-background-timer-throttling",
  "--disable-features=CalculateNativeWinOcclusion",
  "--no-first-run",
  "--no-default-browser-check",
];

export const profileDir = () => config.chromeProfileDir || join(homeDir, "chrome-profile");

function findChrome() {
  const candidates = [
    config.chromeExe,
    join(process.env.ProgramFiles || "C:\\Program Files", "Google\\Chrome\\Application\\chrome.exe"),
    join(process.env["ProgramFiles(x86)"] || "C:\\Program Files (x86)", "Google\\Chrome\\Application\\chrome.exe"),
    join(process.env.LOCALAPPDATA || "", "Google\\Chrome\\Application\\chrome.exe"),
  ].filter(Boolean);
  const exe = candidates.find((p) => existsSync(p));
  if (!exe) throw new Error("크롬(chrome.exe)을 찾지 못했습니다. 관리 페이지 설정의 '크롬 위치'에 chrome.exe 전체 경로를 넣으세요.");
  return exe;
}

// 주 모니터의 작업 영역(작업 표시줄 뺀 곳). 크롬 창 위치와 같은 단위(배율 적용 뒤 좌표)로 받는다.
function workArea() {
  try {
    const out = execFileSync("powershell", ["-NoProfile", "-Command",
      "Add-Type -AssemblyName System.Windows.Forms; $a=[System.Windows.Forms.Screen]::PrimaryScreen.WorkingArea; \"$($a.X),$($a.Y),$($a.Width),$($a.Height)\""],
      { windowsHide: true, timeout: 10000 }).toString().trim();
    const [left, top, width, height] = out.split(",").map(Number);
    if (width > 0 && height > 0) return { left, top, width, height };
  } catch {}
  return null;
}

// 전용 크롬을 띄운다. 이미 떠 있으면 크롬이 같은 프로필 창에 주소만 연다(새 프로그램은 안 뜸).
export function openDedicated(urls) {
  const profile = profileDir();
  mkdirSync(profile, { recursive: true });
  const args = [...FLAGS, `--user-data-dir=${profile}`];
  const a = workArea();
  if (a) {
    const width = Math.min(config.chromeWindowWidth, a.width);
    const height = Math.min(config.chromeWindowHeight, a.height);
    args.push(`--window-position=${a.left + a.width - width},${a.top + a.height - height}`, `--window-size=${width},${height}`);
  }
  const child = spawn(findChrome(), [...args, ...urls], { detached: true, stdio: "ignore" });
  child.unref();
  log("info", `전용 크롬 열기: ${urls.map((u) => u.replace(/#.*/, "#…")).join(" ")}`);
}
