// 연결 창구: 크롬 확장프로그램이 붙는 작은 웹소켓 서버(127.0.0.1만). 외부 패키지 없이 직접 구현한다.
// 채팅마다 이 서버가 하나씩 뜨므로, 시작 포트부터 비어 있는 포트를 골라 연다(확장은 모든 포트에 붙는다).
// 보안: (1) 보낸 곳(Origin)이 우리 확장이 아니면 접속을 거절한다(웹페이지는 Origin을 속일 수 없다).
//       (2) 비밀 암호(extension/secret.js)로 서로 확인한 뒤에만 명령을 보낸다. 암호 자체는 오가지 않는다(HMAC).
//           확장 → hello{nonce}, 서버 → welcome{proof(nonce), nonce2}, 확장 → auth{proof(nonce2)}
import { createServer } from "node:http";
import { createHash, createHmac, randomBytes, timingSafeEqual } from "node:crypto";
import { readFileSync } from "node:fs";
import { secretPath } from "../tor/config.js";

const GUID = "258EAFA5-E914-47DA-95CA-C5AB0DC85B11";
const AUTH_TIMEOUT_MS = 5000;

function loadSecret() {
  let text;
  try {
    text = readFileSync(secretPath, "utf8");
  } catch {
    throw new Error(`비밀 암호 파일이 없습니다(${secretPath}). 설치 안내서의 암호 만들기 단계를 실행한 뒤 크롬에서 확장을 새로고침하세요.`);
  }
  return text.match(/SECRET = "([0-9a-f]+)"/)[1];
}

const proof = (secret, nonce) => createHmac("sha256", secret).update(nonce).digest("hex");
const sameHex = (a, b) =>
  typeof a === "string" && a.length === b.length && timingSafeEqual(Buffer.from(a), Buffer.from(b));

function encodeFrame(text) {
  const payload = Buffer.from(text, "utf8");
  const len = payload.length;
  let header;
  if (len < 126) header = Buffer.from([0x81, len]);
  else if (len < 65536) {
    header = Buffer.alloc(4);
    header[0] = 0x81; header[1] = 126; header.writeUInt16BE(len, 2);
  } else {
    header = Buffer.alloc(10);
    header[0] = 0x81; header[1] = 127; header.writeBigUInt64BE(BigInt(len), 2);
  }
  return Buffer.concat([header, payload]);
}

// 연결 하나: 받은 바이트를 글 단위 메시지로 풀어 onText에 넘긴다.
class Conn {
  constructor(socket, onText, onClose) {
    this.socket = socket;
    this.buffer = Buffer.alloc(0);
    this.fragments = [];
    socket.on("data", (chunk) => this.onData(chunk, onText));
    socket.on("close", onClose);
    socket.on("error", () => {});
  }

  onData(chunk, onText) {
    this.buffer = Buffer.concat([this.buffer, chunk]);
    for (;;) {
      const b = this.buffer;
      if (b.length < 2) return;
      const fin = b[0] & 0x80, opcode = b[0] & 0x0f, masked = b[1] & 0x80;
      let len = b[1] & 0x7f, off = 2;
      if (len === 126) { if (b.length < 4) return; len = b.readUInt16BE(2); off = 4; }
      else if (len === 127) { if (b.length < 10) return; len = Number(b.readBigUInt64BE(2)); off = 10; }
      const maskOff = off; if (masked) off += 4;
      if (b.length < off + len) return;
      const payload = Buffer.from(b.subarray(off, off + len));
      if (masked) for (let i = 0; i < len; i++) payload[i] ^= b[maskOff + (i % 4)];
      this.buffer = b.subarray(off + len);

      if (opcode === 0x8) { this.socket.end(); return; }                            // 닫기
      if (opcode === 0x9) { this.socket.write(Buffer.from([0x8a, 0])); continue; }  // ping → pong
      if (opcode === 0x1 || opcode === 0x0) {
        this.fragments.push(payload);
        if (fin) {
          const text = Buffer.concat(this.fragments).toString("utf8");
          this.fragments = [];
          onText(text);
        }
      }
    }
  }

  send(obj) {
    this.socket.write(encodeFrame(JSON.stringify(obj)));
  }

  close() {
    this.socket.destroy();
  }
}

export class ExtensionLink {
  constructor(portStart, portCount, extensionId) {
    this.portStart = portStart;
    this.portCount = portCount;
    this.origin = `chrome-extension://${extensionId}`;
    this.secret = loadSecret();
    this.port = null;
    this.conn = null; // 암호 확인을 마친 연결
    this.nextId = 0;
    this.pending = new Map();
  }

  async start() {
    for (let port = this.portStart; port < this.portStart + this.portCount; port++) {
      try {
        await this.listen(port);
        this.port = port;
        return;
      } catch (err) {
        if (err.code !== "EADDRINUSE") throw err;
      }
    }
    throw new Error(`크롬 도구 포트(${this.portStart}~${this.portStart + this.portCount - 1})가 모두 사용 중입니다. 크롬 도구를 쓰는 채팅을 줄이세요.`);
  }

  listen(port) {
    return new Promise((resolve, reject) => {
      const server = createServer((_req, res) => { res.writeHead(426); res.end(); });
      server.on("upgrade", (req, socket) => this.accept(req, socket));
      server.once("error", reject);
      server.listen(port, "127.0.0.1", () => {
        this.server = server;
        resolve();
      });
    });
  }

  // 몇 번째 채팅인지(확장의 탭 그룹 "Hand-pilot N"의 N)
  get slotNumber() {
    return this.port - this.portStart + 1;
  }

  accept(req, socket) {
    const key = req.headers["sec-websocket-key"];
    if (!key || req.headers.origin !== this.origin) {
      socket.end("HTTP/1.1 403 Forbidden\r\n\r\n");
      return;
    }
    const acceptKey = createHash("sha1").update(key + GUID).digest("base64");
    socket.write(
      "HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\n" +
      `Sec-WebSocket-Accept: ${acceptKey}\r\n\r\n`
    );

    // 새 연결은 암호 확인을 마칠 때까지 믿지 않는다. 이미 확인된 연결은 그때까지 그대로 둔다.
    let serverNonce = null;
    let trusted = false;
    const timer = setTimeout(() => { if (!trusted) conn.close(); }, AUTH_TIMEOUT_MS);
    const conn = new Conn(
      socket,
      (text) => {
        let msg;
        try { msg = JSON.parse(text); } catch { return conn.close(); }
        if (trusted) return this.onMessage(msg);
        if (msg.type === "hello" && typeof msg.nonce === "string" && !serverNonce) {
          serverNonce = randomBytes(16).toString("hex");
          conn.send({ type: "welcome", proof: proof(this.secret, msg.nonce), nonce: serverNonce });
        } else if (msg.type === "auth" && serverNonce && sameHex(msg.proof, proof(this.secret, serverNonce))) {
          trusted = true;
          clearTimeout(timer);
          if (this.conn) this.conn.close();
          this.conn = conn;
        } else {
          conn.close(); // 순서가 틀리거나 암호가 틀리면 끊는다
        }
      },
      () => {
        clearTimeout(timer);
        if (this.conn === conn) this.dropAll("확장프로그램 연결이 끊겼습니다");
      }
    );
  }

  onMessage(msg) {
    if (msg.id === undefined) return; // keepalive 등
    const waiter = this.pending.get(msg.id);
    if (!waiter) return;
    this.pending.delete(msg.id);
    if (msg.ok) waiter.resolve(msg.value);
    else waiter.reject(new Error(msg.error));
  }

  dropAll(reason) {
    this.conn = null;
    for (const w of this.pending.values()) w.reject(new Error(reason));
    this.pending.clear();
  }

  get connected() {
    return this.conn !== null;
  }

  // 확장프로그램이 붙을 때까지 잠깐 기다린다.
  async waitConnected(timeoutMs) {
    const deadline = Date.now() + timeoutMs;
    while (!this.connected && Date.now() < deadline) await new Promise((r) => setTimeout(r, 200));
    if (!this.connected) {
      throw new Error("크롬 확장프로그램이 연결되지 않았습니다. 크롬이 켜져 있고 Browser Hand-pilot 확장이 켜져 있는지 확인하세요.");
    }
  }

  send(type, params = {}) {
    if (!this.conn) return Promise.reject(new Error("크롬 확장프로그램이 연결되어 있지 않습니다"));
    const id = ++this.nextId;
    return new Promise((resolve, reject) => {
      this.pending.set(id, { resolve, reject });
      this.conn.send({ id, type, ...params });
    });
  }

  close() {
    if (this.conn) this.conn.close();
    if (this.server) this.server.close();
  }
}
