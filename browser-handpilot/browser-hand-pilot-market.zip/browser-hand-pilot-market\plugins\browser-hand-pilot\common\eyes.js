// 눈: 탭 사진을 줄여 보내고, 동작 뒤에는 화면이 멈출 때까지 기다렸다가 바뀐 부분만 잘라 보낸다.
// 핸드파일럿(데스크톱판)의 검증된 기준을 따른다(2026-10-26 상담):
//   16px 칸·2px 샘플·RGB 차이 24 초과면 바뀐 칸, 512px²(칸 2개) 미만 덩어리는 무시, 여백 24px, 최대 3장,
//   바뀐 넓이 50% 이상·잘린 결과 5번마다·문서 이동·화면 크기 변화 때는 전체 사진.
// 좌표는 모두 '탭 사진'(긴 변 maxImage px로 줄인 이미지) 기준이다. 손에는 CSS 픽셀로 바꿔 넘긴다.
import { decodePng, encodePng, resizeBox, crop, fitSize } from "./png.js";
import { config } from "../tor/config.js";
import { log } from "./log.js";
import { checkStop } from "./stopkey.js";

const CELL = 16, SAMPLE = 2, THRESH = 24, MIN_CELLS = 2, MARGIN = 24, MAX_CROPS = 3, TINY = 2;
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

export class Eyes {
  constructor(hand, label) {
    this.hand = hand;
    this.label = label; // 예: "크롬 탭"
    this.tabs = new Map(); // 탭 id → 상태
  }

  state(tab) {
    if (!this.tabs.has(tab)) this.tabs.set(tab, { base: null, crops: 0, ignore: new Map(), observedLast: true, view: null, url: null });
    return this.tabs.get(tab);
  }

  forget(tab) {
    const st = this.state(tab);
    st.base = null;
    st.last = null;
    st.crops = 0;
    st.ignore.clear();
  }

  // 사진 한 장: 원본(기기 픽셀) → 긴 변 maxImage로 줄인 이미지 + 좌표 환산 정보
  async capture(tab) {
    const raw = decodePng(Buffer.from(await this.hand.screenshot(tab), "base64"));
    const dev = await this.hand.devScale(tab, raw.width); // 기기 픽셀 ÷ CSS 픽셀
    const size = fitSize(raw.width, raw.height, config.maxImage);
    const img = resizeBox(raw, size.width, size.height);
    const r = img.width / raw.width; // 사진 픽셀 ÷ 기기 픽셀
    return { raw, img, r, dev, view: `${Math.round(raw.width / dev)}x${Math.round(raw.height / dev)}@${dev.toFixed(3)}` };
  }

  // 사진 좌표 → 손이 쓰는 CSS 좌표
  toCss(frame, x, y) {
    return { x: x / frame.r / frame.dev, y: y / frame.r / frame.dev };
  }

  // 바뀐 칸 번호 집합
  diffCells(a, b) {
    const cols = Math.ceil(a.width / CELL), rows = Math.ceil(a.height / CELL);
    const changed = new Set();
    if (a.width !== b.width || a.height !== b.height) {
      for (let i = 0; i < cols * rows; i++) changed.add(i);
      return changed;
    }
    for (let cy = 0; cy < rows; cy++) {
      for (let cx = 0; cx < cols; cx++) {
        let hit = false;
        for (let y = cy * CELL; y < Math.min((cy + 1) * CELL, a.height) && !hit; y += SAMPLE) {
          for (let x = cx * CELL; x < Math.min((cx + 1) * CELL, a.width); x += SAMPLE) {
            const o = (y * a.width + x) * 4;
            if (Math.abs(a.data[o] - b.data[o]) > THRESH || Math.abs(a.data[o + 1] - b.data[o + 1]) > THRESH ||
                Math.abs(a.data[o + 2] - b.data[o + 2]) > THRESH) { hit = true; break; }
          }
        }
        if (hit) changed.add(cy * cols + cx);
      }
    }
    return changed;
  }

  // 화면이 멈출 때까지 기다린 마지막 사진. 계속 바뀐 칸은 60초 동안 무시 목록에 올린다.
  async settle(tab, first) {
    const st = this.state(tab);
    const start = Date.now();
    let prev = first, lastChange = null, frame = first;
    const busy = new Set();
    for (;;) {
      await sleep(config.settleIntervalMs);
      checkStop();
      frame = await this.capture(tab);
      const d = this.diffCells(prev.img, frame.img);
      const elapsed = Date.now() - start;
      // 입력 커서 깜빡임처럼 칸 2개 이하의 변화는 '멈춤' 판정에서 무시한다(사진 한 장이 0.3초쯤 걸려 깜빡임 사이를 못 잡음)
      if (d.size > TINY) { lastChange = Date.now(); d.forEach((c) => busy.add(c)); } else busy.clear();
      prev = frame;
      // 페이지가 아직 로딩 중이면 멈춘 것으로 보지 않는다(빈 화면을 찍고 끝내지 않게)
      if (elapsed < config.loadWaitMs && (await this.hand.isLoading?.(tab))) { lastChange = Date.now(); continue; }
      if (lastChange === null && elapsed >= config.noChangeMs) break;
      if (lastChange !== null && Date.now() - lastChange >= config.stableMs) break;
      if (elapsed >= config.settleMaxMs) {
        const until = Date.now() + 60000;
        busy.forEach((c) => st.ignore.set(c, until));
        break;
      }
    }
    return { frame, waited: (Date.now() - start) / 1000 };
  }

  activeIgnore(st) {
    const now = Date.now(), set = new Set();
    for (const [c, until] of st.ignore) { if (until > now) set.add(c); else st.ignore.delete(c); }
    return set;
  }

  // 바뀐 칸 → 잘라 보낼 상자(사진 좌표)
  boxes(cells, img) {
    const cols = Math.ceil(img.width / CELL);
    const seen = new Set(), boxes = [];
    for (const start of cells) {
      if (seen.has(start)) continue;
      const stack = [start];
      seen.add(start);
      let n = 0, x0 = Infinity, y0 = Infinity, x1 = -1, y1 = -1;
      while (stack.length) {
        const c = stack.pop();
        n++;
        const cx = c % cols, cy = Math.floor(c / cols);
        x0 = Math.min(x0, cx); y0 = Math.min(y0, cy); x1 = Math.max(x1, cx); y1 = Math.max(y1, cy);
        for (const [dx, dy] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
          const nx = cx + dx, ny = cy + dy, nc = ny * cols + nx;
          if (nx >= 0 && nx < cols && ny >= 0 && cells.has(nc) && !seen.has(nc)) { seen.add(nc); stack.push(nc); }
        }
      }
      if (n < MIN_CELLS) continue;
      boxes.push({
        x0: Math.max(0, x0 * CELL - MARGIN), y0: Math.max(0, y0 * CELL - MARGIN),
        x1: Math.min(img.width, (x1 + 1) * CELL + MARGIN), y1: Math.min(img.height, (y1 + 1) * CELL + MARGIN),
      });
    }
    const area = (b) => (b.x1 - b.x0) * (b.y1 - b.y0);
    const union = (a, b) => ({ x0: Math.min(a.x0, b.x0), y0: Math.min(a.y0, b.y0), x1: Math.max(a.x1, b.x1), y1: Math.max(a.y1, b.y1) });
    // 합쳐도 빈 공간이 30% 이하이거나 겹치면 합친다. 그래도 3장이 넘으면 가장 싸게 합쳐지는 쌍부터 합친다.
    for (let merged = true; merged;) {
      merged = false;
      outer: for (let i = 0; i < boxes.length; i++) {
        for (let j = i + 1; j < boxes.length; j++) {
          const u = union(boxes[i], boxes[j]);
          if ((area(boxes[i]) + area(boxes[j])) / area(u) >= 0.7) {
            boxes.splice(j, 1); boxes[i] = u; merged = true; break outer;
          }
        }
      }
    }
    while (boxes.length > MAX_CROPS) {
      let best = null;
      for (let i = 0; i < boxes.length; i++) for (let j = i + 1; j < boxes.length; j++) {
        const cost = area(union(boxes[i], boxes[j])) - area(boxes[i]) - area(boxes[j]);
        if (!best || cost < best.cost) best = { i, j, cost };
      }
      boxes[best.i] = union(boxes[best.i], boxes[best.j]);
      boxes.splice(best.j, 1);
    }
    return boxes;
  }

  full(tab, frame, head) {
    const st = this.state(tab);
    st.base = frame.img;
    st.crops = 0;
    st.view = frame.view;
    const { width, height } = frame.img;
    return [
      { type: "text", text: `${head}\n전체 ${this.label} ${tab} 사진 ${width}x${height}. 좌표는 이 이미지 기준입니다.` },
      { type: "image", data: encodePng(frame.img).toString("base64"), mimeType: "image/png" },
    ];
  }

  // 기준 화면과 비교해 결과를 만든다. forceFull이면 전체.
  report(tab, frame, head, waited, forceFull) {
    const st = this.state(tab);
    const wait = waited != null ? `, 대기 ${waited.toFixed(1)}초` : "";
    if (forceFull || !st.base || st.view !== frame.view || st.crops >= config.fullEvery) {
      return this.full(tab, frame, `${head}${wait ? ` (${wait.slice(2)})` : ""}`);
    }
    const ignore = this.activeIgnore(st);
    const raw = this.diffCells(st.base, frame.img);
    const cells = new Set([...raw].filter((c) => !ignore.has(c)));
    const boxes = this.boxes(cells, frame.img);
    log("debug", `비교 ${tab}: 바뀐 칸 ${raw.size}, 무시 ${ignore.size}, 남은 칸 ${cells.size}, 상자 ${boxes.length}`);
    if (!boxes.length) {
      return [{ type: "text", text: `${head}\n변화 없음 (${wait.slice(2) || "확인"}). ${this.label} ${tab} 화면이 이전에 본 그대로입니다.` }];
    }
    const total = boxes.reduce((s, b) => s + (b.x1 - b.x0) * (b.y1 - b.y0), 0);
    if (total >= frame.img.width * frame.img.height * 0.5) return this.full(tab, frame, `${head} (화면 대부분 바뀜${wait})`);
    st.crops++;
    const out = [], parts = [];
    boxes.forEach((b, i) => {
      const piece = crop(frame.img, b.x0, b.y0, b.x1 - b.x0, b.y1 - b.y0);
      // 기준 화면에 그 부분만 덮어쓴다
      for (let row = 0; row < piece.height; row++) {
        st.base.data.set(piece.data.subarray(row * piece.width * 4, (row + 1) * piece.width * 4), ((b.y0 + row) * st.base.width + b.x0) * 4);
      }
      parts.push(`이미지 ${i + 1}: 사진 좌표 x=${b.x0}~${b.x1}, y=${b.y0}~${b.y1} (시작점 ${b.x0},${b.y0})`);
      out.push({ type: "image", data: encodePng(piece).toString("base64"), mimeType: "image/png" });
    });
    const text = `${head}\n화면 일부만 바뀜 (${boxes.length}곳 → 이미지 ${boxes.length}장${wait}). ${parts.join(" / ")}. ` +
      `각 이미지의 픽셀 (px, py)는 ${this.label} ${tab} 사진 좌표 (시작점x+px, 시작점y+py)입니다. 나머지 화면은 이전에 본 그대로입니다.`;
    return [{ type: "text", text }, ...out];
  }

  // 동작 하나: 직전 사진 → (화면 크기 확인) → 동작 → 멈출 때까지 대기 → 결과
  async act(tab, head, { observe = true, coords = false }, fn) {
    const st = this.state(tab);
    const pre = await this.capture(tab);
    if (coords && st.view && st.view !== pre.view) {
      this.forget(tab);
      log("warn", `화면 크기 바뀜(${st.view} → ${pre.view}), 동작 취소`);
      return this.full(tab, pre, `⚠ 화면 크기가 바뀌어(${st.view} → ${pre.view}) 동작하지 않았습니다. 이 새 사진으로 좌표를 다시 정하세요.`);
    }
    // 직전 동작이 끝난 뒤 내가 건드리지 않았는데 바뀐 칸(시계·광고·커서)은 무시 목록으로 배운다.
    // 비교 대상은 직전 동작의 마지막 사진(st.last). 기준 화면(st.base)과 비교하면 직전 동작이 남긴 변화까지 무시하게 된다.
    // 작은 변화(ignoreMaxCells 칸 이하)만 배운다. 넓게 바뀌었으면(늦게 뜬 페이지 등) 기준을 비워 이번 결과를 전체로 보낸다.
    // 직전에 관찰을 건너뛰었다면 내 동작 탓일 수 있어 배우지 않는다.
    let stale = false;
    if (st.last && st.view === pre.view) {
      const d = this.diffCells(st.last, pre.img);
      const cellsTotal = Math.ceil(pre.img.width / CELL) * Math.ceil(pre.img.height / CELL);
      if (d.size > cellsTotal * config.ignoreMaxShare) { this.forget(tab); stale = true; }
      else if (st.observedLast && d.size <= config.ignoreMaxCells) {
        const until = Date.now() + 60000;
        d.forEach((c) => st.ignore.set(c, until));
      }
    }
    const urlBefore = await this.hand.url?.(tab);
    checkStop();
    await fn(pre);
    st.observedLast = observe;
    if (!observe) st.last = null;
    if (!observe) return [{ type: "text", text: `${head} (관찰 안 함: 사진 없이 동작만 했습니다)` }];
    const { frame, waited } = await this.settle(tab, pre);
    st.last = frame.img;
    const urlAfter = await this.hand.url?.(tab);
    const moved = urlBefore !== urlAfter;
    if (moved) this.forget(tab);
    const note = moved ? " (새 페이지로 이동함)" : stale ? " (동작 전에 화면이 크게 바뀌어 있었음)" : "";
    return this.report(tab, frame, head + note, waited, moved || stale);
  }

  async look(tab, mode) {
    const frame = await this.capture(tab);
    if (mode === "full") this.forget(tab);
    this.state(tab).last = frame.img;
    return this.report(tab, frame, "탭 사진", null, mode === "full");
  }

  // 일부를 원본 화질로 확대. 기준 화면은 바꾸지 않는다.
  async zoom(tab, x, y, w, h) {
    const frame = await this.capture(tab);
    const k0 = 1 / frame.r; // 사진 픽셀 → 원본 픽셀
    let piece = crop(frame.raw, x * k0, y * k0, w * k0, h * k0);
    const size = fitSize(piece.width, piece.height, config.zoomMax);
    piece = resizeBox(piece, size.width, size.height);
    const k = piece.width / w;
    return [
      { type: "text", text: `확대: ${this.label} ${tab} 사진 좌표 x=${x}~${x + w}, y=${y}~${y + h}를 ${k.toFixed(2)}배로. 이 이미지의 픽셀 (px, py)는 사진 좌표 (${x} + px/${k.toFixed(2)}, ${y} + py/${k.toFixed(2)})입니다. 클릭은 사진 좌표로 하세요.` },
      { type: "image", data: encodePng(piece).toString("base64"), mimeType: "image/png" },
    ];
  }
}
