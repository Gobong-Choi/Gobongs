// 기록: 사용자 폴더\BrowserHandPilot\logs\날짜.log 에 한 줄씩 남긴다(관리 페이지가 읽는다).
// 앱 전용 폴더(AppData)에 두지 않는 이유: Claude 스토어판 안에서는 AppData가 앱 전용 사본으로 바뀌어 앱 밖에서 안 보인다.
import { appendFileSync, mkdirSync } from "node:fs";
import { join } from "node:path";
import { homeDir } from "../tor/config.js";

const dir = join(homeDir, "logs");
const who = `${process.argv[2] || "tool"}#${process.pid}`;

export function log(level, message) {
  try {
    mkdirSync(dir, { recursive: true });
    const now = new Date();
    const day = now.toISOString().slice(0, 10);
    appendFileSync(join(dir, `${day}.log`), `${now.toISOString()} ${level.toUpperCase()} ${who} ${message}\n`);
  } catch {
    // 기록 실패는 동작을 막지 않는다
  }
}
