// 정지 키: 사람이 정해진 키(기본 Esc)를 누르면 브라우저파일럿 동작을 바로 멈춘다.
// 브라우저파일럿의 입력은 운영체제를 거치지 않고 탭 안으로만 들어가므로, 운영체제가 보는 키 눌림은 언제나 사람의 것이다.
// 도구가 동작 중이거나 끝난 뒤 5초 안에만 지켜본다(평소에 누르는 Esc는 무시). 키 확인은 숨긴 PowerShell이 0.05초마다 한다.
import { spawn } from "node:child_process";
import { config } from "../tor/config.js";
import { log } from "./log.js";

const VK = { Escape: 0x1b, Pause: 0x13, ScrollLock: 0x91, F12: 0x7b };

let child = null;
let watching = 0;      // 이 시각까지 지켜본다
let stoppedAt = 0;     // 마지막으로 정지 키를 누른 시각
let busy = false;      // 지금 도구 동작 중인지

function ensureChild() {
  if (child) return;
  const vk = VK[config.stopKey] ?? VK.Escape;
  const script = `
Add-Type -Namespace W -Name K -MemberDefinition '[DllImport("user32.dll")] public static extern short GetAsyncKeyState(int v);'
[void][W.K]::GetAsyncKeyState(${vk})
while ($true) {
  if ([W.K]::GetAsyncKeyState(${vk}) -band 0x8000) { [Console]::Out.WriteLine("STOP"); [Console]::Out.Flush(); Start-Sleep -Milliseconds 400 }
  Start-Sleep -Milliseconds 50
}`;
  child = spawn("powershell", ["-NoProfile", "-WindowStyle", "Hidden", "-Command", script], { stdio: ["ignore", "pipe", "ignore"], windowsHide: true });
  child.stdout.on("data", (b) => {
    if (!String(b).includes("STOP")) return;
    if (busy || Date.now() < watching) {
      stoppedAt = Date.now();
      log("warn", `사용자가 ${config.stopKey}로 정지`);
    }
  });
  child.on("exit", () => { child = null; });
}

export class StoppedError extends Error {}

// 정지 키를 눌렀으면 예외. 동작 단계마다 부른다.
export function checkStop() {
  if (stoppedAt && Date.now() - stoppedAt < config.stopHoldMs) {
    throw new StoppedError(`사용자가 ${config.stopKey} 키로 정지했습니다. 더 진행하지 말고 사용자에게 어떻게 할지 물으세요. (${Math.round(config.stopHoldMs / 1000)}초 동안 모든 동작을 거절합니다)`);
  }
}

export function beginAction() {
  ensureChild();
  checkStop();
  busy = true;
}

export function endAction() {
  busy = false;
  watching = Date.now() + 5000;
}

// 쉴 때·끝날 때 감시를 끈다. 다음 동작 때 beginAction이 다시 켠다.
export function stopWatcher() {
  child?.kill();
  child = null;
}
