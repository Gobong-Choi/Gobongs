// 정지 키: 사람이 정해진 키(기본 Esc)를 누르면 브라우저파일럿 동작을 바로 멈춘다.
// 브라우저파일럿의 입력은 운영체제를 거치지 않고 탭 안으로만 들어가므로, 운영체제가 보는 키 눌림은 언제나 사람의 것이다.
// 누른 순간 맨 앞 프로그램이 이 채팅이 일하는 브라우저이고 맨 앞 탭이 이 채팅 것일 때만 정지로 본다(판정은 도구가 setStopFilter로 정함).
// 바탕화면·다른 프로그램·Claude 앱에서 누른 키는 무시한다(2026-10-28 사용자 의견). 그래서 동작 중이 아니어도
// 도구를 쓰는 동안 내내 지켜본다(쉬면 감시도 끔). 키 확인은 숨긴 PowerShell이 0.05초마다 하고, 누르면 맨 앞 프로그램 경로를 알려 준다.
import { spawn } from "node:child_process";
import { config } from "../tor/config.js";
import { log } from "./log.js";

const VK = { Escape: 0x1b, Pause: 0x13, ScrollLock: 0x91, F12: 0x7b };

let child = null;
let stoppedAt = 0;               // 마지막으로 정지 키를 누른 시각
let isMine = async () => false;  // 맨 앞 프로그램 경로 → 이 채팅 탭이 맨 앞인지

export function setStopFilter(fn) {
  isMine = fn;
}

async function onKey(exe) {
  let mine = false;
  try {
    mine = await isMine(exe);
  } catch {}
  if (mine) {
    stoppedAt = Date.now();
    log("warn", `사용자가 ${config.stopKey}로 정지`);
  } else {
    log("debug", `${config.stopKey}: 이 채팅 탭이 맨 앞이 아니라 무시`);
  }
}

function ensureChild() {
  if (child) return;
  const vk = VK[config.stopKey] ?? VK.Escape;
  const script = `
Add-Type -Namespace W -Name K -MemberDefinition '
[DllImport("user32.dll")] public static extern short GetAsyncKeyState(int v);
[DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
[DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr h, out uint p);'
[void][W.K]::GetAsyncKeyState(${vk})
while ($true) {
  if ([W.K]::GetAsyncKeyState(${vk}) -band 0x8000) {
    [uint32]$p = 0
    [void][W.K]::GetWindowThreadProcessId([W.K]::GetForegroundWindow(), [ref]$p)
    $exe = ""
    try { $exe = (Get-Process -Id $p -ErrorAction Stop).Path } catch {}
    [Console]::Out.WriteLine("STOP|" + $exe); [Console]::Out.Flush(); Start-Sleep -Milliseconds 400
  }
  Start-Sleep -Milliseconds 50
}`;
  child = spawn("powershell", ["-NoProfile", "-WindowStyle", "Hidden", "-Command", script], { stdio: ["ignore", "pipe", "ignore"], windowsHide: true });
  child.stdout.on("data", (b) => {
    for (const line of String(b).split(/\r?\n/)) {
      if (line.startsWith("STOP|")) onKey(line.slice(5).trim());
    }
  });
  child.on("exit", () => { child = null; });
}

export class StoppedError extends Error {}

// 정지 키를 눌렀으면 예외. 동작 단계마다 부른다.
export function checkStop() {
  if (stoppedAt && Date.now() - stoppedAt < config.stopHoldMs) {
    throw new StoppedError(`사용자가 ${config.stopKey} 키로 정지했습니다. 더 진행하지 말고 사용자에게 어떻게 할지 물으세요. (${Math.round(config.stopHoldMs / 1000)}초 동안 모든 동작을 거절합니다)`);
  }
}

export function beginAction() {
  ensureChild();
  checkStop();
}

// 쉴 때·끝날 때 감시를 끈다. 다음 동작 때 beginAction이 다시 켠다.
export function stopWatcher() {
  child?.kill();
  child = null;
}
