// 탭 연결: 탭마다 크롬 디버거를 따로 붙이고 뗀다.
// 연결된 탭에만 명령이 가므로 다른 탭·다른 창에는 영향이 없다.
import { captureTab, viewportWidth } from "./capture.js";
import * as input from "./input.js";
import { startBridge } from "./bridge.js";

const DEBUGGER_VERSION = "1.3";
const attachedTabs = new Set();

async function attach(tabId) {
  if (attachedTabs.has(tabId)) return;
  await chrome.debugger.attach({ tabId }, DEBUGGER_VERSION);
  attachedTabs.add(tabId);
}

async function detach(tabId) {
  if (!attachedTabs.has(tabId)) return;
  await chrome.debugger.detach({ tabId });
  attachedTabs.delete(tabId);
}

// 사용자가 "디버깅 중" 안내 줄의 [취소]를 누르거나 탭을 닫으면 목록에서 뺀다.
chrome.debugger.onDetach.addListener((source) => {
  attachedTabs.delete(source.tabId);
});

// 표시: Claude가 조작하는 탭을 채팅마다 다른 "Hand-pilot N" 탭 그룹에 넣고 확장 아이콘에 "AI N" 배지를 띄운다.
// slot은 몇 번째 채팅(도구 포트)인지다. 팝업 시험 버튼은 slot이 없어 1번으로 본다.
const GROUP_PREFIX = "Hand-pilot";
const GROUP_COLORS = ["purple", "blue", "green", "orange"];
const groupTitle = (slot = 0) => `${GROUP_PREFIX} ${slot + 1}`;

// 그 탭이 어느 채팅 그룹에 들어 있는지(없으면 null)
async function ownerSlot(tab) {
  if (tab.groupId === chrome.tabGroups.TAB_GROUP_ID_NONE) return null;
  const group = await chrome.tabGroups.get(tab.groupId);
  const m = group.title?.match(new RegExp(`^${GROUP_PREFIX} (\\d+)$`));
  return m ? Number(m[1]) - 1 : null;
}

async function markTab(tabId, slot = 0) {
  const tab = await chrome.tabs.get(tabId);
  await chrome.action.setBadgeText({ tabId, text: `AI${slot + 1}` });
  await chrome.action.setBadgeBackgroundColor({ tabId, color: "#7c3aed" });
  const title = groupTitle(slot);
  const [group] = await chrome.tabGroups.query({ windowId: tab.windowId, title });
  if (group) {
    if (tab.groupId !== group.id) await chrome.tabs.group({ tabIds: tabId, groupId: group.id });
    return;
  }
  const groupId = await chrome.tabs.group({ tabIds: tabId, createProperties: { windowId: tab.windowId } });
  await chrome.tabGroups.update(groupId, { title, color: GROUP_COLORS[slot % GROUP_COLORS.length] });
}

// 다른 채팅 그룹에 든 탭은 건드리지 않는다.
async function guardOwner(tabId, slot = 0) {
  const owner = await ownerSlot(await chrome.tabs.get(tabId));
  if (owner !== null && owner !== slot) {
    throw new Error(`이 탭은 다른 채팅(${groupTitle(owner)})이 조작 중입니다. 자기 탭을 new_tab으로 여세요.`);
  }
}

// 도구에서 오는 명령은 주인을 확인하고, 필요하면 그 탭에 먼저 연결하고 표시를 붙인다.
const withTab = (fn) => async (msg) => {
  await guardOwner(msg.tabId, msg.slot);
  await attach(msg.tabId);
  await markTab(msg.tabId, msg.slot).catch(() => {}); // 표시 실패는 조작을 막지 않는다
  return fn(msg);
};

const handlers = {
  attach: (msg) => attach(msg.tabId),
  detach: (msg) => detach(msg.tabId),
  status: (msg) => attachedTabs.has(msg.tabId),
  capture: withTab((msg) => captureTab(msg.tabId)),
  viewportWidth: withTab((msg) => viewportWidth(msg.tabId)),
  click: withTab((m) => input.click(m.tabId, m.x, m.y, m.button, m.double)),
  move: withTab((m) => input.move(m.tabId, m.x, m.y)),
  scroll: withTab((m) => input.scroll(m.tabId, m.x, m.y, m.dy)),
  type: withTab((m) => input.typeText(m.tabId, m.text)),
  key: withTab((m) => input.key(m.tabId, m.combo)),
  tabs: async (m) => {
    const tabs = await chrome.tabs.query({});
    return Promise.all(tabs.map(async (t) => {
      const owner = await ownerSlot(t).catch(() => null);
      return {
        id: t.id, url: t.url, title: t.title, active: t.active, windowId: t.windowId, incognito: t.incognito,
        mine: owner === (m.slot ?? 0), otherChat: owner !== null && owner !== (m.slot ?? 0),
      };
    }));
  },
  newTab: async (m) => {
    const tabId = m.incognito ? await newIncognitoTab(m.url) : await newNormalTab(m.url);
    await markTab(tabId, m.slot).catch(() => {});
    return tabId;
  },
  navigate: async (m) => {
    await guardOwner(m.tabId, m.slot);
    await markTab(m.tabId, m.slot).catch(() => {});
    await chrome.tabs.update(m.tabId, { url: m.url });
    await waitLoaded(m.tabId);
  },
};

async function newNormalTab(url) {
  const [win] = await chrome.windows.getAll({ windowTypes: ["normal"] }).then((ws) => ws.filter((w) => !w.incognito));
  const tab = await chrome.tabs.create({ url: url || "about:blank", active: false, ...(win && { windowId: win.id }) });
  return tab.id;
}

// 시크릿 창이 있으면 그 안에 뒤쪽 탭으로, 없으면 시크릿 창을 새로 연다(사용자 창 앞으로 튀어나오지 않게).
async function newIncognitoTab(url) {
  if (!(await chrome.extension.isAllowedIncognitoAccess())) {
    throw new Error("시크릿 모드가 허용되지 않았습니다. chrome://extensions → Browser Hand-pilot 세부정보 → '시크릿 모드에서 허용'을 켜세요.");
  }
  const wins = await chrome.windows.getAll({ windowTypes: ["normal"] });
  const win = wins.find((w) => w.incognito);
  if (win) {
    return (await chrome.tabs.create({ windowId: win.id, url: url || "about:blank", active: false })).id;
  }
  const created = await chrome.windows.create({ incognito: true, url: url || "about:blank", focused: false });
  return created.tabs[0].id;
}

function waitLoaded(tabId) {
  return new Promise((resolve) => {
    const timer = setTimeout(done, 20000);
    function done() {
      clearTimeout(timer);
      chrome.tabs.onUpdated.removeListener(listener);
      resolve();
    }
    function listener(id, info) {
      if (id === tabId && info.status === "complete") done();
    }
    chrome.tabs.onUpdated.addListener(listener);
  });
}

// 팝업 시험 버튼
chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  const handler = handlers[msg.type];
  if (!handler) {
    sendResponse({ ok: false, error: "알 수 없는 명령: " + msg.type });
    return false;
  }
  Promise.resolve(handler(msg))
    .then((value) => sendResponse({ ok: true, value }))
    .catch((err) => sendResponse({ ok: false, error: String(err.message || err) }));
  return true; // 비동기 응답
});

// Claude 도구와 연결. 서비스 워커는 할 일이 없으면 30초 뒤 잠들어 재시도도 멈추므로,
// 30초마다 알람으로 깨워 다시 붙어 본다.
const bridge = startBridge(handlers);
chrome.alarms.create("reconnect", { periodInMinutes: 0.5 });
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === "reconnect") bridge.ensure();
});
