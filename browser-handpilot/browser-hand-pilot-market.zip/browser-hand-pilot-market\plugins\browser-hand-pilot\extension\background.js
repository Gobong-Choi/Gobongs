// 탭 연결: 탭마다 크롬 디버거를 따로 붙이고 뗀다.
// 연결된 탭에만 명령이 가므로 다른 탭·다른 창에는 영향이 없다.
import { captureTab, viewportWidth } from "./capture.js";
import * as input from "./input.js";
import { startBridge, proof } from "./bridge.js";

const DEBUGGER_VERSION = "1.3";
const attachedTabs = new Set();
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

// 역할: 이 크롬이 Claude 전용 크롬(dedicated, 기본 작업)인지 사용자 크롬(user, 로그인 필요할 때만)인지.
// 도구가 전용 크롬을 띄울 때 여는 확인 페이지 주소 뒤의 암호(HMAC(비밀, CLAIM))를 보고 스스로 기억한다.
// 웹페이지는 비밀을 몰라 이 암호를 만들 수 없다.
const CLAIM = "browserpilot-dedicated"; // chrome/wsserver.js와 같아야 한다
let role = null;
async function getRole() {
  if (!role) role = (await chrome.storage.local.get("role")).role || "user";
  return role;
}
chrome.tabs.onUpdated.addListener(async (_tabId, info) => {
  const m = (info.url || "").match(/^http:\/\/127\.0\.0\.1:\d+\/browserpilot-claim#([0-9a-f]{64})$/);
  if (!m || m[1] !== (await proof(CLAIM)) || (await getRole()) === "dedicated") return;
  await chrome.storage.local.set({ role: "dedicated" });
  role = "dedicated";
  bridge.reconnect(); // 새 역할로 다시 인사한다
});

async function attach(tabId) {
  if (attachedTabs.has(tabId)) return;
  await chrome.debugger.attach({ tabId }, DEBUGGER_VERSION);
  attachedTabs.add(tabId);
}

async function detach(tabId) {
  if (!attachedTabs.has(tabId)) return;
  await chrome.debugger.detach({ tabId });
  attachedTabs.delete(tabId);
}

// 사용자가 "디버깅 중" 안내 줄의 [취소]를 누르거나 탭을 닫으면 목록에서 뺀다.
chrome.debugger.onDetach.addListener((source) => {
  attachedTabs.delete(source.tabId);
});

// 표시: Claude가 조작하는 탭을 채팅마다 다른 "BrowserPilot N" 탭 그룹에 넣고 확장 아이콘에 "AI N" 배지를 띄운다.
// slot은 몇 번째 채팅(도구 포트)인지다. 팝업 시험 버튼은 slot이 없어 1번으로 본다.
const GROUP_PREFIX = "BrowserPilot";
const GROUP_COLORS = ["purple", "blue", "green", "orange"];
const groupTitle = (slot = 0) => `${GROUP_PREFIX} ${slot + 1}`;

// 그 탭이 어느 채팅 그룹에 들어 있는지(없으면 null)
async function ownerSlot(tab) {
  if (tab.groupId === chrome.tabGroups.TAB_GROUP_ID_NONE) return null;
  const group = await chrome.tabGroups.get(tab.groupId);
  const m = group.title?.match(new RegExp(`^${GROUP_PREFIX} (\\d+)$`));
  return m ? Number(m[1]) - 1 : null;
}

async function markTab(tabId, slot = 0) {
  const tab = await chrome.tabs.get(tabId);
  await chrome.action.setBadgeText({ tabId, text: `AI${slot + 1}` });
  await chrome.action.setBadgeBackgroundColor({ tabId, color: "#7c3aed" });
  const title = groupTitle(slot);
  const [group] = await chrome.tabGroups.query({ windowId: tab.windowId, title });
  if (group) {
    if (tab.groupId !== group.id) await chrome.tabs.group({ tabIds: tabId, groupId: group.id });
    return;
  }
  const groupId = await chrome.tabs.group({ tabIds: tabId, createProperties: { windowId: tab.windowId } });
  await chrome.tabGroups.update(groupId, { title, color: GROUP_COLORS[slot % GROUP_COLORS.length] });
}

// 다른 채팅 그룹에 든 탭은 건드리지 않는다.
async function guardOwner(tabId, slot = 0) {
  const owner = await ownerSlot(await chrome.tabs.get(tabId));
  if (owner !== null && owner !== slot) {
    throw new Error(`이 탭은 다른 채팅(${groupTitle(owner)})이 조작 중입니다. 자기 탭을 new_tab으로 여세요.`);
  }
}

// 크롬은 창 안의 뒤쪽 탭을 그리지 않는다. 전용 크롬에서는 조작할 탭을 그 창의 앞 탭으로 바꾼다
// (창 자체는 앞으로 끌어오지 않음). 사용자 크롬에서는 사용자가 보는 탭이 바뀌므로 하지 않는다.
async function showTab(tabId) {
  if ((await getRole()) !== "dedicated") return;
  const tab = await chrome.tabs.get(tabId);
  if (tab.active) return;
  await chrome.tabs.update(tabId, { active: true });
  await sleep(200);
}

// 도구에서 오는 명령은 주인을 확인하고, 필요하면 그 탭에 먼저 연결하고 표시를 붙인다.
const withTab = (fn) => async (msg) => {
  await guardOwner(msg.tabId, msg.slot);
  await showTab(msg.tabId);
  await attach(msg.tabId);
  await markTab(msg.tabId, msg.slot).catch(() => {}); // 표시 실패는 조작을 막지 않는다
  return fn(msg);
};

const handlers = {
  attach: (msg) => attach(msg.tabId),
  detach: (msg) => detach(msg.tabId),
  status: (msg) => attachedTabs.has(msg.tabId),
  // 그 채팅(slot)의 탭과 그룹 밖 탭에서 디버거를 뗀다. 다른 채팅 탭은 그대로 둔다.
  release: async (m) => {
    for (const tabId of [...attachedTabs]) {
      const owner = await chrome.tabs.get(tabId).then(ownerSlot).catch(() => null);
      if (owner === null || owner === m.slot) await detach(tabId).catch(() => attachedTabs.delete(tabId));
    }
  },
  capture: withTab(async (msg) => captureTab(msg.tabId, { restore: (await getRole()) === "dedicated" })),
  viewportWidth: withTab((msg) => viewportWidth(msg.tabId)),
  click: withTab((m) => input.click(m.tabId, m.x, m.y, m.button, m.double)),
  move: withTab((m) => input.move(m.tabId, m.x, m.y)),
  scroll: withTab((m) => input.scroll(m.tabId, m.x, m.y, m.dy)),
  type: withTab((m) => input.typeText(m.tabId, m.text)),
  key: withTab((m) => input.key(m.tabId, m.combo)),
  tabUrl: async (m) => (await chrome.tabs.get(m.tabId)).url,
  tabStatus: async (m) => (await chrome.tabs.get(m.tabId)).status,
  // 디스크의 확장 파일이 새 버전으로 바뀌었을 때 도구가 부른다(압축 해제 확장은 스스로 다시 읽지 않음).
  reload: async () => {
    setTimeout(() => chrome.runtime.reload(), 100);
    return true;
  },
  tabs: async (m) => {
    const tabs = await chrome.tabs.query({});
    return Promise.all(tabs.map(async (t) => {
      const owner = await ownerSlot(t).catch(() => null);
      return {
        id: t.id, url: t.url, title: t.title, active: t.active, windowId: t.windowId, incognito: t.incognito,
        mine: owner === (m.slot ?? 0), otherChat: owner !== null && owner !== (m.slot ?? 0),
      };
    }));
  },
  // mode: "private" 전용 크롬 시크릿 창 | "saved" 전용 크롬 일반 창(로그인 유지) | "user" 사용자 크롬 일반 창(뒤쪽 탭)
  newTab: async (m) => {
    const mode = m.mode || (m.incognito ? "private" : "user");
    const dedicated = (await getRole()) === "dedicated";
    if (mode !== "user" && !dedicated) throw new Error("이 크롬은 Claude 전용 크롬이 아닙니다");
    const tabId = mode === "private" ? await newIncognitoTab(m.url, m.win, dedicated)
      : mode === "saved" ? await newClaudeNormalTab(m.url, m.win)
      : await newNormalTab(m.url);
    await markTab(tabId, m.slot).catch(() => {});
    // 첫 페이지가 다 뜨기 전에 찍으면 사진이 끝나지 않는 일이 있어(2026-10-27 시험) 뜰 때까지 기다린다
    if (m.url) await waitLoaded(tabId);
    return tabId;
  },
  navigate: async (m) => {
    await guardOwner(m.tabId, m.slot);
    await markTab(m.tabId, m.slot).catch(() => {});
    await chrome.tabs.update(m.tabId, { url: m.url });
    await waitLoaded(m.tabId);
  },
};

async function newNormalTab(url) {
  const [win] = await chrome.windows.getAll({ windowTypes: ["normal"] }).then((ws) => ws.filter((w) => !w.incognito));
  const tab = await chrome.tabs.create({ url: url || "about:blank", active: false, ...(win && { windowId: win.id }) });
  return tab.id;
}

// Claude 창은 주 모니터 오른쪽 아래 구석에 연다. 크기는 도구 설정(chromeWindowWidth/Height)을 받는다.
const CLAUDE_WINDOW = { width: 1024, height: 768 };

async function cornerBounds(win = CLAUDE_WINDOW) {
  const displays = await chrome.system.display.getInfo().catch(() => []);
  const area = (displays.find((d) => d.isPrimary) || displays[0])?.workArea;
  if (!area) return {};
  const width = Math.min(win.width || CLAUDE_WINDOW.width, area.width);
  const height = Math.min(win.height || CLAUDE_WINDOW.height, area.height);
  return { width, height, left: area.left + area.width - width, top: area.top + area.height - height };
}

// BrowserPilot 탭 그룹이 있는 창(= Claude 창) 가운데 시크릿 여부가 맞는 것
async function claudeWindow(incognito) {
  const groups = await chrome.tabGroups.query({});
  const claudeWindows = new Set(groups.filter((g) => g.title?.startsWith(GROUP_PREFIX + " ")).map((g) => g.windowId));
  const wins = await chrome.windows.getAll({ windowTypes: ["normal"] });
  return wins.find((w) => w.incognito === incognito && claudeWindows.has(w.id));
}

// Claude 시크릿 창이 있으면 그 안에, 없으면 구석에 새로 연다(사용자 창 앞으로 튀어나오지 않게).
// 사용자가 직접 연 시크릿 창은 쓰지 않는다. front: 전용 크롬이면 앞 탭으로(뒤쪽 탭은 그려지지 않음).
async function newIncognitoTab(url, win, front = false) {
  if (!(await chrome.extension.isAllowedIncognitoAccess())) {
    throw new Error("시크릿 모드가 허용되지 않았습니다. 사용자에게 전용 크롬 창에서 chrome://extensions → BrowserPilot(브라우저파일럿) 세부정보 → '시크릿 모드에서 허용'을 켜 달라고 하세요.");
  }
  const w = await claudeWindow(true);
  if (w) return (await chrome.tabs.create({ windowId: w.id, url: url || "about:blank", active: front })).id;
  const created = await chrome.windows.create({
    incognito: true, url: url || "about:blank", focused: false, state: "normal", ...(await cornerBounds(win)),
  });
  return created.tabs[0].id;
}

// 전용 크롬의 일반 창(사용자가 이 창에서 로그인해 둔 사이트는 로그인이 유지됨). 전용 크롬 전체가 Claude 것이므로
// Claude 창이 없으면 아무 일반 창이나 쓰고, 그것도 없으면 구석에 새로 연다.
async function newClaudeNormalTab(url, win) {
  const w = (await claudeWindow(false)) ||
    (await chrome.windows.getAll({ windowTypes: ["normal"] })).find((x) => !x.incognito);
  if (w) return (await chrome.tabs.create({ windowId: w.id, url: url || "about:blank", active: true })).id;
  const created = await chrome.windows.create({ url: url || "about:blank", focused: false, state: "normal", ...(await cornerBounds(win)) });
  return created.tabs[0].id;
}

function waitLoaded(tabId) {
  return new Promise((resolve) => {
    const timer = setTimeout(done, 20000);
    function done() {
      clearTimeout(timer);
      chrome.tabs.onUpdated.removeListener(listener);
      resolve();
    }
    function listener(id, info) {
      if (id === tabId && info.status === "complete") done();
    }
    chrome.tabs.onUpdated.addListener(listener);
  });
}

// 팝업 시험 버튼
chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  const handler = handlers[msg.type];
  if (!handler) {
    sendResponse({ ok: false, error: "알 수 없는 명령: " + msg.type });
    return false;
  }
  Promise.resolve(handler(msg))
    .then((value) => sendResponse({ ok: true, value }))
    .catch((err) => sendResponse({ ok: false, error: String(err.message || err) }));
  return true; // 비동기 응답
});

// Claude 도구와 연결. 서비스 워커는 할 일이 없으면 30초 뒤 잠들어 재시도도 멈추므로,
// 30초마다 알람으로 깨워 다시 붙어 본다.
const bridge = startBridge(handlers, getRole);
chrome.alarms.create("reconnect", { periodInMinutes: 0.5 });
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === "reconnect") bridge.ensure();
});
