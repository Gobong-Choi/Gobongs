// 다리: 이 PC 안의 Claude 도구(127.0.0.1)에 웹소켓으로 붙어 명령을 받고 결과를 돌려준다.
// 채팅마다 도구가 하나씩 뜨고 각자 다른 포트(PORT_START부터 PORT_COUNT개)를 쓰므로, 포트마다 따로 붙는다.
// 몇 번째 포트에서 온 명령인지(slot)를 명령에 붙여 넘겨 채팅마다 탭 그룹을 나눈다.
// 도구가 꺼져 있으면 몇 초마다 다시 붙어 본다. 연결 중에는 주기적으로 신호를 보내 서비스 워커가 잠들지 않게 한다.
// 연결 없이 잠든 서비스 워커는 background.js의 알람이 깨워 ensure()를 부른다.
// 보안: 붙은 상대가 같은 비밀 암호(secret.js)를 아는 우리 도구인지 확인한 뒤에만 명령을 따른다.
//       hello{nonce} → welcome{proof(nonce), nonce2} 확인 → auth{proof(nonce2)}. 암호 자체는 보내지 않는다.
import { SECRET } from "./secret.js";

const enc = new TextEncoder();
const keyPromise = crypto.subtle.importKey("raw", enc.encode(SECRET), { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
async function proof(nonce) {
  const sig = await crypto.subtle.sign("HMAC", await keyPromise, enc.encode(nonce));
  return [...new Uint8Array(sig)].map((b) => b.toString(16).padStart(2, "0")).join("");
}
function randomNonce() {
  return [...crypto.getRandomValues(new Uint8Array(16))].map((b) => b.toString(16).padStart(2, "0")).join("");
}

const PORT_START = 9333; // config.json의 chromePort와 같아야 한다
const PORT_COUNT = 4;    // config.json의 chromePortCount와 같아야 한다
const RETRY_MS = 5000;
const KEEPALIVE_MS = 20000;

function startSlot(slot, handlers) {
  const url = `ws://127.0.0.1:${PORT_START + slot}`;
  let ws = null;
  let keepalive = null;
  let retryTimer = null;

  function connect() {
    clearTimeout(retryTimer);
    try {
      ws = new WebSocket(url);
    } catch {
      ws = null;
      retryTimer = setTimeout(connect, RETRY_MS);
      return;
    }
    let trusted = false;
    const myNonce = randomNonce();
    ws.onopen = () => {
      ws.send(JSON.stringify({ type: "hello", nonce: myNonce }));
    };
    ws.onclose = () => {
      clearInterval(keepalive);
      ws = null;
      retryTimer = setTimeout(connect, RETRY_MS);
    };
    ws.onerror = () => {}; // onclose에서 다시 붙는다
    ws.onmessage = async (e) => {
      const msg = JSON.parse(e.data);
      if (!trusted) {
        // 상대가 암호를 아는지 확인하고, 우리도 증명한다. 틀리면 끊는다.
        if (msg.type === "welcome" && msg.proof === (await proof(myNonce)) && typeof msg.nonce === "string") {
          ws.send(JSON.stringify({ type: "auth", proof: await proof(msg.nonce) }));
          trusted = true;
          keepalive = setInterval(() => ws.send(JSON.stringify({ type: "keepalive" })), KEEPALIVE_MS);
        } else {
          ws.close();
        }
        return;
      }
      const handler = handlers[msg.type];
      let reply;
      try {
        if (!handler) throw new Error("알 수 없는 명령: " + msg.type);
        reply = { id: msg.id, ok: true, value: await handler({ ...msg, slot }) };
      } catch (err) {
        reply = { id: msg.id, ok: false, error: String(err.message || err) };
      }
      if (ws) ws.send(JSON.stringify(reply));
    };
  }

  connect();
  return {
    ensure() {
      if (!ws) connect();
    },
  };
}

export function startBridge(handlers) {
  const slots = Array.from({ length: PORT_COUNT }, (_, i) => startSlot(i, handlers));
  return {
    ensure() {
      slots.forEach((s) => s.ensure());
    },
  };
}
