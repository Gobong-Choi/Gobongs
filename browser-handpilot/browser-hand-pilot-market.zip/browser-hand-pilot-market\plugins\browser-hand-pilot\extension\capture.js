// 사진 찍기: 연결된 탭 하나만 찍는다.
// 웹페이지 코드(DOM 등)는 읽지 않고 화면 그림과 화면 크기만 받는다.

export async function captureTab(tabId) {
  const result = await chrome.debugger.sendCommand(
    { tabId },
    "Page.captureScreenshot",
    { format: "png" }
  );
  return "data:image/png;base64," + result.data;
}

// 사진 픽셀 ÷ 입력 좌표(CSS 픽셀) 배율을 재기 위한 화면 폭
export async function viewportWidth(tabId) {
  const m = await chrome.debugger.sendCommand({ tabId }, "Page.getLayoutMetrics");
  return (m.cssLayoutViewport || m.layoutViewport).clientWidth;
}
