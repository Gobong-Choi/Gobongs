// 사진 찍기: 연결된 탭 하나만 찍는다.
// 웹페이지 코드(DOM 등)는 읽지 않고 화면 그림과 화면 크기만 받는다.
//
// 크롬은 최소화된 창의 탭을 새로 그리지 않아, 찍어도 옛 화면이 나오거나 끝나지 않는다(2026-10-27 시험).
// 옛 사진으로 '변화 없음'이라고 잘못 알리지 않도록, 최소화된 창이면 찍지 않고 분명한 오류를 낸다.
// 다른 창 뒤에 가려져 있는 것은 괜찮다(전용 크롬은 '가려져도 그리기' 설정으로 떠서 속도도 같다).

const send = (tabId, method, params) => chrome.debugger.sendCommand({ tabId }, method, params);
const timeout = (ms) => new Promise((_, reject) => setTimeout(() => reject(new Error("timeout")), ms));

// restore: 전용 크롬이면 어느 창이든 Claude 것이므로 되살린다. 사용자 크롬은 Claude 시크릿 창만.
async function assertVisible(tabId, restore) {
  const tab = await chrome.tabs.get(tabId);
  const win = await chrome.windows.get(tab.windowId);
  if (win.state === "minimized" && (restore || win.incognito)) {
    // Claude 창이면 원래 크기로 되살리되 앞으로 끌어오지는 않는다(다른 창 작업을 방해하지 않게)
    await chrome.windows.update(win.id, { state: "normal", focused: false });
    await new Promise((r) => setTimeout(r, 500));
    const again = await chrome.windows.get(win.id);
    if (again.state !== "minimized") return;
  }
  if (win.state === "minimized") {
    throw new Error("이 탭이 있는 크롬 창이 최소화돼 있어 화면을 볼 수 없습니다. 사용자에게 그 창(BrowserPilot 탭 그룹이 있는 창)을 " +
      "최소화하지 말고 다른 창 뒤에 두어 달라고 말하세요. 가려져 있는 것은 괜찮습니다.");
  }
}

export async function captureTab(tabId, { restore = false } = {}) {
  await assertVisible(tabId, restore);
  let result;
  for (let attempt = 0; !result; attempt++) {
    try {
      result = await Promise.race([send(tabId, "Page.captureScreenshot", { format: "png" }), timeout(5000)]);
    } catch {
      if (attempt === 0) continue; // 페이지가 바뀌는 도중이면 한 번 더
      throw new Error("크롬이 이 탭 화면을 그리지 않아 사진을 못 찍었습니다. 그 크롬 창을 최소화하지 말고 열어 두어 달라고 사용자에게 말하세요.");
    }
  }
  return "data:image/png;base64," + result.data;
}

// 사진 픽셀 ÷ 입력 좌표(CSS 픽셀) 배율을 재기 위한 화면 폭
export async function viewportWidth(tabId) {
  const m = await chrome.debugger.sendCommand({ tabId }, "Page.getLayoutMetrics");
  return (m.cssLayoutViewport || m.layoutViewport).clientWidth;
}
