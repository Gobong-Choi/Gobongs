// 손: 연결된 탭 하나에만 마우스·키보드·스크롤 신호를 넣는다. 진짜 마우스·키보드는 움직이지 않는다.
// 좌표는 입력 좌표(CSS 픽셀) 기준이다. 사진 픽셀 → 입력 좌표 변환은 서버 쪽에서 한다.

const send = (tabId, method, params) => chrome.debugger.sendCommand({ tabId }, method, params);

const BUTTONS = { left: "left", right: "right", middle: "middle" };

export async function move(tabId, x, y) {
  await send(tabId, "Input.dispatchMouseEvent", { type: "mouseMoved", x, y });
}

export async function click(tabId, x, y, button = "left", double = false) {
  const b = BUTTONS[button] || "left";
  await move(tabId, x, y);
  for (let n = 1; n <= (double ? 2 : 1); n++) {
    await send(tabId, "Input.dispatchMouseEvent", { type: "mousePressed", x, y, button: b, clickCount: n });
    await send(tabId, "Input.dispatchMouseEvent", { type: "mouseReleased", x, y, button: b, clickCount: n });
  }
}

export async function scroll(tabId, x, y, dy) {
  await send(tabId, "Input.dispatchMouseEvent", { type: "mouseWheel", x, y, deltaX: 0, deltaY: dy });
}

// 한글도 그대로 들어가도록 글자 넣기 방식을 쓴다.
export async function typeText(tabId, text) {
  await send(tabId, "Input.insertText", { text });
}

// 특수 키: key 이름, code, Windows 가상 키 코드
const KEYS = {
  enter: ["Enter", "Enter", 13, "\r"], tab: ["Tab", "Tab", 9], backspace: ["Backspace", "Backspace", 8],
  escape: ["Escape", "Escape", 27], esc: ["Escape", "Escape", 27], delete: ["Delete", "Delete", 46],
  space: [" ", "Space", 32, " "], home: ["Home", "Home", 36], end: ["End", "End", 35],
  pageup: ["PageUp", "PageUp", 33], pagedown: ["PageDown", "PageDown", 34],
  left: ["ArrowLeft", "ArrowLeft", 37], up: ["ArrowUp", "ArrowUp", 38],
  right: ["ArrowRight", "ArrowRight", 39], down: ["ArrowDown", "ArrowDown", 40],
  arrowleft: ["ArrowLeft", "ArrowLeft", 37], arrowup: ["ArrowUp", "ArrowUp", 38],
  arrowright: ["ArrowRight", "ArrowRight", 39], arrowdown: ["ArrowDown", "ArrowDown", 40],
  f5: ["F5", "F5", 116],
};
const MODIFIERS = { alt: 1, ctrl: 2, control: 2, meta: 4, shift: 8 };

function keyInfo(name) {
  const k = KEYS[name.toLowerCase()];
  if (k) return { key: k[0], code: k[1], windowsVirtualKeyCode: k[2], text: k[3] };
  if ([...name].length === 1) {
    const upper = name.toUpperCase();
    const vk = /[A-Z0-9]/.test(upper) ? upper.charCodeAt(0) : 0;
    return { key: name, code: /[A-Z]/.test(upper) ? "Key" + upper : "", windowsVirtualKeyCode: vk, text: name };
  }
  throw new Error("모르는 키: " + name);
}

// combo 예: "Enter", "Ctrl+A", "Shift+Tab". 브라우저 메뉴 단축키(Ctrl+F 찾기창 등)는 페이지에만 전달되어 열리지 않는다.
export async function key(tabId, combo) {
  const parts = combo.split("+").map((p) => p.trim());
  const main = parts.pop();
  const modifiers = parts.reduce((m, p) => m | (MODIFIERS[p.toLowerCase()] || 0), 0);
  const info = keyInfo(main);
  const text = modifiers & (2 | 4) ? undefined : info.text;
  await send(tabId, "Input.dispatchKeyEvent", { type: text ? "keyDown" : "rawKeyDown", modifiers, ...info, text });
  await send(tabId, "Input.dispatchKeyEvent", { type: "keyUp", modifiers, ...info, text: undefined });
}
