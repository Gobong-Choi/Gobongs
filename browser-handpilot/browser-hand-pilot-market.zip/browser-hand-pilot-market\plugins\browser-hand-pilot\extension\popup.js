// 시험용 버튼: 지금 보고 있는 탭에 연결 → 사진 찍기 → 연결 해제.
const statusEl = document.getElementById("status");
const shotEl = document.getElementById("shot");

async function currentTabId() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  return tab.id;
}

async function send(type) {
  const tabId = await currentTabId();
  const res = await chrome.runtime.sendMessage({ type, tabId });
  if (!res.ok) throw new Error(res.error);
  return res.value;
}

async function refreshStatus() {
  const connected = await send("status");
  statusEl.textContent = connected ? "이 탭: 연결됨" : "이 탭: 연결 안 됨";
}

function onClick(id, action) {
  document.getElementById(id).addEventListener("click", async () => {
    try {
      await action();
    } catch (err) {
      statusEl.textContent = "오류: " + err.message;
      return;
    }
    await refreshStatus();
  });
}

onClick("attach", () => send("attach"));
onClick("detach", () => send("detach"));
onClick("capture", async () => {
  shotEl.src = await send("capture");
});

refreshStatus();
