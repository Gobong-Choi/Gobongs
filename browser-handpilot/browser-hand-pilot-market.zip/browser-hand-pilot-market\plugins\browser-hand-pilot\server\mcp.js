// Claude 도구 창구: MCP(표준입출력, JSON-RPC 한 줄씩)로 도구 목록을 알려 주고 요청을 손·눈에 넘긴다.
// 외부 패키지 없이 직접 구현한다. 실행 인자로 브라우저를 고른다: node server/mcp.js tor | chrome
import { createInterface } from "node:readline";
import { openSession } from "../tor/launch.js";
import { Hand } from "../tor/actions.js";
import { ChromeHand } from "../chrome/actions.js";
import { config } from "../tor/config.js";

const BROWSER = process.argv[2] === "chrome" ? "chrome" : "tor";
const BROWSER_NAME = BROWSER === "chrome" ? "크롬" : "토르";

let hand = null;
let chromeHand = null;
async function getHand() {
  if (BROWSER === "chrome") {
    if (!chromeHand) {
      chromeHand = new ChromeHand();
      await chromeHand.link.start();
    }
    await chromeHand.link.waitConnected(config.chromeConnectTimeoutMs);
    return chromeHand;
  }
  if (!hand || !hand.connected) hand = new Hand(await openSession());
  return hand;
}

const tab = { type: "string", description: "탭 id (tabs 도구로 확인)" };
const num = (d) => ({ type: "number", description: d });

const TOOLS = [
  { name: "tabs", description: `${BROWSER_NAME}의 열린 탭 목록을 돌려준다.${BROWSER === "tor" ? " 토르가 꺼져 있으면 띄운다." : ""}`, inputSchema: { type: "object", properties: {} } },
  {
    name: "new_tab",
    description: "새 탭을 뒤에서 연다. url을 주면 그 주소로 간다." +
      (BROWSER === "chrome" ? " 기본은 시크릿 창. 사용자가 일반 크롬을 승인했을 때만 normal=true." : ""),
    inputSchema: {
      type: "object",
      properties: {
        url: { type: "string" },
        ...(BROWSER === "chrome" && { normal: { type: "boolean", description: "일반 크롬(로그인 상태)에 열기. 사용자 승인 뒤에만" } }),
      },
    },
  },
  { name: "navigate", description: "탭을 주소로 이동한다.", inputSchema: { type: "object", properties: { tab, url: { type: "string" } }, required: ["tab", "url"] } },
  { name: "screenshot", description: "그 탭만 사진 찍는다. 좌표는 이 사진의 픽셀 기준.", inputSchema: { type: "object", properties: { tab }, required: ["tab"] } },
  { name: "click", description: "그 탭 안 사진 좌표를 클릭한다. 진짜 마우스는 움직이지 않는다.", inputSchema: { type: "object", properties: { tab, x: num("사진 x"), y: num("사진 y"), button: { type: "string", enum: ["left", "right", "middle"] }, double: { type: "boolean" } }, required: ["tab", "x", "y"] } },
  { name: "move", description: "그 탭 안에서 마우스를 옮긴다(마우스 올림 효과).", inputSchema: { type: "object", properties: { tab, x: num("사진 x"), y: num("사진 y") }, required: ["tab", "x", "y"] } },
  { name: "type_text", description: "그 탭에 글자를 입력한다.", inputSchema: { type: "object", properties: { tab, text: { type: "string" } }, required: ["tab", "text"] } },
  { name: "key", description: "키를 누른다. 예: Enter, Tab, Ctrl+F, Shift+Tab", inputSchema: { type: "object", properties: { tab, combo: { type: "string" } }, required: ["tab", "combo"] } },
  { name: "scroll", description: "사진 좌표 위치에서 스크롤한다. dy>0 아래로.", inputSchema: { type: "object", properties: { tab, x: num("사진 x"), y: num("사진 y"), dy: num("픽셀") }, required: ["tab", "x", "y", "dy"] } },
];

// 동작 뒤에는 사진을 함께 돌려줘서 바로 결과를 보게 한다.
async function withShot(h, t, note) {
  const data = await h.stableScreenshot(t);
  return [{ type: "text", text: note }, { type: "image", data, mimeType: "image/png" }];
}

const RUN = {
  tabs: async (h) => [{
    type: "text",
    text: (h.link
      ? `이 채팅의 탭 그룹: Hand-pilot ${h.link.slotNumber} (mine=true인 탭만 이 채팅 것, otherChat=true는 건드리지 말 것)\n`
      : "토르: 항상 기록이 남지 않는 창이고, 한 번에 한 채팅만 쓸 수 있음. 작업은 new_tab으로 연 mine=true 탭에서.\n") +
      JSON.stringify(await h.tabs(), null, 1),
  }],
  new_tab: async (h, a) => [{ type: "text", text: "새 탭 id: " + (await h.newTab(a.url, !a.normal)) }],
  navigate: async (h, a) => { await h.navigate(a.tab, a.url); return withShot(h, a.tab, "이동함"); },
  screenshot: async (h, a) => withShot(h, a.tab, "탭 사진"),
  click: async (h, a) => { await h.click(a.tab, a.x, a.y, a); return withShot(h, a.tab, `클릭 (${a.x}, ${a.y})`); },
  move: async (h, a) => { await h.move(a.tab, a.x, a.y); return withShot(h, a.tab, `이동 (${a.x}, ${a.y})`); },
  type_text: async (h, a) => { await h.type(a.tab, a.text); return withShot(h, a.tab, "입력함"); },
  key: async (h, a) => { await h.key(a.tab, a.combo); return withShot(h, a.tab, "키: " + a.combo); },
  scroll: async (h, a) => { await h.scroll(a.tab, a.x, a.y, a.dy); return withShot(h, a.tab, "스크롤 " + a.dy); },
};

async function handle(req) {
  switch (req.method) {
    case "initialize":
      return {
        protocolVersion: req.params?.protocolVersion || "2025-06-18",
        capabilities: { tools: {} },
        serverInfo: { name: `${BROWSER}-hand`, version: "0.2.0" },
      };
    case "tools/list":
      return { tools: TOOLS };
    case "tools/call": {
      const run = RUN[req.params.name];
      if (!run) throw new Error("모르는 도구: " + req.params.name);
      try {
        return { content: await run(await getHand(), req.params.arguments || {}) };
      } catch (err) {
        return { content: [{ type: "text", text: "오류: " + err.message }], isError: true };
      }
    }
    case "ping":
      return {};
    default:
      throw Object.assign(new Error("지원하지 않는 요청: " + req.method), { code: -32601 });
  }
}

// 끝날 때 연결을 닫는다(토르는 통로 세션을 하나만 받으므로 특히 중요).
async function shutdown() {
  await hand?.close();
  await chromeHand?.close();
  process.exit(0);
}
process.stdin.on("end", shutdown);
process.on("SIGINT", shutdown);
process.on("SIGTERM", shutdown);

const reply = (obj) => process.stdout.write(JSON.stringify({ jsonrpc: "2.0", ...obj }) + "\n");

createInterface({ input: process.stdin }).on("line", async (line) => {
  if (!line.trim()) return;
  let req;
  try { req = JSON.parse(line); } catch { return; }
  if (req.id === undefined) return; // 알림은 답하지 않는다
  try {
    reply({ id: req.id, result: await handle(req) });
  } catch (err) {
    reply({ id: req.id, error: { code: err.code || -32603, message: err.message } });
  }
});
