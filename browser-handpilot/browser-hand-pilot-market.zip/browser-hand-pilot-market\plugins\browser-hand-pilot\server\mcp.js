// Claude 도구 창구: MCP(표준입출력, JSON-RPC 한 줄씩)로 도구 목록을 알려 주고 요청을 손·눈에 넘긴다.
// 외부 패키지 없이 직접 구현한다. 실행 인자로 브라우저를 고른다: node server/mcp.js tor | chrome
// 사진은 common/eyes.js가 줄이고, 동작 뒤에는 바뀐 부분만 잘라 보낸다(토큰 절약).
import { createInterface } from "node:readline";
import { readFileSync } from "node:fs";
import { openSession } from "../tor/launch.js";
import { Hand } from "../tor/actions.js";
import { ChromeHand } from "../chrome/actions.js";
import { ExtensionLink } from "../chrome/wsserver.js";
import { openDedicated } from "../chrome/launch.js";
import { config, refreshConfig } from "../tor/config.js";
import { Eyes } from "../common/eyes.js";
import { log } from "../common/log.js";
import { win32 } from "node:path";
import { beginAction, stopWatcher, setStopFilter, StoppedError } from "../common/stopkey.js";

const BROWSER = process.argv[2] === "chrome" ? "chrome" : "tor";
const BROWSER_NAME = BROWSER === "chrome" ? "크롬" : "토르";
const VERSION = JSON.parse(readFileSync(new URL("../package.json", import.meta.url), "utf8")).version;

// 이번 호출이 쓰는 손과 눈
let hand = null;
let eyes = null;
// 토르
let tor = null, torEyes = null;
// 크롬: 두 크롬의 확장이 같은 연결 창구(link)에 붙는다.
// 기본은 Claude 전용 크롬(ded, 도구가 띄움). 로그인된 사용자 크롬(usr)은 사용자가 승인했을 때만. 사용자 크롬 탭 id는 u로 시작.
let link = null;
let ded = null, dedEyes = null;
let usr = null, usrEyes = null;
let lastChromePort = null; // 쉬었다 다시 잡을 때 같은 포트(= 같은 탭 그룹 번호)를 먼저 시도
const isUserChromeTab = (tab) => /^u\d+$/.test(String(tab ?? ""));
const NEED_EXTENSION = "전용 크롬에 브라우저파일럿 확장이 연결되지 않았습니다. 사용자에게 안내하세요: 오른쪽 아래 전용 크롬 창에서 " +
  "chrome://extensions → 개발자 모드 → '압축해제된 확장 프로그램 로드' → 설치 폴더의 extension 폴더, 그리고 세부정보에서 '시크릿 모드에서 허용'(처음 한 번).";

let linkStarted = 0;
async function useLink() {
  if (!link) {
    link = new ExtensionLink(config.chromePort, config.chromePortCount, config.chromeExtensionId, lastChromePort);
    await link.start();
    linkStarted = Date.now();
    ded = new ChromeHand(link, "dedicated");
    usr = new ChromeHand(link, "user");
    dedEyes = new Eyes(ded, "크롬 탭");
    usrEyes = new Eyes(usr, "사용자 크롬 탭");
  }
  return link;
}

// 전용 크롬 확장이 붙어 있지 않으면 전용 크롬을 띄운다(이미 떠 있으면 확인 페이지 탭만 열려 확장을 깨운다).
async function useDedicated(launch) {
  await useLink();
  // 막 연 창구면 이미 떠 있는 전용 크롬의 확장이 붙는 중일 수 있다(확장은 5초마다 다시 붙어 봄)
  const wait = Math.max(0, linkStarted + 6000 - Date.now());
  if (!link.isConnected("dedicated") && wait) await link.waitConnected("dedicated", wait, "").catch(() => {});
  if (!link.isConnected("dedicated") && launch) {
    openDedicated([link.claimUrl]);
    try {
      await link.waitConnected("dedicated", 15000, NEED_EXTENSION);
    } catch (err) {
      openDedicated(["chrome://extensions"]); // 확장이 없을 때 올릴 화면을 열어 둔다
      throw err;
    }
  }
  return [ded, dedEyes];
}

async function useUser() {
  await useLink();
  await link.waitConnected("user", config.chromeConnectTimeoutMs,
    "사용자 크롬에 브라우저파일럿 확장이 연결되지 않았습니다. 사용자 크롬이 켜져 있고 확장이 올라가 있는지 확인해 달라고 하세요.");
  return [usr, usrEyes];
}

// new_tab의 mode: private(기본) | saved | user. 예전 이름 normal=true는 user.
const tabMode = (a) => (a.mode === "saved" || a.mode === "user" ? a.mode : a.normal ? "user" : "private");

async function getHand(name, args) {
  if (BROWSER === "chrome") {
    const user = name === "new_tab" ? tabMode(args) === "user" : isUserChromeTab(args.tab);
    [hand, eyes] = user ? await useUser() : await useDedicated(name !== "tabs");
    return hand;
  }
  if (!tor || !tor.connected) {
    tor = new Hand(await openSession());
    torEyes = new Eyes(tor, "토르 탭");
  }
  [hand, eyes] = [tor, torEyes];
  return hand;
}

const tab = { type: "string", description: "탭 id (tabs 도구로 확인)" };
const num = (d) => ({ type: "number", description: d });
const observe = { type: "boolean", description: "false면 사진 없이 동작만(여러 동작을 이어 할 때). 기본 true" };

const TOOLS = [
  {
    name: "tabs",
    description: `${BROWSER_NAME}에서 이 채팅이 쓰는 탭 목록. 사용자 탭은 개수만 알려 준다(all=true면 사용자 탭의 번호·사이트 이름만).${BROWSER === "tor" ? " 토르가 꺼져 있으면 띄운다." : ""}`,
    inputSchema: { type: "object", properties: { all: { type: "boolean" } } },
  },
  {
    name: "new_tab",
    description: "새 탭을 연다. url을 주면 그 주소로 간다." +
      (BROWSER === "chrome" ? " 크롬은 Claude 전용 크롬(사용자 크롬과 따로 도는 창, 화면 오른쪽 아래)에 연다. mode: 'private'(기본, 시크릿 창이라 기록 안 남음), " +
        "'saved'(전용 크롬 일반 창. 사용자가 그 창에서 로그인해 둔 사이트는 로그인 유지), 'user'(사용자의 평소 크롬, 로그인 상태. 사용자가 승인했을 때만)." : ""),
    inputSchema: {
      type: "object",
      properties: {
        url: { type: "string" },
        ...(BROWSER === "chrome" && {
          mode: { type: "string", enum: ["private", "saved", "user"], description: "기본 private. user는 사용자 승인 뒤에만" },
        }),
      },
    },
  },
  { name: "navigate", description: "탭을 주소로 이동하고 전체 사진을 돌려준다.", inputSchema: { type: "object", properties: { tab, url: { type: "string" } }, required: ["tab", "url"] } },
  {
    name: "screenshot",
    description: "그 탭을 본다. mode='auto'(기본): 마지막으로 본 것과 비교해 바뀐 부분만, mode='full': 전체. 좌표는 '탭 사진'(긴 변 약 1280px) 기준.",
    inputSchema: { type: "object", properties: { tab, mode: { type: "string", enum: ["auto", "full"] } }, required: ["tab"] },
  },
  {
    name: "zoom",
    description: "탭 사진의 한 부분(x,y,w,h 사진 좌표)을 원본 화질로 확대해 본다. 작은 글씨가 뭉개져 보이면 추측하지 말고 쓴다.",
    inputSchema: { type: "object", properties: { tab, x: num("사진 x"), y: num("사진 y"), w: num("폭"), h: num("높이") }, required: ["tab", "x", "y", "w", "h"] },
  },
  { name: "click", description: "그 탭 안 사진 좌표를 클릭한다. 진짜 마우스는 움직이지 않는다. 화면 크기가 바뀌었으면 누르지 않고 새 사진을 준다.", inputSchema: { type: "object", properties: { tab, x: num("사진 x"), y: num("사진 y"), button: { type: "string", enum: ["left", "right", "middle"] }, double: { type: "boolean" }, observe }, required: ["tab", "x", "y"] } },
  { name: "move", description: "그 탭 안에서 마우스를 옮긴다(마우스 올림 효과).", inputSchema: { type: "object", properties: { tab, x: num("사진 x"), y: num("사진 y"), observe }, required: ["tab", "x", "y"] } },
  { name: "type_text", description: "그 탭에 글자를 입력한다.", inputSchema: { type: "object", properties: { tab, text: { type: "string" }, observe }, required: ["tab", "text"] } },
  { name: "key", description: "키를 누른다. 예: Enter, Tab, Ctrl+A, Shift+Tab", inputSchema: { type: "object", properties: { tab, combo: { type: "string" }, observe }, required: ["tab", "combo"] } },
  { name: "scroll", description: "사진 좌표 위치에서 스크롤한다. dy는 사진 픽셀, >0 아래로.", inputSchema: { type: "object", properties: { tab, x: num("사진 x"), y: num("사진 y"), dy: num("사진 픽셀"), observe }, required: ["tab", "x", "y", "dy"] } },
];

const site = (url) => { try { return new URL(url).hostname || url.split(":")[0]; } catch { return "?"; } };

// 이 채팅 탭만 자세히, 사용자 탭은 개수(또는 번호·사이트 이름)만 — 다른 탭 제목에 개인정보가 있을 수 있다.
function tabLines(list, all, head, othersLabel = "사용자 탭") {
  const mine = list.filter((t) => t.mine).map(({ id, url, title, incognito }) => ({ id, url, title, incognito }));
  const others = list.filter((t) => !t.mine && !t.otherChat);
  const otherChats = list.filter((t) => t.otherChat).length;
  const lines = [
    `${head} 작업은 아래 '이 채팅 탭'에서 하고, 새로 필요하면 new_tab.`,
    `이 채팅 탭 ${mine.length}개: ${JSON.stringify(mine)}`,
    `${othersLabel} ${others.length}개${all ? ": " + JSON.stringify(others.map((t) => ({ id: t.id, site: site(t.url) }))) : ` (all=true면 번호·사이트 이름만 보임. ${othersLabel}은 사용자 확인 뒤에만 조작)`}`,
  ];
  if (otherChats) lines.push(`다른 채팅 탭 ${otherChats}개(건드리지 말 것)`);
  return lines;
}

// 크롬: 전용 크롬 탭을 먼저, 사용자 크롬은 확장이 붙어 있을 때만 붙여 보여 준다. 크롬을 새로 띄우지는 않는다.
async function chromeTabs(all) {
  const lines = [];
  if (link.isConnected("dedicated")) {
    lines.push(...tabLines(await ded.tabs(), all,
      `Claude 전용 크롬(사용자 크롬과 따로 도는 창, 화면 오른쪽 아래, incognito=true는 기록 안 남는 창) — 이 채팅의 탭 그룹: BrowserPilot ${link.slotNumber}.`,
      "전용 크롬의 그룹 밖 탭"));
  } else {
    lines.push("Claude 전용 크롬이 아직 연결되지 않았습니다. new_tab을 하면 띄웁니다.");
  }
  if (link.isConnected("user")) {
    lines.push("", ...tabLines(await usr.tabs(), all, "사용자 크롬(평소 크롬, 로그인 상태) — new_tab mode='user'로 연 탭만 이 채팅 탭."));
  } else {
    lines.push("로그인된 사용자 크롬이 꼭 필요하면 사용자 승인 뒤 new_tab mode='user'(사용자 크롬에 확장 필요).");
  }
  return [{ type: "text", text: lines.join("\n") }];
}

const head = (s) => `${s}`;
const RUN = {
  tabs: async (h, a) => (BROWSER === "chrome" ? chromeTabs(a.all)
    : [{ type: "text", text: tabLines(await h.tabs(), a.all, "토르: 항상 기록이 남지 않는 창이고, 한 번에 한 채팅만 쓸 수 있음.").join("\n") }]),
  new_tab: async (h, a) => {
    if (BROWSER !== "chrome") return [{ type: "text", text: "새 탭 id: " + (await h.newTab(a.url)) }];
    const mode = tabMode(a);
    const where = { private: "Claude 전용 크롬 시크릿 창, 기록 안 남음", saved: "Claude 전용 크롬 일반 창", user: "사용자 크롬" }[mode];
    return [{ type: "text", text: `새 탭 id: ${await h.newTab(a.url, mode)} (${where})` }];
  },
  navigate: async (h, a) => {
    await h.navigate(a.tab, a.url);
    eyes.forget(a.tab);
    return eyes.look(a.tab, "full").then((c) => { c[0].text = "이동함\n" + c[0].text; return c; });
  },
  screenshot: async (h, a) => eyes.look(a.tab, a.mode),
  zoom: async (h, a) => eyes.zoom(a.tab, a.x, a.y, a.w, a.h),
  click: async (h, a) => eyes.act(a.tab, head(`클릭 (${a.x}, ${a.y})`), { observe: a.observe !== false, coords: true }, async (f) => {
    const p = eyes.toCss(f, a.x, a.y);
    await h.click(a.tab, p.x, p.y, a);
  }),
  move: async (h, a) => eyes.act(a.tab, `이동 (${a.x}, ${a.y})`, { observe: a.observe !== false, coords: true }, async (f) => {
    const p = eyes.toCss(f, a.x, a.y);
    await h.move(a.tab, p.x, p.y);
  }),
  type_text: async (h, a) => eyes.act(a.tab, "입력함", { observe: a.observe !== false }, () => h.type(a.tab, a.text)),
  key: async (h, a) => eyes.act(a.tab, "키: " + a.combo, { observe: a.observe !== false }, () => h.key(a.tab, a.combo)),
  scroll: async (h, a) => eyes.act(a.tab, "스크롤 " + a.dy, { observe: a.observe !== false, coords: true }, async (f) => {
    const p = eyes.toCss(f, a.x, a.y);
    await h.scroll(a.tab, p.x, p.y, a.dy / f.r / f.dev);
  }),
};

async function handle(req) {
  switch (req.method) {
    case "initialize":
      return {
        protocolVersion: req.params?.protocolVersion || "2025-06-18",
        capabilities: { tools: {} },
        serverInfo: { name: `${BROWSER}-hand`, version: VERSION },
      };
    case "tools/list":
      return { tools: TOOLS };
    case "tools/call": {
      const run = RUN[req.params.name];
      if (!run) throw new Error("모르는 도구: " + req.params.name);
      refreshConfig();
      const started = Date.now();
      try {
        if (req.params.name !== "tabs") beginAction(); // 정지 키를 눌렀으면 여기서 거절
        const args = req.params.arguments || {};
        const content = await run(await getHand(req.params.name, args), args);
        const images = content.filter((c) => c.type === "image").length;
        log("info", `${req.params.name} ${Date.now() - started}ms 이미지 ${images}장`);
        return { content };
      } catch (err) {
        if (err instanceof StoppedError) return { content: [{ type: "text", text: "⏹ " + err.message }], isError: true };
        log("error", `${req.params.name}: ${err.message}`);
        return { content: [{ type: "text", text: "오류: " + err.message }], isError: true };
      }
    }
    case "ping":
      return {};
    default:
      throw Object.assign(new Error("지원하지 않는 요청: " + req.method), { code: -32601 });
  }
}

// 정지 키는 누른 순간 맨 앞 프로그램이 이 채팅이 일하는 브라우저일 때만 받는다(바탕화면·다른 프로그램의 키는 무시).
// 크롬은 두 크롬(전용·사용자)의 확장에 "지금 맨 앞 창의 보이는 탭이 이 채팅 탭인가"를 물어, 여러 채팅 중 그 탭의 채팅만 멈춘다.
setStopFilter(async (exe) => {
  if (!exe) return false;
  if (BROWSER === "tor") return !!config.torExe && exe.toLowerCase() === config.torExe.toLowerCase();
  if (win32.basename(exe).toLowerCase() !== "chrome.exe" || !link) return false;
  for (const role of ["dedicated", "user"]) {
    if (!link.isConnected(role)) continue;
    const r = await link.send("focusedTab", {}, role).catch(() => null);
    if (r?.focused) return r.mine;
  }
  return false;
});

// 끝날 때 연결을 닫는다(토르는 통로 세션을 하나만 받으므로 특히 중요).
async function shutdown() {
  stopWatcher();
  link?.close();
  await tor?.close().catch(() => {});
  process.exit(0);
}
process.stdin.on("end", shutdown);
process.on("SIGINT", shutdown);
process.on("SIGTERM", shutdown);

// 쉬면 브라우저 쪽만 놓는다: 크롬은 포트를 닫으면 두 크롬의 확장이 이 채팅 탭의 디버거를 떼고(노란 띠 사라짐),
// 토르는 통로 세션을 끝내 다른 채팅이 쓸 수 있게 한다. 전용 크롬 창은 그대로 둔다(다른 채팅도 같이 씀).
// 도구 서버는 켜 둔다(꺼지면 Claude Code가 다시 켜 주지 않음). 채팅이 닫히면 stdin이 끝나 바로 꺼지고,
// 아주 오래 안 쓰면 안전망으로 꺼진다. 자동 업데이트는 '도구 서버 0개'일 때 설치한다.
async function release() {
  stopWatcher();
  if (!link && !tor) return;
  log("info", "쉬는 중이라 브라우저 연결을 놓음");
  if (link) {
    lastChromePort = link.port;
    link.close();
  }
  const oldTor = tor;
  link = ded = dedEyes = usr = usrEyes = tor = torEyes = hand = eyes = null;
  await oldTor?.close().catch(() => {});
}

let releaseTimer = null;
let exitTimer = null;
function touch() {
  clearTimeout(releaseTimer);
  clearTimeout(exitTimer);
  releaseTimer = setTimeout(release, config.releaseIdleMs);
  exitTimer = setTimeout(() => { log("info", "오래 안 써서 종료"); shutdown(); }, config.exitIdleMs);
}
touch();

const reply = (obj) => process.stdout.write(JSON.stringify({ jsonrpc: "2.0", ...obj }) + "\n");

createInterface({ input: process.stdin }).on("line", async (line) => {
  if (!line.trim()) return;
  let req;
  try { req = JSON.parse(line); } catch { return; }
  touch();
  if (req.id === undefined) return; // 알림은 답하지 않는다
  try {
    reply({ id: req.id, result: await handle(req) });
  } catch (err) {
    reply({ id: req.id, error: { code: err.code || -32603, message: err.message } });
  }
  touch();
});
