// 상태 점검: 항목마다 상태(ok·warn·bad·info), 한 줄 설명, 고치는 법 한 줄을 돌려준다.
import { existsSync, readFileSync, readdirSync } from "node:fs";
import { join } from "node:path";
import { connect } from "node:net";
import { execFile } from "node:child_process";
import { promisify } from "node:util";
import { config, DEFAULTS, homeDir, configPath, localConfigPath, secretPath, refreshConfig } from "../../tor/config.js";
import { ExtensionLink } from "../../chrome/wsserver.js";

const run = promisify(execFile);
const pluginDir = new URL("../../", import.meta.url);
export const localVersion = () => JSON.parse(readFileSync(new URL("package.json", pluginDir), "utf8")).version;
export const VERSION_URL = "https://gobong-choi.github.io/Gobongs/browser-handpilot/version.json";

const item = (name, status, desc, fix = "") => ({ name, status, desc, fix });

function portOpen(port) {
  return new Promise((resolve) => {
    const s = connect({ host: "127.0.0.1", port, timeout: 800 });
    s.on("connect", () => { s.destroy(); resolve(true); });
    s.on("error", () => resolve(false));
    s.on("timeout", () => { s.destroy(); resolve(false); });
  });
}

export function findClaude() {
  const roots = [
    join(process.env.APPDATA || "", "Claude", "claude-code"),
    ...(() => {
      const base = join(process.env.LOCALAPPDATA || "", "Claude-Data");
      try { return readdirSync(base).map((d) => join(base, d, "claude-code")); } catch { return []; }
    })(),
  ];
  const found = [];
  for (const r of roots) {
    try {
      for (const v of readdirSync(r)) for (const h of readdirSync(join(r, v))) {
        const exe = join(r, v, h, "claude.exe");
        if (existsSync(exe)) found.push({ exe, v });
      }
    } catch { /* 없음 */ }
  }
  found.sort((a, b) => a.v.localeCompare(b.v, undefined, { numeric: true }));
  return found.at(-1)?.exe;
}

export async function remoteVersion() {
  const res = await fetch(VERSION_URL + "?t=" + Date.now(), { signal: AbortSignal.timeout(8000) });
  return (await res.json()).version;
}

const newer = (a, b) => a.localeCompare(b, undefined, { numeric: true }) > 0;

export async function runChecks() {
  refreshConfig();
  const out = [];
  const major = Number(process.versions.node.split(".")[0]);
  out.push(major >= 18 ? item("Node.js", "ok", process.version) : item("Node.js", "bad", process.version + " (18 이상 필요)", "https://nodejs.org 에서 LTS 설치"));

  try {
    const shared = JSON.parse(readFileSync(configPath, "utf8"));
    const local = existsSync(localConfigPath) ? JSON.parse(readFileSync(localConfigPath, "utf8")) : {};
    const unknown = Object.keys({ ...shared, ...local }).filter((k) => !(k in DEFAULTS));
    out.push(unknown.length
      ? item("설정 파일", "warn", "모르는 항목: " + unknown.join(", "), "설정 탭에서 [기본값으로]를 누르거나 철자 확인")
      : item("설정 파일", "ok", `공용 + 이 PC 값 ${Object.keys(local).length}개`));
  } catch (err) {
    out.push(item("설정 파일", "bad", "읽기 실패: " + err.message, "설치 스크립트를 다시 실행"));
  }

  out.push(existsSync(secretPath) ? item("비밀 암호", "ok", "있음") : item("비밀 암호", "bad", "없음", "설치 스크립트를 다시 실행한 뒤 크롬 확장 새로고침"));

  try {
    const ext = JSON.parse(readFileSync(join(homeDir, "extension", "manifest.json"), "utf8")).version;
    out.push(ext === localVersion()
      ? item("크롬 확장 파일", "ok", `버전 ${ext}`)
      : item("크롬 확장 파일", "warn", `확장 ${ext} / 도구 ${localVersion()}`, "설치 스크립트를 다시 실행"));
  } catch {
    out.push(item("크롬 확장 파일", "bad", "확장 폴더 없음", "설치 스크립트를 다시 실행"));
  }

  // 빈 포트에 잠깐 창구를 열고 두 크롬(전용·평소)의 확장이 암호를 맞춰 붙는지 본다. 크롬을 새로 띄우지는 않는다.
  const link = new ExtensionLink(config.chromePort, config.chromePortCount, config.chromeExtensionId);
  try {
    await link.start();
    await Promise.all([
      link.waitConnected("dedicated", 8000, "").catch(() => {}),
      link.waitConnected("user", 8000, "").catch(() => {}),
    ]);
    out.push(link.isConnected("dedicated")
      ? item("전용 크롬 연결", "ok", `확장이 암호 확인을 통과함(포트 ${link.port})`)
      : item("전용 크롬 연결", "info", "연결 안 됨(전용 크롬이 꺼져 있으면 정상, Claude가 쓸 때 띄움)",
        "켜져 있는데도 안 되면 전용 크롬 창의 chrome://extensions에서 확장이 켜져 있는지, ID가 " + config.chromeExtensionId + " 인지 확인"));
    out.push(link.isConnected("user")
      ? item("평소 크롬 연결", "ok", "확장이 암호 확인을 통과함(로그인 상태로 일 시킬 때만 씀)")
      : item("평소 크롬 연결", "info", "연결 안 됨(평소 크롬에 확장을 안 올렸으면 정상)"));
  } catch (err) {
    out.push(item("크롬 연결", "warn", err.message.slice(0, 120), "크롬 도구를 쓰는 채팅을 줄인 뒤 다시"));
  } finally {
    link.close();
  }

  out.push(config.torExe && existsSync(config.torExe)
    ? item("토르 위치", "ok", config.torExe)
    : item("토르 위치", "info", config.torExe ? "파일 없음: " + config.torExe : "정하지 않음(토르를 안 쓰면 무시)", "설정 탭에서 토르의 Browser\\firefox.exe 경로 입력"));
  out.push((await portOpen(config.port))
    ? item("토르 통로", "info", `열려 있음(포트 ${config.port}) — 토르가 켜져 있음. 다 쓰면 토르 창을 닫으세요`)
    : item("토르 통로", "ok", "닫혀 있음(쓸 때 도구가 띄움)"));

  const claude = findClaude();
  if (!claude) out.push(item("플러그인 등록", "bad", "Claude Code를 찾지 못함", "Claude 앱 설치 후 Code 탭을 한 번 열기"));
  else {
    try {
      const { stdout } = await run(claude, ["plugin", "list"], { timeout: 20000, windowsHide: true });
      const m = stdout.match(/browser-hand-pilot@[^\s]+[\s\S]*?Version:\s*([\d.]+)[\s\S]*?Status:\s*(.+)/);
      out.push(m
        ? item("플러그인 등록", m[1] === localVersion() ? "ok" : "warn", `버전 ${m[1]}, ${m[2].trim()}`, m[1] === localVersion() ? "" : "설치 스크립트를 다시 실행")
        : item("플러그인 등록", "bad", "등록 안 됨", "설치 스크립트를 다시 실행"));
    } catch (err) {
      out.push(item("플러그인 등록", "warn", "확인 실패: " + err.message.slice(0, 80)));
    }
  }

  try {
    const { stdout } = await run("powershell", ["-NoProfile", "-Command",
      "(Get-CimInstance Win32_Process -Filter \"Name='node.exe'\" | Where-Object { $_.CommandLine -match 'server[\\\\/]mcp\\.js' }).Count"], { timeout: 15000, windowsHide: true });
    const n = Number(stdout.trim() || 0);
    out.push(item("실행 중인 도구 서버", "info", `${n}개 (채팅마다 크롬·토르 하나씩, 10분 안 쓰면 스스로 꺼짐)`));
  } catch { /* 생략 */ }

  try {
    const dir = join(homeDir, "logs");
    const since = Date.now() - 86400000;
    let errors = 0;
    for (const f of existsSync(dir) ? readdirSync(dir) : []) {
      for (const line of readFileSync(join(dir, f), "utf8").split("\n")) {
        if (line.includes(" ERROR ") && Date.parse(line.slice(0, 24)) >= since) errors++;
      }
    }
    out.push(errors ? item("최근 24시간 오류", "warn", `${errors}건`, "로그 탭에서 '오류만'으로 확인") : item("최근 24시간 오류", "ok", "없음"));
  } catch { /* 생략 */ }

  try {
    const remote = await remoteVersion();
    out.push(newer(remote, localVersion())
      ? item("업데이트", "warn", `새 버전 ${remote} (지금 ${localVersion()})`, "정보 탭의 [지금 업데이트]")
      : item("업데이트", "ok", `최신 ${localVersion()}`));
  } catch {
    out.push(item("업데이트", "info", "확인 실패(인터넷 연결 확인)"));
  }

  try {
    await run("schtasks", ["/Query", "/TN", "BrowserHandPilotUpdate"], { windowsHide: true });
    out.push(item("자동 업데이트", "ok", "켜짐(매주 월요일 10시 확인)"));
  } catch {
    out.push(item("자동 업데이트", "info", "꺼짐", "정보 탭에서 켤 수 있음"));
  }
  return out;
}
