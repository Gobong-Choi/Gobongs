// 브라우저파일럿 관리 페이지: 이 PC 안(127.0.0.1)에서만 열리는 작은 웹 서버.
// 실행마다 바뀌는 열쇠(token)를 주소에 넣어 열고, API는 같은 열쇠와 Host·Origin을 확인한다(다른 사이트가 못 부르게).
// 페이지가 30초 넘게 신호를 안 보내면 스스로 꺼진다. 이미 떠 있으면 open-admin.ps1이 그 주소를 다시 연다(admin.json).
// 실행: node tools/admin/server.js  (시작 메뉴 '브라우저파일럿 관리'가 대신 실행)
import { createServer } from "node:http";
import { randomBytes } from "node:crypto";
import { readFileSync, writeFileSync, renameSync, existsSync, readdirSync, unlinkSync } from "node:fs";
import { join } from "node:path";
import { spawn, execFile } from "node:child_process";
import { fileURLToPath } from "node:url";
import { DEFAULTS, homeDir, localConfigPath, sharedConfig, refreshConfig, config } from "../../tor/config.js";
import { runChecks, localVersion, remoteVersion } from "./checks.js";

const token = randomBytes(16).toString("hex");
const adminFile = join(homeDir, "admin.json");
const toolsDir = fileURLToPath(new URL("..", import.meta.url));
let lastBeat = Date.now();

// 설정 항목 설명(관리 페이지에 보임). 여기 없는 키는 화면에 안 나온다.
const FIELDS = [
  ["torExe", "토르 위치", "토르 폴더의 Browser\\firefox.exe 전체 경로"],
  ["chromeExe", "크롬 위치", "비우면 기본 설치 위치에서 찾음. Claude 전용 크롬을 띄울 chrome.exe 전체 경로"],
  ["chromeProfileDir", "전용 크롬 프로필 폴더", "비우면 설치 폴더\\chrome-profile. 바꾸면 확장을 그 프로필에 다시 올려야 함"],
  ["chromeWindowWidth", "Claude 창 가로(px)", "화면 오른쪽 아래 구석에 놓이는 창 크기"],
  ["chromeWindowHeight", "Claude 창 세로(px)", ""],
  ["stopKey", "정지 키", "누르면 브라우저파일럿이 바로 멈춤. Escape, Pause, ScrollLock, F12 중 하나(바꾸면 새 채팅부터)"],
  ["stopHoldMs", "정지 유지 시간(ms)", "정지 키를 누른 뒤 이 시간 동안 모든 동작 거절"],
  ["maxImage", "탭 사진 크기(긴 변 px)", "작을수록 토큰 절약, 클수록 선명. 1000~1600"],
  ["zoomMax", "확대 사진 크기(긴 변 px)", ""],
  ["fullEvery", "전체 사진 주기", "잘린 결과를 이만큼 보내면 한 번은 전체"],
  ["stableMs", "화면 멈춤 판정(ms)", "마지막 변화 뒤 이만큼 그대로면 멈춘 것"],
  ["noChangeMs", "변화 없음 판정(ms)", ""],
  ["settleMaxMs", "최대 대기(ms)", "움직이는 화면이어도 이만큼 뒤엔 찍음"],
  ["loadWaitMs", "페이지 로딩 대기(ms)", "크롬"],
  ["chromeConnectTimeoutMs", "크롬 확장 연결 대기(ms)", ""],
  ["releaseIdleMs", "쉬면 연결 놓기(ms)", "안 쓰면 크롬 포트·디버거·토르 통로를 놓음(다음 호출 때 다시 잡음)"],
  ["exitIdleMs", "도구 서버 자동 종료(ms)", "안전망. 채팅을 닫으면 그때 바로 꺼짐"],
];

function readLocal() {
  return existsSync(localConfigPath) ? JSON.parse(readFileSync(localConfigPath, "utf8")) : {};
}

// 기본값·공용과 다른 값만 config.local.json에 저장한다(임시 파일 → 이름 바꾸기).
function saveLocal(values) {
  const shared = sharedConfig();
  const local = readLocal();
  for (const [k, v] of Object.entries(values)) {
    if (!(k in DEFAULTS)) continue;
    const typed = typeof DEFAULTS[k] === "number" ? Number(v) : String(v);
    if (typeof DEFAULTS[k] === "number" && !Number.isFinite(typed)) throw new Error(`${k}: 숫자가 아닙니다`);
    if (typed === shared[k]) delete local[k];
    else local[k] = typed;
  }
  if (!Object.keys(local).length) {
    if (existsSync(localConfigPath)) unlinkSync(localConfigPath);
    return 0;
  }
  const tmp = localConfigPath + ".tmp";
  writeFileSync(tmp, JSON.stringify(local, null, 2) + "\n");
  renameSync(tmp, localConfigPath);
  return Object.keys(local).length;
}

function readLogs(errorsOnly) {
  const dir = join(homeDir, "logs");
  if (!existsSync(dir)) return [];
  const files = readdirSync(dir).sort().slice(-3);
  const lines = files.flatMap((f) => readFileSync(join(dir, f), "utf8").split("\n").filter(Boolean));
  return (errorsOnly ? lines.filter((l) => / (ERROR|WARN) /.test(l)) : lines).slice(-300);
}

function updateScript(args) {
  return spawn("powershell", ["-NoProfile", "-WindowStyle", "Hidden", "-ExecutionPolicy", "Bypass", "-File", join(toolsDir, "update.ps1"), ...args],
    { detached: true, stdio: "ignore", windowsHide: true }).unref();
}

function json(res, code, obj) {
  res.writeHead(code, { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store" });
  res.end(JSON.stringify(obj));
}

async function body(req) {
  let s = "";
  for await (const c of req) s += c;
  return s ? JSON.parse(s) : {};
}

const server = createServer(async (req, res) => {
  const host = `127.0.0.1:${server.address().port}`;
  // Host 확인: 다른 이름으로 가장한 요청(DNS 리바인딩) 막기. Origin이 있으면 우리 주소여야 한다.
  if (req.headers.host !== host || (req.headers.origin && req.headers.origin !== `http://${host}`)) return json(res, 403, { error: "forbidden" });
  const url = new URL(req.url, `http://${host}`);
  if (url.pathname === "/") {
    if (url.searchParams.get("t") !== token) return json(res, 403, { error: "열쇠가 없습니다. 시작 메뉴로 다시 여세요." });
    res.writeHead(200, { "Content-Type": "text/html; charset=utf-8", "Cache-Control": "no-store", "Content-Security-Policy": "default-src 'self' 'unsafe-inline'" });
    return res.end(readFileSync(new URL("page.html", import.meta.url), "utf8").replace("__TOKEN__", token));
  }
  if (req.headers["x-token"] !== token) return json(res, 403, { error: "forbidden" });
  lastBeat = Date.now();
  try {
    switch (`${req.method} ${url.pathname}`) {
      case "GET /api/ping": return json(res, 200, { ok: true });
      case "GET /api/checks": return json(res, 200, await runChecks());
      case "GET /api/config": {
        refreshConfig();
        const shared = sharedConfig(), local = readLocal();
        return json(res, 200, FIELDS.map(([key, label, hint]) => ({ key, label, hint, value: config[key], base: shared[key], changed: key in local })));
      }
      case "POST /api/config": return json(res, 200, { changed: saveLocal(await body(req)) });
      case "POST /api/config/reset": if (existsSync(localConfigPath)) unlinkSync(localConfigPath); return json(res, 200, { ok: true });
      case "GET /api/logs": return json(res, 200, readLogs(url.searchParams.get("errors") === "1"));
      case "GET /api/info": {
        let remote = null;
        try { remote = await remoteVersion(); } catch { /* 오프라인 */ }
        let auto = false;
        await new Promise((r) => execFile("schtasks", ["/Query", "/TN", "BrowserHandPilotUpdate"], { windowsHide: true }, (e) => { auto = !e; r(); }));
        return json(res, 200, { version: localVersion(), remote, home: homeDir, auto });
      }
      case "POST /api/update": updateScript(["-Now"]); return json(res, 200, { started: true });
      case "POST /api/auto": updateScript([(await body(req)).on ? "-Register" : "-Unregister"]); return json(res, 200, { ok: true });
      case "POST /api/open": {
        const what = (await body(req)).what;
        const target = what === "logs" ? join(homeDir, "logs") : what === "extension" ? join(homeDir, "extension") : homeDir;
        spawn("explorer.exe", [target], { detached: true, stdio: "ignore" }).unref();
        return json(res, 200, { ok: true });
      }
      default: return json(res, 404, { error: "없음" });
    }
  } catch (err) {
    return json(res, 500, { error: err.message });
  }
});

server.listen(0, "127.0.0.1", () => {
  const { port } = server.address();
  writeFileSync(adminFile, JSON.stringify({ port, token, pid: process.pid }) + "\n");
  console.log(`http://127.0.0.1:${port}/?t=${token}`);
});

// 페이지가 닫혀 신호가 끊기면 스스로 끈다
setInterval(() => {
  if (Date.now() - lastBeat > 30000) {
    try { unlinkSync(adminFile); } catch { /* 이미 없음 */ }
    process.exit(0);
  }
}, 5000);
