// 시험용 도구 호출기: MCP 도구를 Claude 없이 직접 불러 본다. 사진은 출력 폴더에 저장한다.
// 실행: node tools/call.js <tor|chrome> <출력폴더> '<단계 JSON 배열>'
//   예: node tools/call.js tor ./out '[["tabs",{}],["screenshot",{"tab":"..."}]]'
// 한 번 실행하는 동안 같은 도구 서버를 쓰므로, 앞 단계에서 연 탭의 mine 표시가 뒤 단계에도 남는다.
import { spawn } from "node:child_process";
import { mkdirSync, writeFileSync } from "node:fs";
import { join } from "node:path";
import { createInterface } from "node:readline";
import { fileURLToPath } from "node:url";

const [browser, outDir, stepsJson] = process.argv.slice(2);
const steps = JSON.parse(stepsJson);
mkdirSync(outDir, { recursive: true });

const server = spawn(process.execPath, [fileURLToPath(new URL("../server/mcp.js", import.meta.url)), browser], {
  stdio: ["pipe", "pipe", "inherit"],
});
const waiting = new Map();
createInterface({ input: server.stdout }).on("line", (line) => {
  const msg = JSON.parse(line);
  waiting.get(msg.id)?.(msg);
});
let nextId = 0;
const request = (method, params) =>
  new Promise((resolve) => {
    const id = ++nextId;
    waiting.set(id, resolve);
    server.stdin.write(JSON.stringify({ jsonrpc: "2.0", id, method, params }) + "\n");
  });

await request("initialize", { protocolVersion: "2025-06-18" });
let failed = false;
for (const [i, [name, args]] of steps.entries()) {
  const started = Date.now();
  const res = await request("tools/call", { name, arguments: args });
  const content = res.result?.content || [];
  const texts = content.filter((c) => c.type === "text").map((c) => c.text);
  const img = content.find((c) => c.type === "image");
  let saved = "";
  if (img) {
    const file = join(outDir, `step${i + 1}-${name}.png`);
    const png = Buffer.from(img.data, "base64");
    writeFileSync(file, png);
    saved = ` 사진 ${png.readUInt32BE(16)}x${png.readUInt32BE(20)} → ${file}`;
  }
  const ok = !res.error && !res.result?.isError;
  if (!ok) failed = true;
  console.log(`[${i + 1}] ${name} ${ok ? "성공" : "실패"} (${Date.now() - started}ms)${saved}`);
  for (const t of texts) console.log("    " + t.replace(/\n/g, "\n    "));
  if (res.error) console.log("    오류: " + res.error.message);
}
server.stdin.end();
setTimeout(() => process.exit(failed ? 1 : 0), 1500);
