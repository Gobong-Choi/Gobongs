// 비밀 암호 만들기: 도구와 확장이 서로 확인할 무작위 암호를 extension/secret.js에 쓴다.
// 이 파일은 git과 배포 묶음에서 빠진다. 다시 만들면 크롬에서 확장을 새로고침해야 한다.
// 실행: node tools/make-secret.js            (개발 폴더 또는 BHP_HOME)
//       node tools/make-secret.js <폴더>     (그 폴더의 extension/secret.js)
import { randomBytes } from "node:crypto";
import { writeFileSync } from "node:fs";
import { join } from "node:path";
import { fileURLToPath } from "node:url";

const home = process.argv[2] || process.env.BHP_HOME || fileURLToPath(new URL("..", import.meta.url));
const file = join(home, "extension", "secret.js");
const token = randomBytes(32).toString("hex");
writeFileSync(file, `// 자동 생성 파일(tools/make-secret.js). 공유·커밋 금지.\nexport const SECRET = "${token}";\n`);
console.log(`${file} 를 만들었습니다. 크롬에서 확장을 새로고침하세요.`);
