﻿# 시작 메뉴에 '브라우저파일럿 관리' 바로가기를 만든다(setup.js가 부름).
# 대상은 MS 서명된 powershell.exe라 스마트 앱 컨트롤에 막히지 않고, 창을 숨겨 콘솔이 안 보인다.
param([Parameter(Mandatory)][string]$PluginDir)
$lnk = Join-Path ([Environment]::GetFolderPath("Programs")) "브라우저파일럿 관리.lnk"
$ws = New-Object -ComObject WScript.Shell
$s = $ws.CreateShortcut($lnk)
$s.TargetPath = Join-Path $env:SystemRoot "System32\WindowsPowerShell\v1.0\powershell.exe"
$s.Arguments = "-NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File `"$(Join-Path $PluginDir 'tools\open-admin.ps1')`""
$s.WorkingDirectory = $PluginDir
$s.Description = "브라우저파일럿 상태 점검·설정·로그·업데이트"
$s.IconLocation = "$env:SystemRoot\System32\shell32.dll,13"
$s.Save()
Write-Host "   시작 메뉴 바로가기: 브라우저파일럿 관리"
