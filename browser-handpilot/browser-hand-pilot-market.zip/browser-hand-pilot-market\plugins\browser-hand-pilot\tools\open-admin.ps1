﻿# 브라우저파일럿 관리 페이지 열기(시작 메뉴 바로가기가 실행). 이미 떠 있으면 그 주소를 다시 연다.
$ErrorActionPreference = "Stop"
$home2 = if ($env:BHP_HOME) { $env:BHP_HOME } else { Join-Path $env:USERPROFILE "BrowserHandPilot" }
$adminFile = Join-Path $home2 "admin.json"
$server = Join-Path $PSScriptRoot "admin\server.js"

function Open-If-Alive {
    if (-not (Test-Path $adminFile)) { return $false }
    $a = Get-Content $adminFile -Raw | ConvertFrom-Json
    try {
        Invoke-RestMethod -Uri "http://127.0.0.1:$($a.port)/api/ping" -Headers @{ "X-Token" = $a.token } -TimeoutSec 2 | Out-Null
        Start-Process "http://127.0.0.1:$($a.port)/?t=$($a.token)"
        return $true
    } catch { return $false }
}

if (Open-If-Alive) { exit 0 }
if (Test-Path $adminFile) { Remove-Item $adminFile -Force }
$node = (Get-Command node -ErrorAction SilentlyContinue).Source
if (-not $node) { $node = Join-Path $env:ProgramFiles "nodejs\node.exe" }
Start-Process -FilePath $node -ArgumentList "`"$server`"" -WindowStyle Hidden
for ($i = 0; $i -lt 40; $i++) {
    Start-Sleep -Milliseconds 250
    if (Open-If-Alive) { exit 0 }
}
Add-Type -AssemblyName PresentationFramework
[System.Windows.MessageBox]::Show("관리 페이지를 열지 못했습니다. Node.js가 설치돼 있는지 확인하세요.", "브라우저파일럿") | Out-Null
exit 1
