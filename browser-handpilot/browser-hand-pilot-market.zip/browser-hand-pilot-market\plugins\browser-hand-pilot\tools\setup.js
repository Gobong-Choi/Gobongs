// 새 컴퓨터 최초 설치: 사용자 폴더\BrowserHandPilot 에 크롬 확장·설정을 놓고 비밀 암호를 만든다.
// 플러그인 폴더에서 실행한다: node tools/setup.js
// 다시 실행하면 확장 코드만 새것으로 바꾸고, 설정(config.json)과 암호(secret.js)는 그대로 둔다.
import { cpSync, existsSync, mkdirSync, readFileSync, writeFileSync } from "node:fs";
import { join } from "node:path";
import { homedir } from "node:os";
import { fileURLToPath } from "node:url";
import { execFileSync } from "node:child_process";

const pluginDir = fileURLToPath(new URL("..", import.meta.url));
const home = process.env.BHP_HOME || join(homedir(), "BrowserHandPilot");
mkdirSync(home, { recursive: true });

// 1. 크롬 확장 복사(암호 파일은 덮어쓰지 않음)
const extDir = join(home, "extension");
const secretFile = join(extDir, "secret.js");
const oldSecret = existsSync(secretFile) ? readFileSync(secretFile) : null;
cpSync(join(pluginDir, "extension"), extDir, { recursive: true });
if (oldSecret) writeFileSync(secretFile, oldSecret);
console.log("1. 크롬 확장 폴더: " + extDir);

// 2. 비밀 암호
if (!oldSecret) {
  execFileSync(process.execPath, [join(pluginDir, "tools", "make-secret.js"), home], { stdio: "inherit" });
}
console.log("2. 비밀 암호: " + (oldSecret ? "기존 것 유지" : "새로 만듦"));

// 3. 설정과 토르 위치
const configFile = join(home, "config.json");
if (!existsSync(configFile)) {
  const config = JSON.parse(readFileSync(join(pluginDir, "config.template.json"), "utf8"));
  config.torExe = findTor() || "";
  writeFileSync(configFile, JSON.stringify(config, null, 2) + "\n");
}
const config = JSON.parse(readFileSync(configFile, "utf8"));
console.log("3. 설정 파일: " + configFile);
console.log(config.torExe ? "   토르 위치: " + config.torExe
  : "   토르를 찾지 못했습니다. 토르를 쓰려면 설정 파일의 torExe에 토르 폴더의 Browser\\firefox.exe 경로를 적으세요.");

console.log(`
다음 단계(직접):
  - 크롬 주소창에 chrome://extensions → 개발자 모드 켜기 → '압축해제된 확장 프로그램을 로드합니다' → ${extDir}
  - 확장 카드의 '세부정보' → '시크릿 모드에서 허용' 켜기
  - 확장 ID가 ${config.chromeExtensionId} 인지 확인`);

function findTor() {
  const tail = join("Tor Browser", "Browser", "firefox.exe");
  const candidates = [
    join(homedir(), "Desktop", tail),
    join(homedir(), "OneDrive", "Desktop", tail),
    join(homedir(), "OneDrive", "바탕 화면", tail),
    join(process.env.LOCALAPPDATA || "", tail),
    join(process.env.ProgramFiles || "C:\\Program Files", tail),
  ];
  return candidates.find((p) => existsSync(p));
}
