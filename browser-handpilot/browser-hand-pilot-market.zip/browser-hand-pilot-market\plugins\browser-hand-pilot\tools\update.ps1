﻿# 브라우저파일럿 업데이트
#   -Check -Auto : (작업 스케줄러가 매주 실행) 새 버전이 있으면 알림을 띄우고, 설치는 별도 창(-Now -WaitIdle)으로 넘긴다(작업 5분 제한 때문).
#   -Now [-WaitIdle] : 도구 서버가 하나도 안 돌 때(아무 채팅도 안 쓸 때) 설치 스크립트를 내려받아 실행. 최대 12시간 기다림.
#   -Register / -Unregister : 매주 월요일 10시 확인 작업 켜기/끄기(놓친 실행은 켜진 뒤 보충)
# '새 버전'은 사이트의 version.json 버전 번호가 지금 설치본보다 높을 때만이다.
param([switch]$Check, [switch]$Auto, [switch]$Now, [switch]$WaitIdle, [switch]$Register, [switch]$Unregister)

$ErrorActionPreference = "Stop"
$TaskName = "BrowserHandPilotUpdate"
$Base = "https://gobong-choi.github.io/Gobongs/browser-handpilot"
$PluginDir = Split-Path $PSScriptRoot -Parent
$Home2 = if ($env:BHP_HOME) { $env:BHP_HOME } else { Join-Path $env:USERPROFILE "BrowserHandPilot" }
$LogDir = Join-Path $Home2 "logs"

function Log([string]$level, [string]$msg) {
    New-Item -ItemType Directory -Force $LogDir | Out-Null
    $line = "{0} {1} update#{2} {3}" -f (Get-Date).ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ss.fffZ"), $level, $PID, $msg
    [IO.File]::AppendAllText((Join-Path $LogDir ("{0}.log" -f (Get-Date).ToUniversalTime().ToString("yyyy-MM-dd"))), "$line`n", [Text.UTF8Encoding]::new($false))
}

function Notify([string]$title, [string]$text) {
    try {
        [Windows.UI.Notifications.ToastNotificationManager, Windows.UI.Notifications, ContentType = WindowsRuntime] | Out-Null
        [Windows.Data.Xml.Dom.XmlDocument, Windows.Data.Xml.Dom.XmlDocument, ContentType = WindowsRuntime] | Out-Null
        $xml = [Windows.Data.Xml.Dom.XmlDocument]::new()
        $t = [Security.SecurityElement]::Escape($title); $b = [Security.SecurityElement]::Escape($text)
        $xml.LoadXml("<toast><visual><binding template='ToastGeneric'><text>$t</text><text>$b</text></binding></visual></toast>")
        $app = '{1AC14E77-02E7-4E5D-B744-2EB1AE5198B7}\WindowsPowerShell\v1.0\powershell.exe'
        [Windows.UI.Notifications.ToastNotificationManager]::CreateToastNotifier($app).Show([Windows.UI.Notifications.ToastNotification]::new($xml))
    } catch { Log "WARN" "알림 실패: $($_.Exception.Message)" }
}

function Local-Version { (Get-Content (Join-Path $PluginDir "package.json") -Raw | ConvertFrom-Json).version }
function Remote-Version { (Invoke-RestMethod -UseBasicParsing "$Base/version.json?t=$([DateTime]::Now.Ticks)" -TimeoutSec 15).version }
function Is-Newer([string]$a, [string]$b) { [version]$a -gt [version]$b }
function Busy-Count {
    @(Get-CimInstance Win32_Process -Filter "Name='node.exe'" | Where-Object { $_.CommandLine -match 'server[\\/]mcp\.js' }).Count
}

try {
    if ($Register) {
        $action = New-ScheduledTaskAction -Execute "powershell.exe" -Argument "-NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File `"$PSCommandPath`" -Check -Auto"
        $trigger = New-ScheduledTaskTrigger -Weekly -DaysOfWeek Monday -At 10am
        $settings = New-ScheduledTaskSettingsSet -StartWhenAvailable -ExecutionTimeLimit (New-TimeSpan -Minutes 5) -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries
        Register-ScheduledTask -TaskName $TaskName -Action $action -Trigger $trigger -Settings $settings -Description "브라우저파일럿 새 버전 확인" -Force | Out-Null
        Log "INFO" "자동 업데이트 켬"
        exit 0
    }
    if ($Unregister) {
        Unregister-ScheduledTask -TaskName $TaskName -Confirm:$false -ErrorAction SilentlyContinue
        Log "INFO" "자동 업데이트 끔"
        exit 0
    }

    if ($Check) {
        $local = Local-Version; $remote = Remote-Version
        if (-not (Is-Newer $remote $local)) { Log "INFO" "최신($local)"; exit 0 }
        Log "INFO" "새 버전 $remote (지금 $local)"
        if ($Auto) {
            Start-Process powershell.exe -WindowStyle Hidden -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`" -Now -WaitIdle"
            Notify "브라우저파일럿 $remote" "새 버전이 있어요. 아무 채팅도 브라우저 도구를 안 쓸 때 자동으로 설치해요."
        } else {
            Notify "브라우저파일럿 $remote" "새 버전이 있어요. 관리 페이지에서 [지금 업데이트]를 누르세요."
        }
        exit 0
    }

    if ($Now) {
        $mutex = [Threading.Mutex]::new($false, "Global\BrowserHandPilotUpdate")
        if (-not $mutex.WaitOne(0)) { Log "INFO" "이미 업데이트 중"; exit 0 }
        $deadline = (Get-Date).AddHours(12)
        while ($WaitIdle -and (Busy-Count) -gt 0) {
            if ((Get-Date) -gt $deadline) {
                Log "WARN" "12시간 동안 도구 사용 중이라 업데이트를 미룸"
                Notify "브라우저파일럿" "계속 사용 중이라 업데이트를 미뤘어요. 관리 페이지에서 [지금 업데이트]를 누르세요."
                exit 0
            }
            Start-Sleep -Seconds 60
        }
        $f = Join-Path $env:TEMP "browser-handpilot-setup.ps1"
        Invoke-WebRequest -UseBasicParsing "$Base/setup.ps1" -OutFile $f
        $p = Start-Process powershell.exe -WindowStyle Hidden -Wait -PassThru -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$f`" -NoOpenFolder"
        if ($p.ExitCode -eq 0) {
            Log "INFO" "업데이트 완료 $(Local-Version)"
            Notify "브라우저파일럿 업데이트 완료" "버전 $(Local-Version). 크롬 확장은 다음 연결 때 스스로 새로 불러와요. 새 도구 설명은 새 채팅부터."
        } else {
            Log "ERROR" "업데이트 실패(종료 코드 $($p.ExitCode))"
            Notify "브라우저파일럿 업데이트 실패" "관리 페이지의 로그를 확인하세요."
        }
        $mutex.ReleaseMutex()
        exit $p.ExitCode
    }
} catch {
    Log "ERROR" $_.Exception.Message
    exit 1
}
