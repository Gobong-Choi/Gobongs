// 눈과 손: 탭 목록, 탭 사진, 그 탭 안에서만 클릭·입력·키·스크롤.
// 웹페이지 내용(DOM·글자)은 읽지 않는다. 화면 배율도 페이지에 묻지 않고 사진으로 잰다
// (토르는 지문 방지로 페이지에 배율을 1로 속여 알려 주기 때문).
import { config } from "./config.js";

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

// WebDriver 특수 키 코드
const KEYS = {
  enter: "", tab: "", backspace: "", escape: "", esc: "",
  space: " ", delete: "", home: "", end: "",
  pageup: "", pagedown: "",
  left: "", up: "", right: "", down: "",
  arrowleft: "", arrowup: "", arrowright: "", arrowdown: "",
  ctrl: "", control: "", shift: "", alt: "",
  f5: "",
};

function keyValue(name) {
  const v = KEYS[name.toLowerCase()];
  if (v) return v;
  if ([...name].length === 1) return name;
  throw new Error("모르는 키: " + name);
}

export class Hand {
  constructor(bidi) {
    this.bidi = bidi;
    this.mine = new Set();
    // 탭별 로딩 상태: 페이지 이동이 시작되면 true, 로드가 끝나면 false(눈이 화면 멈춤 판정 전에 본다)
    this.loading = new Map();
    bidi.onEvent = (method, p) => {
      if (method === "browsingContext.navigationStarted") this.loading.set(p.context, true);
      if (method === "browsingContext.load") this.loading.set(p.context, false);
    };
    bidi.send("session.subscribe", { events: ["browsingContext.navigationStarted", "browsingContext.load"] }).catch(() => {});
  }

  async isLoading(tab) {
    return this.loading.get(tab) === true;
  }

  get connected() {
    return this.bidi.connected;
  }

  // 토르는 통로 세션을 하나만 받으므로 끝날 때 꼭 닫는다.
  async close() {
    if (!this.bidi.connected) return;
    await Promise.race([this.bidi.send("session.end", {}).catch(() => {}), sleep(1000)]);
    this.bidi.close();
  }

  // mine: 이 채팅이 new_tab으로 연 탭(크롬판의 mine과 같은 뜻). 토르는 한 채팅만 쓰므로 otherChat은 없다.
  async tabs() {
    const tree = await this.bidi.send("browsingContext.getTree", { maxDepth: 0 });
    return tree.contexts.map((c, i) => ({ index: i, id: c.context, url: c.url, mine: this.mine.has(c.context) }));
  }

  async newTab(url) {
    const { context } = await this.bidi.send("browsingContext.create", { type: "tab", background: true });
    this.mine.add(context);
    if (url) await this.bidi.send("browsingContext.navigate", { context, url, wait: "complete" });
    return context;
  }

  async navigate(tab, url) {
    await this.bidi.send("browsingContext.navigate", { context: tab, url, wait: "complete" });
  }

  async url(tab) {
    const tree = await this.bidi.send("browsingContext.getTree", { maxDepth: 0 });
    return tree.contexts.find((c) => c.context === tab)?.url;
  }

  // 기기 픽셀 ÷ CSS 픽셀: 입력 좌표 기준 100×100 상자를 찍어 사진 폭을 잰다(페이지에 묻지 않음).
  async devScale(tab) {
    const { data } = await this.bidi.send("browsingContext.captureScreenshot", {
      context: tab,
      clip: { type: "box", x: 0, y: 0, width: 100, height: 100 },
    });
    const width = Buffer.from(data, "base64").readUInt32BE(16); // PNG 머리말의 폭
    return width / 100 || 1;
  }

  async screenshot(tab) {
    const { data } = await this.bidi.send("browsingContext.captureScreenshot", { context: tab });
    return data; // base64 png, 화면 픽셀 기준
  }

  async perform(tab, actions) {
    await this.bidi.send("input.performActions", { context: tab, actions });
    await this.bidi.send("input.releaseActions", { context: tab });
    await sleep(config.settleMs);
  }

  // x, y는 CSS 픽셀(사진 좌표 환산은 common/eyes.js가 한다)
  async click(tab, x, y, { button = "left", double = false } = {}) {
    const s = 1;
    const btn = { left: 0, middle: 1, right: 2 }[button] ?? 0;
    const press = [{ type: "pointerDown", button: btn }, { type: "pointerUp", button: btn }];
    await this.perform(tab, [{
      type: "pointer", id: "mouse", parameters: { pointerType: "mouse" },
      actions: [
        { type: "pointerMove", x: Math.round(x / s), y: Math.round(y / s) },
        ...press, ...(double ? press : []),
      ],
    }]);
    // 링크 클릭은 새 페이지가 조금 늦게 시작되므로 더 기다린 뒤 화면 멈춤을 본다.
    await sleep(config.clickSettleMs);
  }

  async move(tab, x, y) {
    const s = 1;
    await this.perform(tab, [{
      type: "pointer", id: "mouse", parameters: { pointerType: "mouse" },
      actions: [{ type: "pointerMove", x: Math.round(x / s), y: Math.round(y / s) }],
    }]);
  }

  async type(tab, text) {
    const actions = [];
    for (const ch of text) {
      actions.push({ type: "keyDown", value: ch }, { type: "keyUp", value: ch });
      if (config.typeDelayMs) actions.push({ type: "pause", duration: config.typeDelayMs });
    }
    await this.perform(tab, [{ type: "key", id: "keyboard", actions }]);
  }

  // combo 예: "Enter", "Ctrl+F", "Shift+Tab"
  async key(tab, combo) {
    const values = combo.split("+").map((k) => keyValue(k.trim()));
    const down = values.map((value) => ({ type: "keyDown", value }));
    const up = [...values].reverse().map((value) => ({ type: "keyUp", value }));
    await this.perform(tab, [{ type: "key", id: "keyboard", actions: [...down, ...up] }]);
    // Enter는 새 페이지를 여는 일이 많아 링크 클릭처럼 더 기다린다.
    if (/(^|\+)\s*enter\s*$/i.test(combo)) await sleep(config.clickSettleMs);
  }

  // dy > 0 이면 아래로. x, y, dy 모두 CSS 픽셀
  async scroll(tab, x, y, dy) {
    // 토르는 뒤에 숨은 탭에서 휠 스크롤을 무시한다(2026-10-26 시험). 토르 창 안에서만 그 탭을 앞으로 꺼낸다.
    // 운영체제 창 순서(다른 프로그램)는 바뀌지 않는 것을 확인했다.
    await this.bidi.send("browsingContext.activate", { context: tab });
    const s = 1;
    await this.perform(tab, [{
      type: "wheel", id: "wheel",
      actions: [{ type: "scroll", x: Math.round(x / s), y: Math.round(y / s), deltaX: 0, deltaY: Math.round(dy / s) }],
    }]);
  }
}
