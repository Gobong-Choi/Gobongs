// 통로 접속: 토르(파이어폭스)의 WebDriver BiDi에 웹소켓으로 붙어 명령을 주고받는다.

export class Bidi {
  constructor(url) {
    this.url = url;
    this.ws = null;
    this.nextId = 0;
    this.pending = new Map();
  }

  connect() {
    return new Promise((resolve, reject) => {
      const ws = new WebSocket(this.url);
      ws.onopen = () => { this.ws = ws; resolve(); };
      ws.onerror = () => reject(new Error("통로 접속 실패: " + this.url));
      ws.onclose = () => {
        this.ws = null;
        for (const { reject: rej } of this.pending.values()) rej(new Error("통로가 닫혔습니다"));
        this.pending.clear();
      };
      ws.onmessage = (e) => this.onMessage(JSON.parse(e.data));
    });
  }

  onMessage(msg) {
    if (msg.id === undefined) return; // 이벤트는 쓰지 않는다
    const waiter = this.pending.get(msg.id);
    if (!waiter) return;
    this.pending.delete(msg.id);
    if (msg.type === "error") waiter.reject(new Error(`${msg.error}: ${msg.message}`));
    else waiter.resolve(msg.result);
  }

  send(method, params = {}) {
    if (!this.ws) return Promise.reject(new Error("통로에 연결되어 있지 않습니다"));
    const id = ++this.nextId;
    return new Promise((resolve, reject) => {
      this.pending.set(id, { resolve, reject });
      this.ws.send(JSON.stringify({ id, method, params }));
    });
  }

  get connected() {
    return this.ws !== null;
  }

  close() {
    if (this.ws) this.ws.close();
  }
}
