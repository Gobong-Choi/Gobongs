// 설정 읽기: 바뀔 값은 모두 config.json 한 곳에 둔다.
// 개발 폴더에서는 프로젝트 맨 위 config.json·extension/을 쓰고,
// 플러그인으로 설치한 컴퓨터(옆에 config.json이 없음)에서는 사용자 폴더\BrowserHandPilot 안의 것을 쓴다.
// 환경 변수 BHP_HOME을 주면 그 폴더를 쓴다.
import { existsSync, readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { join } from "node:path";
import { homedir } from "node:os";

const projectDir = fileURLToPath(new URL("..", import.meta.url));
export const defaultHome = join(homedir(), "BrowserHandPilot");
export const homeDir =
  process.env.BHP_HOME || (existsSync(join(projectDir, "config.json")) ? projectDir : defaultHome);

const configPath = join(homeDir, "config.json");
if (!existsSync(configPath)) {
  throw new Error(`설정 파일이 없습니다(${configPath}). 설치 안내서의 'node tools/setup.js' 단계를 먼저 실행하세요.`);
}
export const config = JSON.parse(readFileSync(configPath, "utf8"));
export const secretPath = join(homeDir, "extension", "secret.js");
