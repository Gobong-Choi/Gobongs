// 설정 읽기: 기본값(아래 DEFAULTS) ← config.json(공용) ← config.local.json(이 PC 전용) 순서로 키 단위로 덮어쓴다.
// 관리 페이지는 기본값·공용과 다른 값만 config.local.json에 저장하므로 업데이트와 부딪히지 않는다.
// 두 파일의 수정 시각이 바뀌면 refreshConfig()가 다시 읽는다(도구 서버는 동작마다 부름 → 재시작 없이 적용).
// 개발 폴더에서는 프로젝트 맨 위 파일·extension/을 쓰고, 플러그인으로 설치한 컴퓨터(옆에 config.json이 없음)에서는
// 사용자 폴더\BrowserHandPilot 안의 것을 쓴다. 환경 변수 BHP_HOME을 주면 그 폴더를 쓴다.
import { existsSync, readFileSync, statSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { join } from "node:path";
import { homedir } from "node:os";

export const DEFAULTS = {
  torExe: "",
  port: 9222,
  chromePort: 9333,
  chromePortCount: 4,
  chromeExtensionId: "kheofijbolmhdnfmplopdgkfcfbmkohn",
  chromeConnectTimeoutMs: 40000,
  chromeExe: "",           // Claude 전용 크롬으로 띄울 chrome.exe(비우면 기본 설치 위치에서 찾음)
  chromeProfileDir: "",    // Claude 전용 크롬 프로필 폴더(비우면 설치 폴더\chrome-profile)
  chromeWindowWidth: 1024, // Claude 창 크기(화면 오른쪽 아래 구석에 놓임)
  chromeWindowHeight: 768,
  launchTimeoutMs: 30000,
  maxImage: 1280,        // 탭 사진 긴 변(px). 클수록 선명하지만 토큰이 늘어남
  zoomMax: 1568,         // 확대 사진 긴 변(px)
  fullEvery: 5,          // 잘린 결과를 이만큼 보내면 한 번은 전체 사진
  ignoreMaxShare: 0.1,   // 동작 전에 저절로 바뀐 칸이 화면의 이 비율을 넘으면 기준을 비우고 전체 사진
  ignoreMaxCells: 6,     // 동작 전에 저절로 바뀐 칸이 이 개수 이하일 때만 '무시할 칸'으로 배움(시계·커서·작은 광고)
  stopKey: "Escape",     // Claude가 일하는 탭을 맨 앞에 두고 사람이 누르면 그 채팅 동작을 바로 멈추는 키(Escape, Pause, ScrollLock, F12)
  stopHoldMs: 30000,     // 정지 키를 누른 뒤 이 시간 동안은 모든 동작을 거절(그사이 Claude가 사용자에게 물음)
  settleIntervalMs: 150, // 화면 멈춤 확인 간격
  stableMs: 400,         // 마지막 변화 뒤 이만큼 그대로면 멈춘 것으로 봄
  noChangeMs: 700,       // 아무 변화가 없으면 이만큼 뒤 '변화 없음'
  settleMaxMs: 3000,     // 계속 바뀌어도 이만큼 뒤엔 찍음
  loadWaitMs: 5000,      // 페이지 로딩이 끝나길 기다리는 최대 시간(크롬)
  settleMs: 100,         // 입력을 넣은 직후 잠깐 쉼
  clickSettleMs: 400,    // 토르: 클릭·Enter 뒤 새 페이지가 시작될 시간
  typeDelayMs: 30,
  releaseIdleMs: 300000, // 이만큼 안 쓰면 크롬 포트·디버거·토르 통로·정지 키 감시를 놓음(도구는 켜 둔 채, 다음 호출 때 다시 잡음)
  exitIdleMs: 43200000,  // 안전망: 이만큼 안 쓰면 도구 서버가 스스로 꺼짐(채팅이 닫혀 통로가 끊기면 그때 바로 꺼짐)
};

const projectDir = fileURLToPath(new URL("..", import.meta.url));
export const defaultHome = join(homedir(), "BrowserHandPilot");
export const homeDir =
  process.env.BHP_HOME || (existsSync(join(projectDir, "config.json")) ? projectDir : defaultHome);
export const configPath = join(homeDir, "config.json");
export const localConfigPath = join(homeDir, "config.local.json");
export const secretPath = join(homeDir, "extension", "secret.js");

if (!existsSync(configPath)) {
  throw new Error(`설정 파일이 없습니다(${configPath}). 설치 안내서의 설치 단계를 먼저 실행하세요.`);
}

const readJson = (p) => (existsSync(p) ? JSON.parse(readFileSync(p, "utf8")) : {});
const mtime = (p) => (existsSync(p) ? statSync(p).mtimeMs : 0);

// 공용 설정(기본값 + config.json). 관리 페이지가 '다른 값만 저장'할 때 비교 기준
export function sharedConfig() {
  return { ...DEFAULTS, ...readJson(configPath) };
}

export const config = {};
let stamp = "";
export function refreshConfig() {
  const now = `${mtime(configPath)}|${mtime(localConfigPath)}`;
  if (now === stamp) return config;
  try {
    const merged = { ...sharedConfig(), ...readJson(localConfigPath) };
    for (const k of Object.keys(config)) delete config[k];
    Object.assign(config, merged);
    stamp = now;
  } catch (err) {
    if (!stamp) throw err; // 처음 읽기 실패는 알리고, 쓰는 도중 읽은 경우는 다음에 다시
  }
  return config;
}
refreshConfig();
