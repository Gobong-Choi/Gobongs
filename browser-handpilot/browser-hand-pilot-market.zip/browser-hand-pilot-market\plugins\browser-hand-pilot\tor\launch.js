// 토르 실행: 통로가 열려 있으면 그대로 쓰고, 없으면 통로를 켜는 옵션으로 토르를 띄운다.
// 통로는 이 PC 안(127.0.0.1)에서만 접속된다.
import { spawn } from "node:child_process";
import { config } from "./config.js";
import { Bidi } from "./bidi.js";

const sessionUrl = () => `ws://127.0.0.1:${config.port}/session`;
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

async function tryConnect() {
  const bidi = new Bidi(sessionUrl());
  try {
    await bidi.connect();
    return bidi;
  } catch {
    return null;
  }
}

function startTor() {
  const child = spawn(config.torExe, ["--remote-debugging-port", String(config.port)], {
    detached: true,
    stdio: "ignore",
  });
  child.unref();
}

// 세션까지 열린 통로를 돌려준다.
export async function openSession() {
  let bidi = await tryConnect();
  if (!bidi) {
    startTor();
    const deadline = Date.now() + config.launchTimeoutMs;
    while (!bidi && Date.now() < deadline) {
      await sleep(500);
      bidi = await tryConnect();
    }
    if (!bidi) throw new Error("토르를 띄웠지만 통로가 열리지 않았습니다: " + config.torExe);
  }
  try {
    await bidi.send("session.new", { capabilities: {} });
  } catch (err) {
    bidi.close();
    if (/Maximum number of active sessions/.test(err.message)) {
      throw new Error("다른 프로그램(다른 채팅)이 토르 통로를 쓰고 있거나, 지난 연결이 남아 있습니다. 토르 창을 닫았다가 다시 시도하세요.");
    }
    throw err;
  }
  return bidi;
}
