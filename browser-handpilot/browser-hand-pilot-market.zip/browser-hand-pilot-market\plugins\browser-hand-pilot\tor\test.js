// 시험: 토르 통로 접속 → 탭 목록 → 첫 탭 사진 → 그 탭 안 마우스 이동.
// 사이트에 접속하거나 클릭하지 않는다. 사진은 인자로 준 경로에 저장한다.
import { writeFileSync } from "node:fs";
import { openSession } from "./launch.js";
import { Hand } from "./actions.js";

const out = process.argv[2];
const hand = new Hand(await openSession());
const tabs = await hand.tabs();
console.log("탭:", tabs);
const t = tabs[0].id;
console.log("배율:", await hand.scale(t));
const png = await hand.screenshot(t);
if (out) writeFileSync(out, Buffer.from(png, "base64"));
console.log("사진 바이트:", png.length);
await hand.move(t, 20, 20);
console.log("마우스 이동 됨");
await hand.bidi.send("session.end", {});
hand.bidi.close();
