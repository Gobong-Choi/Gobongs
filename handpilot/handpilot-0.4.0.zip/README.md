# 핸드파일럿 (handpilot)

Claude Code가 이 PC의 화면을 보고(스크린샷) 마우스·키보드를 직접 조작하게 해주는 **개인용 Claude Code 플러그인**입니다.
내 PC의 로컬 마켓플레이스(`handpilot-local`)로 설치되어 있으며, 외부에 공개되지 않습니다.

## 문서

| 문서 | 내용 |
|---|---|
| [CHANGELOG.md](CHANGELOG.md) | 버전별 변경 내용 |
| [docs/DECISIONS.md](docs/DECISIONS.md) | 왜 이렇게 만들었는지 (결정과 이유, 보류한 방법) |
| [docs/ROADMAP.md](docs/ROADMAP.md) | 앞으로 할 것, 개발 방향 후보 |
| [docs/TESTING.md](docs/TESTING.md) | 테스트 방법과 기준값 |
| [docs/SETUP.md](docs/SETUP.md) | 설치 · 재설치 · 다른 PC에 설치 · 제거 |
| [docs/OPERATIONS.md](docs/OPERATIONS.md) | 파일·로그 위치, 서버 확인·재시작, 증상별 대처, 알려진 한계 |
| [docs/STATUS.md](docs/STATUS.md) | 상태 기준점 (v0.1.9, v0.2.0 — 버전·환경·기능·테스트 기준값) |
| [docs/HISTORY.md](docs/HISTORY.md) | 작업 일지 (요청 → 한 일 → 발견, 시간순) |
| [CLAUDE.md](CLAUDE.md) | 이 폴더에서 일하는 Claude가 자동으로 읽는 개발 안내 (기록 규칙 포함) |

## 용어 정리 (핸드파일럿은 MCP? 커넥터? 도구? 서버?)

같은 것을 층마다 다르게 부릅니다. 비유: USB 마우스. 그림: **[docs/how-it-works.html](docs/how-it-works.html)**(0.2.6 기준 — 층별 구조·Claude에 붙는 방식·할 수 있는 영역·동작 흐름·데이터·파일 위치), 예전 그림 [docs/concepts.svg](docs/concepts.svg)(0.1.x)

| 용어 | 비유 | 핸드파일럿에서는 |
|---|---|---|
| MCP | USB 규격 | Claude와 외부 프로그램이 대화하는 표준 규칙(프로그램이 아님) |
| MCP 서버 | 마우스 본체 | `handpilot/server.py` — 실제로 화면을 찍고 마우스를 움직이는 프로그램. 채팅창마다 1개 |
| 도구(tool) | 마우스 버튼 | `screenshot`·`click` 등 8개 기능. Claude가 직접 호출하는 단위 |
| 커넥터 | "연결된 장치" 목록 | 앱이 연결된 MCP 서버를 부르는 이름(`plugin:handpilot:handpilot`) |
| 스킬 | 사용설명서 | `SKILL.md` — 도구 사용 방법·안전 규칙 (`/handpilot:handpilot`) |
| 플러그인 | 포장 상자 | MCP 서버 + 스킬 묶음. 설치·업데이트·끄기의 단위 |

Notion·Google Drive 커넥터도 같은 원리(MCP 서버)이고, 그쪽은 인터넷에, 핸드파일럿은 내 PC 안에서 돕니다.

## 설치 · 업데이트

| 상황 | 할 일 |
|---|---|
| 새 PC 설치 | 설치 안내 페이지(https://gobong-choi.github.io/Gobongs/handpilot/)의 **[설치 파일 받기]** → 더블클릭 → 끝(설치 안내 사이트의 공개 묶음을 받음 — GitHub 로그인·Git 필요 없음, 0.4.0~) |
| 재설치 / 폴더 이동 후 | `powershell -ExecutionPolicy Bypass -File install.ps1` |
| 업데이트 받기 | 관리 창 상태 탭 업데이트 카드 [업데이트 확인…] → 설치 창 **[지금 설치]**, 또는 `update.ps1` (`-Check`: 확인만, `-RestartServers`: 예전 서버 바로 교체). 설치 파일로 설치한 PC는 설치 안내 사이트에서, GitHub로 설치한 PC는 GitHub에서 받음 |
| 정기 업데이트 확인 | 매주 월요일 10시, 새 버전(릴리스)이 있으면 **핸드파일럿을 안 쓸 때 자동 설치 + Windows 알림**(0.3.3~, 관리 창 설정 탭 '새 버전 자동 설치'로 끄면 설치 창). 확인 자체는 관리 창 정보 탭 스위치로 켜기/끄기 |
| 새 버전 내기 (개발 PC) | `CHANGELOG.md` 작성 → `release.ps1` |
| 상태 점검 (문제가 있을 때 먼저) | `doctor.ps1` (`-Fetch`: 원격 새 버전도) |
| **관리 창 (상태·업데이트·설정·로그)** | 시작 메뉴 **핸드파일럿 관리** (`tools/settings.pyw`) |

자세한 내용: [docs/SETUP.md](docs/SETUP.md) · 설치 안내 페이지(다른 PC에서 보기 편함): https://gobong-choi.github.io/Gobongs/handpilot/

## 사용법

어느 폴더의 채팅창에서든:

```
/handpilot:handpilot 메모장 열고 오늘 할 일 세 줄 적어줘
```

또는 그냥 "핸드파일럿으로 ~ 해줘", "지금 화면 봐줘"라고 해도 됩니다.

## 정지 / 재개

- Claude가 작업하는 동안 화면 오른쪽 위에 **"● 핸드파일럿 작동 중"** 표시가 뜹니다(스크린샷에는 찍히지 않음).
- 이때 **마우스를 움직이거나, 클릭하거나, 키를 누르면 즉시 일시정지**됩니다. 진행 중인 대기도 바로 끊기고, Claude는 재시도하지 않고 기다립니다.
- 표시가 **"⏸ 일시정지됨 [재개]"** 로 바뀌며, **[재개]를 직접 클릭**해야 다시 움직입니다(Claude는 정지를 풀 수 없음).
- 마지막 동작 후 5초가 지나면 감시를 멈추므로, 작업이 끝난 뒤엔 평소처럼 PC를 써도 멈추지 않습니다.
- 보조 수단: 마우스를 화면 왼쪽 위 모서리로 밀어도 정지됩니다(FailSafe).

설정은 `handpilot/config.json`(공용)에서, PC마다 다르게 하려면 `handpilot/config.local.json`(이 PC 전용)에서 바꿉니다. 저장하면 바로 적용됩니다.

| 항목 | 기본값 | 의미 |
|---|---|---|
| `idle_exit_min` | 10 | 이 시간(분) 동안 안 쓰면 서버 자동 종료 (0 = 안 함) |
| `lock_hold_sec` | 15 | 마지막 동작 후 조작권을 유지하는 시간(초) — 훅이 없는 채팅창 기준 |
| `lock_hold_turn_sec` | 90 | 답변 중(훅 확인)일 때 최대 유지 시간. 답변이 끝나면 바로 반납 |
| `log_enabled` | true | 자체 로그 기록 (`%LOCALAPPDATA%\handpilot\logs`) |
| `log_retention_days` | 30 | 이 기간(일)이 지난 로그 자동 삭제 |
| `active_window_sec` | 5.0 | 마지막 동작 후 사람 입력을 감시하는 시간(초) |
| `move_threshold_px` | 30 | 이 거리(px) 이상 움직여야 정지 |
| `focus_claude_on_done` | true | 핸드파일럿을 쓴 답변이 끝나면 Claude 창을 맨 앞으로(그때 사람이 입력 중이면 작업 표시줄 깜빡임만) |
| `esc_stop` | true | 핸드파일럿이 작업·답변 중일 땐 언제든 Esc로 즉시 정지(안 쓸 때의 Esc는 무시) |
| `stop_on_other_input` | true | 다른 프로그램이 만든 입력(PowerToys 마우스 공유 등)도 사람으로 보고 정지. 마우스 흔들기 등 자동화 프로그램을 쓰면 false |
| `overlay_enabled` | true | 작동 중 표시 사용 여부 |
| `overlay_position` | top-right | top-right / top-left / bottom-right / bottom-left |
| `overlay_margin_x`, `overlay_margin_y` | 16, 60 | 화면 가장자리에서 떨어진 거리(px) |

## 구성

```
직접 마우스 화면 컨트롤 앱\           ← 로컬 마켓플레이스 (개발 원본)
├─ .claude-plugin\marketplace.json
├─ handpilot\                        ← 플러그인 본체
│   ├─ .claude-plugin\plugin.json    ← 이름, 버전
│   ├─ .mcp.json.template            ← MCP 서버 실행 설정 템플릿 (.mcp.json은 install.ps1이 PC 경로로 생성)
│   ├─ server.py                     ← 고정 껍데기: 도구 목록 + 정지 장치 연결
│   ├─ actions.py                    ← 실제 동작 + 화면 변화 감지 (자동 다시 불러오기)
│   ├─ guard.py                      ← 정지 장치 (사람 입력 감지, 작동 중 표시, [재개]/[종료])
│   ├─ lease.py                      ← 조작권 잠금 (여러 채팅창 중 한 곳만 조작)
│   ├─ hplog.py                      ← 자체 로그 (날짜별 파일, 30일 정리)
│   ├─ hook_signal.py                ← 훅 → 서버 신호 (답변 끝남 / 새 메시지)
│   ├─ hooks\hooks.json.template     ← 훅 설정 템플릿 (hooks.json은 install.ps1이 생성)
│   ├─ config.json                   ← 공용 설정 (정지 장치 · 화면 변화 감지 · 메모리 · 조작권)
│   ├─ config.local.json             ← (선택) 이 PC 전용 설정 — git·업데이트 대상 아님
│   └─ skills\handpilot\SKILL.md     ← /handpilot 사용설명서 (작업 방식, 안전 규칙)
├─ .venv\                            ← Python 가상환경 (라이브러리)
├─ docs\                            ← 결정 기록 · 로드맵 · 테스트 방법
├─ tests\                           ← 테스트 창 · 통합 테스트 · 메모리 측정
├─ CHANGELOG.md                      ← 버전별 변경 기록
├─ requirements.txt / requirements.lock  ← 라이브러리 (lock = 정확한 버전 고정)
├─ install.ps1                       ← 설치 · 재설치 · 폴더 이동 후 (경로 자동 설정)
├─ update.ps1                        ← 업데이트 받기
├─ release.ps1                       ← 새 버전 내기 (개발 PC)
├─ doctor.ps1                        ← 상태 점검 (tools\doctor.py)
├─ tools\                            ← 관리 도구: doctor.py(점검), settings.pyw(관리 창), update_prompt.pyw(업데이트 설치 창), ui_style.py(두 창 공통 모양), wait_report.py(대기 측정 요약)
├─ web\                              ← 웹 설치 파일 원본: handpilot-setup.cmd(더블클릭), setup.ps1 — 설치 안내 페이지에 복사본
└─ scripts\common.ps1                ← 스크립트 공통 기능
```

## 제공 도구

| 도구 | 설명 |
|---|---|
| `screenshot(mode)` | `auto`: 마지막으로 본 화면과 비교해 바뀐 부분만 / `full`: 전체 화면 |
| `click(x, y, button, clicks, observe)` | 클릭 / 우클릭 / 더블클릭 |
| `move(x, y, observe)` | 마우스 이동 (hover) |
| `drag(from_x, from_y, to_x, to_y, observe)` | 끌어다 놓기 |
| `type_text(text, observe)` | 텍스트 입력 (한글 가능, 클립보드 붙여넣기 방식) |
| `key(combo, observe)` | 키/단축키 (`enter`, `ctrl+s`, `alt+tab`, `win+r` …) |
| `scroll(amount, x, y, observe)` | 스크롤 (양수=위, 음수=아래) |
| `wait(seconds, until_stable)` | 대기 / 화면 안정될 때까지 대기 |
| `windows(focus, maximize)` | 작업할 창을 찾아 맨 앞으로(프로그램 이름·제목 일부·번호, 최소화 해제, 화면 함께). 없으면 열린 창 목록과 안내 — 0.3.0, 새 채팅창부터 |
| `zoom(x, y, width, height)` | 화면 일부를 원본 해상도로 확대(작은 글씨 읽기, 읽기 전용) — 0.2.0, 새 채팅창부터 |

## 여러 채팅창 동시 사용 (조작권)

채팅창마다 서버가 따로 뜨므로, **한 번에 한 채팅창만** 화면을 조작하도록 PC 전체에서 조작권을 나눕니다.

- 모든 도구(screenshot 포함)는 조작권이 있어야 실행됩니다. 다른 채팅창이 쥐고 있으면 **기다리지 않고 바로 거부**하고,
  Claude는 재시도하지 않고 사용자에게 알립니다. 예: `다른 채팅창(「○○」)이 핸드파일럿을 사용 중입니다. 그 채팅창의 작업이 끝나면 약 12초 뒤 자동으로 반납됩니다.`
- **답변이 끝나면 바로 반납**합니다(Claude Code 훅). 답변 중에는 길게 생각해도 최대 `lock_hold_turn_sec`(90초)까지 유지합니다.
- 훅이 없는 채팅창(이전에 연 채팅창)은 마지막 동작 후 `lock_hold_sec`(15초) 동안 쥐고 자동 반납합니다.
- [종료] 뒤 사용자가 새 메시지를 보내면 종료 알림이 자동으로 정리되어 새 지시는 바로 진행됩니다.
- **일시정지 중에는 조작권을 계속 쥡니다.** 표시창의 **[재개]**(이어서 하기) 또는 **[종료]**(정지 해제 + 조작권 즉시 반납)를 누르세요.
- 서버가 비정상 종료돼도 잠금이 남지 않습니다(파일 핸들 잠금 → OS가 자동 해제).
- 같은 채팅창 안에서도 동작은 한 번에 하나씩 실행됩니다.

표시창 상태:

| 표시 | 의미 |
|---|---|
| `● 핸드파일럿 작동 중 「채팅창 제목」` | 그 채팅창이 조작 중 (마우스를 움직이면 정지) |
| `◌ 핸드파일럿 조작권 보유 「채팅창 제목」 · N초 후 반납` (흐리게) | 동작은 끝났지만 아직 조작권을 쥐고 있음 — 이때 다른 채팅창은 거부됨 |
| `⏸ 핸드파일럿 일시정지됨 「채팅창 제목」 [재개] [종료]` | 사용자가 만져서 정지. 조작권 유지 중 |

채팅창 이름은 사이드바의 **채팅창 제목**을 앱 세션 파일에서 읽어 옵니다(못 읽으면 작업 폴더명).

## 메모리 절약

채팅창을 열 때마다 핸드파일럿 서버가 하나씩 켜지므로, 안 쓰는 채팅창은 최대한 가볍게 둡니다.

| 상태 | 메모리 (실측) |
|---|---|
| 채팅창을 열었지만 핸드파일럿을 안 씀 | 약 64MB (MCP 통신 라이브러리만) |
| 핸드파일럿 사용 중 | 약 136MB (예약 메모리 91MB) |
| `idle_exit_min`(기본 10분) 동안 안 씀 | **0MB** — 서버가 스스로 종료, 다음에 부르면 자동 재시작(1~3초) |

- 화면 처리·마우스 조작·정지 감시·표시창은 **첫 도구 호출 때** 불러옵니다.
- numpy 계산 스레드를 1개로 제한해 예약 메모리를 약 490MB → 16MB로 줄였습니다.
- 일시정지 중이거나 작업 중(마지막 동작 후 5초 이내)에는 종료하지 않습니다.
- 자동 종료를 끄려면 `config.json`의 `idle_exit_min`을 `0`으로.

## Claude 앱 창 보호

Claude가 자기 채팅 입력창에 글을 쓰고 Enter를 누르면 **사용자 이름으로 메시지가 나갈 수 있어서**, 기본으로 막아 둡니다.
- 맨 앞 창이 Claude 앱이면 글자 입력·키 입력을 거부합니다(창 전환용 `alt+tab`, `win` 계열, `esc`는 허용).
- 클릭·드래그 위치가 Claude 앱 창이면 거부합니다(작업표시줄 클릭은 허용).
- 끄려면 `config.json`의 `protect_claude_window`를 `false`로.

## 화면 변화 감지

동작 도구는 실행 후 **화면이 0.4초 동안 안 바뀔 때까지** 기다렸다가, Claude가 마지막으로 본 화면과 비교한 결과를 함께 돌려줍니다.

| 상황 | 보내는 것 |
|---|---|
| 변화 없음 | 글자만 (이미지 없음) |
| 일부만 바뀜 | 가까운 변화는 합치고, 멀리 떨어진 변화는 최대 3장까지 따로 잘라낸 이미지 + 각 이미지의 스크린샷/실제 화면 좌표 |
| 화면의 50% 이상 바뀜, 또는 잘린 이미지 5번마다 | 전체 화면 |
| 변화 감지 실패 (원격 데스크톱 등) | 기존 방식(전체 화면)으로 자동 전환 |

- 작업표시줄 시계·알림 영역은 기본으로 무시합니다.
- Claude가 아무것도 안 했는데 계속 바뀌는 곳(시계, 영상, 로딩 아이콘, 채팅창 타이머, 커서 깜빡임)은 자동으로 찾아 무시합니다. 단, 그 곳에 진짜 변화(입력한 글자 등)가 섞이면 보고합니다.
- **Claude 채팅창이 화면에 같이 보이면** 채팅창의 변화도 잡혀서 잘린 이미지가 커질 수 있습니다. 작업할 프로그램을 최대화해 두면 가장 효율적입니다.

`config.json`의 `observe` 항목으로 조절합니다(같은 채팅창에서 바로 적용).

| 항목 | 기본값 | 의미 |
|---|---|---|
| `stable_sec` | 0.4 | 이 시간 동안 안 바뀌면 안정 (0.5 이하 권장, 커서 깜빡임 주기 때문) |
| `no_change_wait_sec` | 0.7 | 아무 변화 없을 때 '변화 없음'으로 결론 내기까지 |
| `max_wait_sec` | 3.0 | 계속 바뀌어도 이 시간이 지나면 캡처 |
| `full_frame_ratio` | 0.5 | 이 비율 이상 바뀌면 전체 화면 |
| `full_every` | 5 | 잘린 이미지를 이만큼 보내면 전체 화면 1번 |
| `crop_margin` | 24 | 잘라낼 때 주변 여유 (스크린샷 px) |
| `max_crops` | 3 | 멀리 떨어진 변화를 따로 보낼 최대 이미지 수 |
| `ignore_taskbar_tray` | true | 작업표시줄 시계·알림 영역 무시 |
| `ignore_regions` | [] | 추가로 무시할 영역 `[[x, y, w, h], ...]` (스크린샷 좌표) |
| `wait_watch` | true | 기록만: 고정 대기 동안 화면이 언제 멈추는지 숫자로 로그에(대기·결과 그대로). 요약은 관리 창 로그 탭 [대기 측정 요약] |
| `wait_watch_poll_sec` | 0.1 | 기록용 비교 간격 |

## 개발 / 수정 방법

플러그인은 설치할 때 `~/.claude/plugins/cache`에 **복사본**이 만들어집니다. 수정 내용에 따라 반영 방법이 다릅니다.

| 고친 파일 | 반영 방법 |
|---|---|
| `actions.py`, `config.json` | 아무것도 안 해도 됨. **같은 채팅창에서 다음 동작부터 바로 적용** (자동 다시 불러오기) |
| `server.py`(도구 추가·입력 항목 변경), `guard.py`, `lease.py` | 그 채팅창의 서버가 다시 켜질 때 반영 (자동 종료 후 재시작, 또는 새 채팅창). 도구 입력 항목 변경은 새 채팅창에서만 보임 |
| `SKILL.md`, `.mcp.json.template`, `plugin.json` | `release.ps1` 실행 후 새 채팅창 열기 |

```powershell
powershell -ExecutionPolicy Bypass -File release.ps1
```

릴리스 순서: `CHANGELOG.md` 맨 위에 `## [새 버전] - 날짜` 항목 작성 → 위 스크립트 실행
(항목이 없으면 멈춤). 버전 반영 · 설치본 업데이트 · git 커밋 `release: vX.Y.Z` · 태그 `vX.Y.Z`까지 한 번에 처리합니다.

## 버전 관리 (git + GitHub 비공개 저장소 `Gobong-Choi/handpilot`)

| 하고 싶은 것 | 명령 |
|---|---|
| 기록 보기 | `git log --oneline --decorate` |
| 예전 버전 코드 보기 | `git show v0.1.3:handpilot/server.py` |
| 두 버전 비교 | `git diff v0.1.4 v0.1.5` |
| 실험 갈래 만들기 | `git switch -c feature/이름` |
| 안정 버전으로 돌아가기 | `git switch main` |
| 실험 합치기 | `git switch main` 후 `git merge feature/이름` |

라이브러리를 추가했다면 `requirements.txt`에 적고 설치하세요:

```bash
.venv/Scripts/python.exe -m pip install -r requirements.txt
```

## 끄기 / 제거

`~/.claude/settings.json`의 `enabledPlugins`에서 `"handpilot@handpilot-local"`을 `false`로 바꾸면 꺼집니다.
완전히 제거하려면 Claude Code CLI로 `plugin uninstall handpilot@handpilot-local`을 실행합니다.

## 주의

- 이 폴더의 **위치나 이름을 바꾸면 동작하지 않습니다**(`.mcp.json`과 마켓플레이스 경로가 이 위치를 가리킴).
- 관리자 권한 확인창(UAC), 로그인/잠금 화면은 조작할 수 없습니다.
- 비밀번호, 결제, 송금, 삭제처럼 되돌리기 어려운 동작은 Claude가 실행 전 확인을 받도록 SKILL.md에 규칙으로 넣어 두었습니다.
- 다중 모니터는 주 모니터만 지원합니다. 스크린샷 1장은 약 1,500토큰을 씁니다.
