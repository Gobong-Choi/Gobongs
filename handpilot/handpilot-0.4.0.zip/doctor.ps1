﻿# 핸드파일럿 상태 점검 (읽기만 함 — 아무것도 고치지 않음)
#
#   powershell -ExecutionPolicy Bypass -File doctor.ps1          # 점검
#   powershell -ExecutionPolicy Bypass -File doctor.ps1 -Fetch   # 원격 저장소의 새 버전까지 확인
#   powershell -ExecutionPolicy Bypass -File doctor.ps1 -Json    # 결과를 JSON으로 (설정창·자동화용)

param([switch]$Fetch, [switch]$Json)

$root = $PSScriptRoot
$py = Join-Path $root ".venv\Scripts\python.exe"
if (-not (Test-Path $py)) {
    Write-Host "❌ Python 가상환경(.venv)이 없습니다 → install.ps1 을 먼저 실행하세요." -ForegroundColor Red
    exit 1
}
$prevEnc = [Console]::OutputEncoding
[Console]::OutputEncoding = [Text.Encoding]::UTF8
$env:PYTHONIOENCODING = "utf-8"
$a = @((Join-Path $root "tools\doctor.py"))
if ($Fetch) { $a += "--fetch" }
if ($Json) { $a += "--json" }
try { & $py @a; $code = $LASTEXITCODE } finally { [Console]::OutputEncoding = $prevEnc }
if ($MyInvocation.InvocationName -ne '&') { exit $code }  # 다른 스크립트 안에서 불렸을 땐 그 스크립트를 끝내지 않음
