"""핸드파일럿 실제 동작 (자동 다시 불러오기 대상).

server.py가 도구를 부를 때마다 이 파일이 바뀌었는지 보고, 바뀌었으면 다시 불러온다.
서버를 다시 켜지 않아도 같은 채팅창에서 바로 반영된다.
다시 불러와도 유지돼야 하는 값(기준 화면, 배율 등)은 모두 ctx.state에 둔다.

화면 변화 감지:
- 동작 직후 화면을 계속 비교하다가 stable_sec 동안 안 바뀌면 그때 캡처한다.
- Claude가 마지막으로 본 화면(기준 화면)과 비교해서 바뀐 부분만 잘라 보낸다.
  바뀐 게 없으면 글자만, 크게 바뀌었거나 일정 횟수마다는 전체 화면을 보낸다.
- 시계·영상·로딩 아이콘처럼 Claude가 아무것도 안 했는데 계속 바뀌는 칸은 자동으로 무시한다.
"""

import ctypes
import io
import sys
import time
from ctypes import wintypes
from collections import deque

import mss
import numpy as np
import pyautogui
import pyperclip
from PIL import Image as PILImage

from mcp.server.mcpserver import Image
from mcp.server.mcpserver.exceptions import ToolError

from guard import Paused  # guard는 다시 불러오지 않으므로 같은 클래스가 유지된다

STEP = 2          # 비교용 샘플링 간격 (원본 px)
CELL = 8          # 비교 칸 크기 (샘플 px) → 원본 16px
CELL_PX = STEP * CELL

OBSERVE_DEFAULTS = {
    "max_width": 1280,            # 전송 이미지 최대 폭 (= 스크린샷 좌표계)
    "settle_delay_sec": 0.1,      # 동작 직후 첫 비교 전 대기
    "poll_sec": 0.05,             # 비교 간격 (캡처 시간 별도)
    "stable_sec": 0.4,            # 이 시간 동안 안 바뀌면 안정으로 판단 (깜빡이는 커서 때문에 0.5 이하 권장)
    "no_change_wait_sec": 0.7,    # 아무 변화도 없을 때 '변화 없음'으로 결론 내기까지 기다리는 시간
    "max_wait_sec": 3.0,          # 계속 바뀌어도 이 시간이 지나면 캡처
    "pixel_threshold": 24,        # 픽셀 색 차이가 이보다 커야 바뀐 것으로 봄 (0~255)
    "min_change_area_px": 512,    # 이보다 작은 변화 덩어리는 무시 (원본 px², 16x16 칸 2개)
    "full_frame_ratio": 0.5,      # 바뀐 영역이 화면의 이 비율 이상이면 전체 화면
    "full_every": 5,              # 잘린 이미지를 이만큼 보내면 다음엔 전체 화면
    "crop_margin": 24,            # 잘라낼 때 주변 여유 (스크린샷 px)
    "max_crops": 3,               # 멀리 떨어진 변화는 합치지 않고 이만큼까지 따로 잘라 보냄
    "ignore_taskbar_tray": True,  # 작업표시줄 오른쪽(시계·알림 아이콘) 무시
    "ignore_regions": [],         # 추가로 무시할 영역 [[x, y, w, h], ...] (스크린샷 좌표)
    "noise_hits": 2,              # Claude가 안 건드렸는데 이만큼 바뀐 칸은 자동 무시
    "noise_ttl_sec": 60,          # 자동 무시 유지 시간 (그동안 안 바뀌면 해제)
    "wait_watch": True,           # 기록만: 고정 대기(wait) 동안 화면이 언제 바뀌고 멈췄는지 숫자로 로그에 남김(대기·결과는 그대로)
    "wait_watch_poll_sec": 0.1,   # 기록용 비교 간격 (작을수록 정확, CPU 더 씀)
}

# Claude 앱 창 보호: Claude가 자기 채팅창에 글을 쓰거나 버튼을 누르면 사용자 이름으로 메시지가 나갈 수 있다.
PROTECTED_PROCESSES = {"claude.exe"}
WINDOW_SWITCH_KEYS = {"win", "winleft", "winright", "alt+tab", "alt+shift+tab", "esc"}

_user32 = ctypes.windll.user32
_kernel32 = ctypes.windll.kernel32


class _POINT(ctypes.Structure):
    _fields_ = [("x", ctypes.c_long), ("y", ctypes.c_long)]


def _process_name(hwnd) -> str:
    pid = ctypes.c_ulong()
    _user32.GetWindowThreadProcessId(_user32.GetAncestor(hwnd, 2), ctypes.byref(pid))
    h = _kernel32.OpenProcess(0x1000, False, pid.value)  # PROCESS_QUERY_LIMITED_INFORMATION
    if not h:
        return ""
    try:
        buf = ctypes.create_unicode_buffer(1024)
        size = ctypes.c_ulong(len(buf))
        if _kernel32.QueryFullProcessImageNameW(h, 0, buf, ctypes.byref(size)):
            return buf.value.rsplit("\\", 1)[-1].lower()
        return ""
    finally:
        _kernel32.CloseHandle(h)


def _protect(ctx) -> bool:
    return ctx.cfg.get("protect_claude_window", True)


def _guard_keyboard(ctx, what: str) -> None:
    if _protect(ctx) and _process_name(_user32.GetForegroundWindow()) in PROTECTED_PROCESSES:
        raise ToolError(
            f"지금 맨 앞 창이 Claude 앱이라 {what}을(를) 막았습니다(Claude 채팅창에 입력되는 것 방지). "
            "작업할 창을 먼저 앞으로 가져오세요: 작업표시줄의 해당 아이콘 클릭, 또는 key('alt+tab'). "
            "그다음 screenshot으로 확인하고 다시 시도하세요.")


def _guard_point(ctx, sx: int, sy: int, what: str) -> None:
    if _protect(ctx):
        hwnd = _user32.WindowFromPoint(_POINT(sx, sy))
        if hwnd and _process_name(hwnd) in PROTECTED_PROCESSES:
            raise ToolError(
                f"그 위치는 Claude 앱 창이라 {what}을(를) 막았습니다(Claude 채팅창 조작 방지). "
                "작업할 창이 Claude 창에 가려져 있으면 작업표시줄에서 그 창을 먼저 앞으로 가져오세요.")


def _log(ctx, msg: str) -> None:
    ctx.log(f"[actions] {msg}")


def _ocfg(ctx) -> dict:
    o = dict(OBSERVE_DEFAULTS)
    o.update(ctx.cfg.get("observe", {}))
    return o


# ---------------------------------------------------------------- 좌표

def _ensure_geometry(ctx) -> None:
    st = ctx.state
    if "scale" in st:
        return
    with mss.MSS() as sct:
        mon = sct.monitors[1]
    _set_geometry(ctx, mon["width"], mon["left"], mon["top"])


def _set_geometry(ctx, width: int, left: int, top: int) -> None:
    max_w = _ocfg(ctx)["max_width"]
    ctx.state["scale"] = width / max_w if width > max_w else 1.0
    ctx.state["origin"] = (left, top)


def _to_screen(ctx, x: int, y: int) -> tuple[int, int]:
    _ensure_geometry(ctx)
    s, (ox, oy) = ctx.state["scale"], ctx.state["origin"]
    return ox + round(x * s), oy + round(y * s)


# ---------------------------------------------------------------- 캡처/비교

def _grab(sct, mon) -> np.ndarray:
    raw = sct.grab(mon)
    return np.frombuffer(raw.bgra, dtype=np.uint8).reshape(raw.height, raw.width, 4)


def _changed_cells(a: np.ndarray, b: np.ndarray, thr: int) -> np.ndarray:
    d = np.abs(a[::STEP, ::STEP, :3].astype(np.int16) - b[::STEP, ::STEP, :3]).max(axis=2) > thr
    ph, pw = -d.shape[0] % CELL, -d.shape[1] % CELL
    if ph or pw:
        d = np.pad(d, ((0, ph), (0, pw)))
    return d.reshape(d.shape[0] // CELL, CELL, d.shape[1] // CELL, CELL).any(axis=(1, 3))


def _cell_shape(frame: np.ndarray) -> tuple[int, int]:
    h, w = frame.shape[:2]
    return -(-h // CELL_PX), -(-w // CELL_PX)


def _ignore_mask(ctx, frame: np.ndarray) -> np.ndarray:
    o, st = _ocfg(ctx), ctx.state
    mask = np.zeros(_cell_shape(frame), dtype=bool)
    h, w = frame.shape[:2]

    def block(x0, y0, x1, y1):  # 원본 px
        mask[max(0, y0 // CELL_PX):max(0, -(-y1 // CELL_PX)),
             max(0, x0 // CELL_PX):max(0, -(-x1 // CELL_PX))] = True

    if o["ignore_taskbar_tray"]:
        dpi = ctypes.windll.user32.GetDpiForSystem() / 96
        block(w - int(320 * dpi), h - int(52 * dpi), w, h)
    s = st.get("scale", 1.0)
    for x, y, rw, rh in o["ignore_regions"]:
        block(int(x * s), int(y * s), int((x + rw) * s), int((y + rh) * s))
    return mask


def _noise_mask(ctx, shape, now: float, dilate: bool = True) -> np.ndarray:
    st, o = ctx.state, _ocfg(ctx)
    count, last = st.get("noise_count"), st.get("noise_last")
    if count is None or count.shape != shape:
        return np.zeros(shape, dtype=bool)
    noisy = (count >= o["noise_hits"]) & (now - last <= o["noise_ttl_sec"])
    return _dilate(noisy) if dilate and noisy.any() else noisy


def _dilate(m: np.ndarray) -> np.ndarray:
    """주변 1칸까지 넓힌다."""
    p = np.pad(m, 1)
    out = np.zeros_like(m)
    for dy in range(3):
        for dx in range(3):
            out |= p[dy:dy + m.shape[0], dx:dx + m.shape[1]]
    return out


def _note_noise(ctx, cells: np.ndarray, now: float, hits: int = 1) -> None:
    """Claude가 아무 동작도 안 했는데 바뀐 칸을 기록한다."""
    st, o = ctx.state, _ocfg(ctx)
    if st.get("noise_count") is None or st["noise_count"].shape != cells.shape:
        st["noise_count"] = np.zeros(cells.shape, dtype=np.int16)
        st["noise_last"] = np.zeros(cells.shape, dtype=np.float64)
    count, last = st["noise_count"], st["noise_last"]
    count[now - last > o["noise_ttl_sec"]] = 0
    count[cells] += hits
    last[cells] = now


def _components(cells: np.ndarray, min_area_px: int,
                noisy: np.ndarray | None = None) -> list[tuple[int, int, int, int]]:
    """바뀐 칸 덩어리(8방향 연결)의 범위 목록 (칸 단위 x0, y0, x1, y1 포함).
    작은 덩어리와, 전부 '계속 바뀌는 칸'으로만 이뤄진 덩어리(시계·커서 깜빡임)는 버린다.
    입력한 글자처럼 진짜 변화가 섞인 덩어리는 커서 칸까지 포함해 그대로 남긴다."""
    ys, xs = np.nonzero(cells)
    if len(ys) == 0:
        return []
    if len(ys) > 4000:  # 너무 많이 바뀜 → 하나로
        return [(int(xs.min()), int(ys.min()), int(xs.max()), int(ys.max()))]
    todo = set(zip(ys.tolist(), xs.tolist()))
    out = []
    while todo:
        stack = [todo.pop()]
        y0 = y1 = stack[0][0]
        x0 = x1 = stack[0][1]
        real = noisy is None
        while stack:
            cy, cx = stack.pop()
            if not real and not noisy[cy, cx]:
                real = True
            y0, y1, x0, x1 = min(y0, cy), max(y1, cy), min(x0, cx), max(x1, cx)
            for dy in (-1, 0, 1):
                for dx in (-1, 0, 1):
                    n = (cy + dy, cx + dx)
                    if n in todo:
                        todo.remove(n)
                        stack.append(n)
        if real and (x1 - x0 + 1) * (y1 - y0 + 1) * CELL_PX * CELL_PX >= min_area_px:
            out.append((x0, y0, x1, y1))
    return out


def _encode(ctx, frame: np.ndarray) -> tuple[Image, tuple[int, int]]:
    """원본 BGRA 조각을 스크린샷 배율로 줄여 PNG로."""
    s = ctx.state.get("scale", 1.0)
    img = PILImage.fromarray(np.ascontiguousarray(frame[:, :, 2::-1]))
    if s != 1.0:
        img = img.resize((max(1, round(img.width / s)), max(1, round(img.height / s))), PILImage.LANCZOS)
    buf = io.BytesIO()
    img.save(buf, "PNG")
    return Image(data=buf.getvalue(), format="png"), img.size


# ---------------------------------------------------------------- 관찰

def _wait_stable(ctx, max_wait: float | None = None):
    """화면이 stable_sec 동안 안 바뀔 때까지 기다린 뒤 마지막 프레임을 돌려준다."""
    o, guard = _ocfg(ctx), ctx.guard
    max_wait = o["max_wait_sec"] if max_wait is None else max_wait
    with mss.MSS() as sct:
        mon = sct.monitors[1]
        _set_geometry(ctx, mon["width"], mon["left"], mon["top"])
        guard.sleep(o["settle_delay_sec"])
        start = time.monotonic()
        prev = _grab(sct, mon)
        base_ignore = _ignore_mask(ctx, prev)
        noisy = _noise_mask(ctx, _cell_shape(prev), start)
        ignore = base_ignore | noisy
        last_change, recent = None, deque()
        while True:
            guard.sleep(o["poll_sec"])
            cur = _grab(sct, mon)
            now = time.monotonic()
            if cur.shape != prev.shape:  # 해상도 변경
                prev, last_change = cur, now
                base_ignore = _ignore_mask(ctx, cur)
                noisy = np.zeros(_cell_shape(cur), dtype=bool)
                continue
            raw = _changed_cells(prev, cur, o["pixel_threshold"]) & ~base_ignore
            m = raw & ~noisy
            if (raw & noisy).any():  # 무시 중인 칸이 아직도 바뀜 → 유지 시간 연장
                ctx.state["noise_last"][(raw & noisy) & (ctx.state["noise_count"] > 0)] = now
            prev = cur
            if m.any():
                last_change = now
                recent.append((now, m))
            while recent and now - recent[0][0] > 1.0:
                recent.popleft()
            quiet = now - (last_change or start)
            if quiet >= o["stable_sec"] and (last_change or now - start >= o["no_change_wait_sec"]):
                return cur, True, now - start
            if now - start >= max_wait:
                if recent:  # 끝까지 계속 바뀐 칸 → 영상·로딩 아이콘으로 보고 바로 자동 무시
                    _note_noise(ctx, np.logical_or.reduce([mm for _, mm in recent]), now,
                                hits=o["noise_hits"])
                return cur, False, now - start


def _note_idle_changes(ctx) -> None:
    """동작 직전: Claude가 마지막으로 본 뒤 저절로 바뀐 칸(시계, 타이머, 커서 깜빡임)을 기록."""
    base = ctx.state.get("baseline")
    if ctx.state.pop("unobserved", False):  # 관찰 안 한 동작(observe=False)의 결과는 '저절로 바뀐 것'이 아님
        return
    if base is None:
        return
    with mss.MSS() as sct:
        cur = _grab(sct, sct.monitors[1])
    if cur.shape != base.shape:
        return
    m = _changed_cells(base, cur, _ocfg(ctx)["pixel_threshold"]) & ~_ignore_mask(ctx, cur)
    if m.any():
        _note_noise(ctx, m, time.monotonic())


def _report(ctx, frame: np.ndarray, mode: str, waited: float, stable: bool) -> list:
    o, st = _ocfg(ctx), ctx.state
    s = st.get("scale", 1.0)
    h, w = frame.shape[:2]
    wait_note = f"대기 {waited:.1f}초" + ("" if stable else f", ⚠ {waited:.1f}초 동안 계속 바뀌는 영역 있음(자동 무시 처리)")
    base = st.get("baseline")
    reason = None
    if mode == "full":
        reason = "전체 화면 요청"
    elif base is None or base.shape != frame.shape:
        reason = "기준 화면 없음"
    else:
        now = time.monotonic()
        noisy = _noise_mask(ctx, _cell_shape(frame), now, dilate=False)  # 넓히면 커서 옆 글자까지 버려짐
        cells = _changed_cells(base, frame, o["pixel_threshold"]) & ~_ignore_mask(ctx, frame)
        comps = _components(cells, o["min_change_area_px"], noisy)
        if not comps:
            return [f"변화 없음 ({wait_note}). 화면이 이전에 본 그대로입니다."]
        m = int(o["crop_margin"] * s)
        boxes = [(max(0, cx0 * CELL_PX - m), max(0, cy0 * CELL_PX - m),
                  min(w, (cx1 + 1) * CELL_PX + m), min(h, (cy1 + 1) * CELL_PX + m))
                 for cx0, cy0, cx1, cy1 in comps]
        boxes = _group_boxes(boxes, o["max_crops"])
        ratio = sum(_area(b) for b in boxes) / (w * h)
        if ratio >= o["full_frame_ratio"]:
            reason = f"화면의 {ratio:.0%}가 바뀜"
        elif st.get("since_full", 0) >= o["full_every"]:
            reason = "주기적 전체 확인"

    if reason:
        image, size = _encode(ctx, frame)
        st["baseline"] = frame.copy()
        st["since_full"] = 0
        return [f"전체 화면 {size[0]}x{size[1]} ({reason}, {wait_note}). 좌표는 이 이미지 기준.", image]

    ox, oy = st["origin"]
    lines, images = [], []
    for i, (x0, y0, x1, y1) in enumerate(boxes, 1):
        crop = frame[y0:y1, x0:x1]
        image, size = _encode(ctx, crop)
        base[y0:y1, x0:x1] = crop  # Claude가 본 화면 갱신
        sx, sy = round(x0 / s), round(y0 / s)
        lines.append(f"이미지 {i}: 스크린샷 좌표 x={sx}~{sx + size[0]}, y={sy}~{sy + size[1]} "
                     f"(시작점 {sx},{sy} / 실제 화면 x={ox + x0}~{ox + x1}, y={oy + y0}~{oy + y1})")
        images.append(image)
    st["since_full"] = st.get("since_full", 0) + 1
    return [
        f"화면 일부만 바뀜 ({len(comps)}곳 → 이미지 {len(images)}장, {wait_note}). "
        + " / ".join(lines)
        + ". 각 이미지의 픽셀 (px, py)는 스크린샷 좌표 (시작점x+px, 시작점y+py)입니다. "
          "나머지 화면은 이전에 본 그대로입니다.",
        *images,
    ]


def _area(b) -> int:
    return (b[2] - b[0]) * (b[3] - b[1])


def _union(a, b):
    return min(a[0], b[0]), min(a[1], b[1]), max(a[2], b[2]), max(a[3], b[3])


def _group_boxes(boxes: list, max_n: int) -> list:
    """가까운 상자는 합치고, 합치면 빈 공간이 많아지는 먼 상자는 max_n개까지 따로 둔다."""
    boxes = list(boxes)
    if len(boxes) > 40:
        u = boxes[0]
        for b in boxes[1:]:
            u = _union(u, b)
        return [u]
    while len(boxes) > 1:
        best = None
        for i in range(len(boxes)):
            for j in range(i + 1, len(boxes)):
                u = _union(boxes[i], boxes[j])
                waste = _area(u) - _area(boxes[i]) - _area(boxes[j])
                if best is None or waste < best[0]:
                    best = (waste, i, j, u)
        waste, i, j, u = best
        if len(boxes) <= max_n and waste > 0.3 * _area(u):
            break
        boxes[i] = u
        del boxes[j]
    return boxes


def _observe(ctx, mode: str = "auto", max_wait: float | None = None) -> list:
    try:
        frame, stable, waited = _wait_stable(ctx, max_wait)
        return _report(ctx, frame, mode, waited, stable)
    except (ToolError, Paused):
        raise
    except Exception as e:
        _log(ctx, f"변화 감지 실패, 기존 방식으로 전환: {e!r}")
        return _plain_screenshot(ctx, f"변화 감지 실패({type(e).__name__}) → 전체 화면")


def _plain_screenshot(ctx, note: str) -> list:
    """변화 감지를 못 쓰는 환경용 기존 방식."""
    with mss.MSS() as sct:
        mon = sct.monitors[1]
        frame = _grab(sct, mon)
    _set_geometry(ctx, mon["width"], mon["left"], mon["top"])
    image, size = _encode(ctx, frame)
    ctx.state["baseline"] = frame.copy()
    ctx.state["since_full"] = 0
    return [f"전체 화면 {size[0]}x{size[1]} ({note}).", image]


def _run(ctx, label: str, observe: bool, do) -> list | str:
    """동작 실행 + (선택) 결과 관찰."""
    kind = sys._getframe(1).f_code.co_name  # click·key 등 (대기 기록용 — 좌표·글자는 남기지 않음)
    if observe:
        try:
            _note_idle_changes(ctx)
        except Exception as e:  # 관찰 준비 실패는 동작을 막지 않는다
            _log(ctx, f"사전 비교 실패: {e!r}")
    do()
    if not observe:
        ctx.state["unobserved"] = True
        ctx.state["last_act"] = {"kind": kind, "observed": False, "end": time.monotonic()}
        return label
    result = _observe(ctx)
    ctx.state["last_act"] = {"kind": kind, "observed": True, "end": time.monotonic()}
    return [f"{label} → {result[0]}", *result[1:]]


# ---------------------------------------------------------------- 도구 구현

def screenshot(ctx, mode: str = "auto"):
    if mode not in ("auto", "full"):
        raise ToolError("mode는 auto 또는 full이어야 합니다.")
    try:
        _note_idle_changes(ctx)
    except Exception as e:
        _log(ctx, f"사전 비교 실패: {e!r}")
    return _observe(ctx, mode)


def click(ctx, x: int, y: int, button: str, clicks: int, observe: bool):
    if button not in ("left", "right", "middle"):
        raise ToolError("button은 left, right, middle 중 하나여야 합니다.")
    sx, sy = _to_screen(ctx, x, y)
    _guard_point(ctx, sx, sy, "클릭")
    return _run(ctx, f"{button} 클릭 x{clicks} at ({x},{y})", observe,
                lambda: pyautogui.click(sx, sy, clicks=clicks, interval=0.08, button=button))


def move(ctx, x: int, y: int, observe: bool):
    sx, sy = _to_screen(ctx, x, y)
    return _run(ctx, f"이동 ({x},{y})", observe, lambda: pyautogui.moveTo(sx, sy, duration=0.2))


def drag(ctx, from_x: int, from_y: int, to_x: int, to_y: int, observe: bool):
    fx, fy = _to_screen(ctx, from_x, from_y)
    tx, ty = _to_screen(ctx, to_x, to_y)
    _guard_point(ctx, fx, fy, "드래그")
    _guard_point(ctx, tx, ty, "드래그")

    def do():
        pyautogui.moveTo(fx, fy, duration=0.15)
        ctx.guard.check()
        pyautogui.dragTo(tx, ty, duration=0.5, button="left")

    return _run(ctx, f"드래그 ({from_x},{from_y}) -> ({to_x},{to_y})", observe, do)


def type_text(ctx, text: str, observe: bool):
    _guard_keyboard(ctx, "글자 입력")

    def do():
        try:
            previous = pyperclip.paste()
        except pyperclip.PyperclipException:
            previous = None
        pyperclip.copy(text)
        pyautogui.hotkey("ctrl", "v")
        time.sleep(0.15)
        if previous is not None:
            pyperclip.copy(previous)

    return _run(ctx, f"{len(text)}자 입력", observe, do)


def key(ctx, combo: str, observe: bool):
    keys = [k.strip().lower() for k in combo.split("+") if k.strip()]
    unknown = [k for k in keys if k not in pyautogui.KEYBOARD_KEYS]
    if not keys or unknown:
        raise ToolError(f"알 수 없는 키: {unknown or combo}")
    if "+".join(keys) not in WINDOW_SWITCH_KEYS and keys[0] not in ("win", "winleft", "winright"):
        _guard_keyboard(ctx, f"키 입력({combo})")
    return _run(ctx, f"키 입력 {combo}", observe, lambda: pyautogui.hotkey(*keys))


def scroll(ctx, amount: int, x: int | None, y: int | None, observe: bool):
    def do():
        if x is not None and y is not None:
            pyautogui.moveTo(*_to_screen(ctx, x, y))
        pyautogui.scroll(amount * 120)

    return _run(ctx, f"스크롤 {amount}", observe, do)


ZOOM_MAX_EDGE = 1568  # Claude 이미지 긴 변 권장 최대


def zoom(ctx, x: int, y: int, width: int, height: int):
    """화면 일부를 원본 해상도로(작은 글씨 읽기용). 화면 기준(변화 감지)은 바꾸지 않는다."""
    if width <= 0 or height <= 0:
        raise ToolError("width와 height는 1 이상이어야 합니다(스크린샷 좌표 기준 크기).")
    with mss.MSS() as sct:
        mon = sct.monitors[1]
        _set_geometry(ctx, mon["width"], mon["left"], mon["top"])
        s = ctx.state["scale"]
        # 스크린샷 좌표 → 원본 좌표, 화면 밖은 잘라냄
        nx0 = max(0, min(mon["width"] - 1, round(x * s)))
        ny0 = max(0, min(mon["height"] - 1, round(y * s)))
        nx1 = max(nx0 + 1, min(mon["width"], round((x + width) * s)))
        ny1 = max(ny0 + 1, min(mon["height"], round((y + height) * s)))
        raw = sct.grab({"left": mon["left"] + nx0, "top": mon["top"] + ny0, "width": nx1 - nx0, "height": ny1 - ny0})
    img = PILImage.frombytes("RGB", raw.size, raw.rgb)
    shrink = min(1.0, ZOOM_MAX_EDGE / max(img.width, img.height))
    if shrink < 1.0:
        img = img.resize((max(1, round(img.width * shrink)), max(1, round(img.height * shrink))), PILImage.LANCZOS)
    buf = io.BytesIO()
    img.save(buf, "PNG")
    sx0, sy0 = nx0 / s, ny0 / s                 # 실제로 잡은 영역(스크린샷 좌표)
    sw, sh = (nx1 - nx0) / s, (ny1 - ny0) / s
    k = img.width / sw                          # 확대 이미지 px / 스크린샷 px
    note = "원본과 같은 해상도" if s == 1.0 and shrink == 1.0 else f"스크린샷보다 {k:.2f}배 크게"
    text = (f"확대 이미지 {img.width}x{img.height}: 스크린샷 좌표 x={sx0:.0f}~{sx0 + sw:.0f}, y={sy0:.0f}~{sy0 + sh:.0f} 영역({note}). "
            f"이 이미지의 픽셀 (px, py)는 스크린샷 좌표 ({sx0:.0f} + px/{k:.2f}, {sy0:.0f} + py/{k:.2f})입니다. "
            "클릭할 땐 이 공식으로 바꾼 스크린샷 좌표를 쓰세요. (읽기 전용 — 변화 감지 기준 화면은 바뀌지 않음)")
    return [text, Image(data=buf.getvalue(), format="png")]


WATCH_MAX_BURSTS = 30  # 기록 한 줄에 남길 변화 구간 수 (깜빡임이 많아도 로그가 커지지 않게)


def _bursts(samples: list, join: float) -> list:
    """(시각, 바뀐 칸 수) 목록 → 변화 구간 [시작, 끝, 최대 칸 수] (join초 이내 간격은 한 구간으로)."""
    out = []
    for t, n in samples:
        if out and t - out[-1][1] <= join:
            out[-1][1] = t
            out[-1][2] = max(out[-1][2], n)
        else:
            out.append([t, t, n])
    return out


def _watch_fixed_wait(ctx, seconds: float) -> None:
    """기록만: 고정 대기를 그대로 다 기다리면서 그동안 화면이 언제 바뀌고 멈췄는지 로그에 남긴다.
    Claude에게 가는 결과·대기 시간·변화 감지 기준 화면·자동 무시 기록은 바꾸지 않는다(읽기만).
    '계속 바뀌는 칸 자동 무시'를 뺀 기록(all)과 적용한 기록(clean)을 함께 남겨, 대기 방식을 바꿨다면
    어땠을지(tools/wait_report.py)를 나중에 계산한다. 화면 내용은 남기지 않고 시각·칸 수만."""
    o, guard = _ocfg(ctx), ctx.guard
    start = time.monotonic()
    end = start + seconds
    poll = max(0.05, float(o.get("wait_watch_poll_sec", 0.1)))
    last = ctx.state.get("last_act") or {}
    s_all, s_clean, polls, cells = [], [], 0, 0
    paused = False

    def record():
        join = max(0.25, 2.5 * poll)
        b_all, b_clean = _bursts(s_all, join), _bursts(s_clean, join)
        rec = {
            "req": round(seconds, 2), "poll": poll, "polls": polls, "cells": cells,
            "after": last.get("kind"), "after_observed": last.get("observed"),
            "gap": round(start - last["end"], 2) if last.get("end") else None,
            "all": b_all[:WATCH_MAX_BURSTS], "clean": b_clean[:WATCH_MAX_BURSTS],
            "trunc": len(b_all) > WATCH_MAX_BURSTS,
            "busy_end": bool(b_all and b_all[-1][1] >= seconds - 1.0),
        }
        if paused:
            rec["paused"] = True
        ctx.log("[actions] 고정 대기 기록", "info", watch=rec)

    try:
        with mss.MSS() as sct:
            mon = sct.monitors[1]
            _set_geometry(ctx, mon["width"], mon["left"], mon["top"])
            prev = _grab(sct, mon)
            base_ignore = _ignore_mask(ctx, prev)
            noisy = _noise_mask(ctx, _cell_shape(prev), start, dilate=False)
            cells = int(base_ignore.size)
            while True:
                left = end - time.monotonic()
                if left <= 0:
                    break
                guard.sleep(min(poll, left))
                cur = _grab(sct, mon)
                t = round(time.monotonic() - start, 2)
                polls += 1
                if cur.shape != prev.shape:  # 해상도 변경 — 화면 전체가 바뀐 것으로 기록
                    s_all.append((t, cells))
                    s_clean.append((t, cells))
                    prev = cur
                    base_ignore = _ignore_mask(ctx, cur)
                    noisy = np.zeros(_cell_shape(cur), dtype=bool)
                    continue
                raw = _changed_cells(prev, cur, o["pixel_threshold"]) & ~base_ignore
                n_all = int(raw.sum())
                if n_all:
                    s_all.append((t, n_all))
                    n_clean = int((raw & ~noisy).sum())
                    if n_clean:
                        s_clean.append((t, n_clean))
                prev = cur
    except Paused:
        paused = True
        record()
        raise
    except Exception as e:  # 기록이 실패해도 대기는 원래대로
        _log(ctx, f"대기 기록 실패(대기는 그대로): {e!r}")
        rest = end - time.monotonic()
        if rest > 0:
            guard.sleep(rest)
        return
    record()


# ---------------------------------------------------------------- 창 찾기·앞으로 (windows)

# 한국어로 부르는 프로그램 이름 → 실행 파일 이름(.exe 뺀 것)
APP_ALIASES = {
    "크롬": "chrome", "구글 크롬": "chrome", "엣지": "msedge", "웨일": "whale", "파이어폭스": "firefox",
    "엑셀": "excel", "워드": "winword", "파워포인트": "powerpnt", "아웃룩": "outlook", "한글": "hwp",
    "메모장": "notepad", "그림판": "mspaint", "탐색기": "explorer", "파일 탐색기": "explorer",
    "카카오톡": "kakaotalk", "카톡": "kakaotalk", "팀즈": "ms-teams", "슬랙": "slack", "노션": "notion",
}
_WNDENUMPROC = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)
WINDOWS_LIST_MAX = 25


def _list_windows() -> list[dict]:
    """작업 표시줄에 나오는 보이는 최상위 창 — 맨 앞부터(Z 순서). 도구 창(핸드파일럿 작동 중 표시창 등)·바탕화면·숨은 앱 창은 뺀다."""
    out = []

    def cb(hwnd, _):
        if not hwnd or not _user32.IsWindowVisible(hwnd) or _user32.GetWindow(hwnd, 4):  # GW_OWNER: 딸린 창
            return True
        n = _user32.GetWindowTextLengthW(hwnd)
        if n == 0 or _user32.GetWindowLongW(hwnd, -20) & 0x80:  # WS_EX_TOOLWINDOW
            return True
        cloaked = wintypes.DWORD(0)
        try:
            ctypes.windll.dwmapi.DwmGetWindowAttribute(hwnd, 14, ctypes.byref(cloaked), 4)  # DWMWA_CLOAKED(숨은 앱 창)
        except OSError:
            pass
        if cloaked.value:
            return True
        buf = ctypes.create_unicode_buffer(n + 1)
        _user32.GetWindowTextW(hwnd, buf, n + 1)
        exe = _process_name(hwnd)
        exe = exe[:-4] if exe.endswith(".exe") else exe
        if exe == "explorer" and buf.value == "Program Manager":  # 바탕화면
            return True
        out.append({"hwnd": hwnd, "exe": exe, "title": buf.value, "min": bool(_user32.IsIconic(hwnd))})
        return True
    _user32.EnumWindows(_WNDENUMPROC(cb), 0)
    return out


def _match_windows(wins: list[dict], q: str) -> list[dict]:
    """q = 목록 번호 / 프로그램 이름(한국어 별칭·실행 파일 이름) / 창 제목 일부.
    우선순위: 번호 > 실행 파일 이름 같음 > 실행 파일 이름 일부 > 제목 일부. 같은 순위면 맨 앞 창부터."""
    q = q.strip()
    if q.isdigit():
        i = int(q) - 1
        return [wins[i]] if 0 <= i < len(wins) else []
    ql = q.lower()
    exe = APP_ALIASES.get(q, APP_ALIASES.get(ql, ql))
    exe = exe[:-4] if exe.endswith(".exe") else exe
    for found in ([w for w in wins if w["exe"] == exe],
                  [w for w in wins if exe and exe in w["exe"]],
                  [w for w in wins if ql and ql in w["title"].lower()]):
        if found:
            return found
    return []


def _fmt_window(i: int, w: dict) -> str:
    t = w["title"] if len(w["title"]) <= 70 else w["title"][:69] + "…"
    return f"{i}. {w['exe']} — {t}" + (" (최소화)" if w["min"] else "")


class _MONITORINFO(ctypes.Structure):
    _fields_ = [("cbSize", wintypes.DWORD), ("rcMonitor", wintypes.RECT), ("rcWork", wintypes.RECT), ("dwFlags", wintypes.DWORD)]


def _fit_rect(win: tuple, src_work: tuple, dst_work: tuple) -> tuple:
    """다른 모니터의 창 위치·크기를 작업 모니터로 옮길 값 (모두 (left, top, right, bottom), 결과는 (x, y, w, h)).
    크기는 유지하되 작업 모니터보다 크면 맞추고, 원래 모니터에서의 상대 위치를 유지하되 화면 밖으로 나가지 않게."""
    w, h = win[2] - win[0], win[3] - win[1]
    dw, dh = dst_work[2] - dst_work[0], dst_work[3] - dst_work[1]
    w, h = min(w, dw), min(h, dh)
    x = dst_work[0] + max(0, min(win[0] - src_work[0], dw - w))
    y = dst_work[1] + max(0, min(win[1] - src_work[1], dh - h))
    return x, y, w, h


def _monitor_work(hmon) -> tuple:
    mi = _MONITORINFO()
    mi.cbSize = ctypes.sizeof(_MONITORINFO)
    _user32.GetMonitorInfoW(ctypes.c_void_p(hmon), ctypes.byref(mi))
    r = mi.rcWork
    return r.left, r.top, r.right, r.bottom


def _work_monitor():
    """핸드파일럿이 보는 모니터(화면 캡처와 같은 mss monitors[1])의 모니터 핸들."""
    with mss.MSS() as sct:
        m = sct.monitors[1]
    _user32.MonitorFromPoint.restype = ctypes.c_void_p
    return _user32.MonitorFromPoint(wintypes.POINT(m["left"] + m["width"] // 2, m["top"] + m["height"] // 2), 2)


def _move_to_monitor(hwnd, target) -> bool:
    """창이 다른 모니터에 있으면 작업 모니터로 옮긴다. 최대화돼 있던 창은 거기서 다시 최대화. 옮겼으면 True."""
    _user32.MonitorFromWindow.restype = ctypes.c_void_p
    src = _user32.MonitorFromWindow(hwnd, 2)  # MONITOR_DEFAULTTONEAREST
    if not src or not target or src == target:
        return False
    was_max = bool(_user32.IsZoomed(hwnd))
    if was_max or _user32.IsIconic(hwnd):
        _user32.ShowWindow(hwnd, 9)  # SW_RESTORE — 원래 크기·위치로 돌린 뒤 옮김
    r = wintypes.RECT()
    _user32.GetWindowRect(hwnd, ctypes.byref(r))
    x, y, w, h = _fit_rect((r.left, r.top, r.right, r.bottom), _monitor_work(src), _monitor_work(target))
    _user32.SetWindowPos(hwnd, None, x, y, w, h, 0x0004 | 0x0010)  # SWP_NOZORDER | SWP_NOACTIVATE
    if was_max:
        _user32.ShowWindow(hwnd, 3)  # SW_MAXIMIZE
    return True


def _focus_window(hwnd) -> bool:
    """창을 맨 앞으로. Windows는 다른 프로그램이 창을 앞으로 가져오는 걸 막으므로 입력 연결 → Alt(핸드파일럿 표시가 붙은 키) 순서로."""
    def front():
        fg = _user32.GetForegroundWindow()
        return bool(fg) and _user32.GetAncestor(fg, 2) == hwnd
    if front():
        return True
    fg = _user32.GetForegroundWindow()
    me = _kernel32.GetCurrentThreadId()
    other = _user32.GetWindowThreadProcessId(fg, None) if fg else 0
    attached = bool(other and other != me and _user32.AttachThreadInput(me, other, True))
    try:
        _user32.BringWindowToTop(hwnd)
        _user32.SetForegroundWindow(hwnd)
    finally:
        if attached:
            _user32.AttachThreadInput(me, other, False)
    time.sleep(0.05)
    if front():
        return True
    _user32.keybd_event(0x12, 0, 0, 0)
    _user32.SetForegroundWindow(hwnd)
    _user32.keybd_event(0x12, 0, 2, 0)
    time.sleep(0.05)
    return front()


def windows(ctx, focus: str, maximize: bool):
    """focus 비움 → 열린 창 목록. focus 있음 → 맞는 창을 맨 앞으로(최소화 해제·선택 최대화) + 전체 화면.
    맞는 창이 없으면 오류로 멈추지 않고 목록과 함께 알려 준다(Claude가 비슷한 창을 번호로 고르거나 사용자에게 묻도록)."""
    wins = _list_windows()
    listing = "\n".join(_fmt_window(i, w) for i, w in enumerate(wins[:WINDOWS_LIST_MAX], 1))
    if len(wins) > WINDOWS_LIST_MAX:
        listing += f"\n… 외 {len(wins) - WINDOWS_LIST_MAX}개"
    if not focus.strip():
        return (f"열린 창 {len(wins)}개 (맨 앞부터):\n{listing}\n"
                "→ windows(focus='번호' 또는 프로그램 이름·제목 일부)로 앞으로 가져올 수 있습니다.")
    found = _match_windows(wins, focus)
    if not found:
        return (f"⚠ '{focus}'에 맞는 창을 찾지 못했습니다(열려 있지 않거나 이름이 다름). 지금 열린 창 {len(wins)}개:\n{listing}\n"
                "→ 비슷한 창이 있으면 그 번호로 다시 부르세요. 없으면 사용자에게 그 프로그램을 열어 달라고 하거나, "
                "확인받은 뒤 실행하세요(win+r 또는 시작 메뉴).")
    w = found[0]
    if w["exe"] == "claude" and _protect(ctx):
        raise ToolError("Claude 앱 창은 조작 대상이 아닙니다(Claude 앱 창 보호). 작업할 다른 프로그램 창을 고르세요.")
    hwnd = w["hwnd"]
    moved = False
    try:
        moved = _move_to_monitor(hwnd, _work_monitor())  # 다른 모니터의 창이면 Claude가 보는 모니터로 옮겨 옴
    except Exception as e:
        _log(ctx, f"작업 모니터로 옮기기 실패: {e!r}")
    if _user32.IsIconic(hwnd):
        _user32.ShowWindow(hwnd, 9)  # SW_RESTORE
    if maximize:
        _user32.ShowWindow(hwnd, 3)  # SW_MAXIMIZE
    ok = _focus_window(hwnd)
    name = f"「{w['exe']} — {w['title'][:60]}」"
    if ok:
        note = (f"{name} 창을 맨 앞으로" + (" (최소화 해제)" if w["min"] else "")
                + (" · 다른 모니터에 있어 작업 모니터로 옮겨 옴" if moved else "") + (" · 최대화" if maximize else ""))
    else:
        note = f"⚠ {name} 창을 앞으로 가져오지 못했습니다(Windows가 막음) — 화면을 보고 작업 표시줄에서 그 창을 클릭하세요"
    others = found[1:4]
    if others:
        note += " / 같은 조건의 다른 창: " + " · ".join(_fmt_window(wins.index(o) + 1, o) for o in others) + " (다른 창이면 번호로)"
    result = _observe(ctx, "full", max_wait=1.5)  # 앞으로 온 화면을 새 기준으로(따로 screenshot 불필요). 창 전환은 금방 끝나 대기 짧게
    return [f"{note}. {result[0]}", *result[1:]]


def wait(ctx, seconds: float, until_stable: bool):
    seconds = max(0.0, min(seconds, 10.0))
    if until_stable:
        result = _observe(ctx, max_wait=max(seconds, 0.5))
        return [f"화면 안정 대기(최대 {seconds}초) → {result[0]}", *result[1:]]
    if _ocfg(ctx).get("wait_watch") and seconds >= 1.0:
        _watch_fixed_wait(ctx, seconds)
    else:
        ctx.guard.sleep(seconds)
    return f"{seconds}초 대기"
