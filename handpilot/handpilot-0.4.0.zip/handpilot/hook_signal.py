"""Claude Code 훅 → 핸드파일럿 서버 신호.

hooks/hooks.json(설치 때 생성)이 Claude Code의 Stop(답변 끝남)·UserPromptSubmit(사용자가 새 메시지를 보냄) 때 실행한다.
이 채팅창의 Claude Code 프로세스(가장 가까운 claude.exe 조상) PID 이름으로 신호 파일을 남기면,
같은 채팅창의 핸드파일럿 서버(lease.py)가 0.5초마다 확인해 조작권을 반납하거나 [종료] 알림을 정리한다.

- 표준 라이브러리만 쓴다(빠르게 끝나도록). 모든 채팅창의 답변마다 실행되므로 하는 일은 파일 하나 쓰기뿐.
- 무슨 일이 있어도 아무것도 출력하지 않고 0으로 끝난다(훅이 Claude의 동작을 막지 않게).
"""

import ctypes
import json
import os
import sys
import time
from ctypes import wintypes
from pathlib import Path

SIGNAL_DIR = Path(os.environ.get("LOCALAPPDATA", str(Path.home()))) / "handpilot" / "signals"


class _PE(ctypes.Structure):
    _fields_ = [("dwSize", wintypes.DWORD), ("cntUsage", wintypes.DWORD), ("th32ProcessID", wintypes.DWORD),
                ("th32DefaultHeapID", ctypes.c_void_p), ("th32ModuleID", wintypes.DWORD),
                ("cntThreads", wintypes.DWORD), ("th32ParentProcessID", wintypes.DWORD),
                ("pcPriClassBase", ctypes.c_long), ("dwFlags", wintypes.DWORD), ("szExeFile", ctypes.c_wchar * 260)]


def claude_pid() -> int:
    k = ctypes.WinDLL("kernel32")
    k.CreateToolhelp32Snapshot.restype = ctypes.c_void_p
    k.Process32FirstW.argtypes = [ctypes.c_void_p, ctypes.POINTER(_PE)]
    k.Process32NextW.argtypes = [ctypes.c_void_p, ctypes.POINTER(_PE)]
    k.CloseHandle.argtypes = [ctypes.c_void_p]
    snap = k.CreateToolhelp32Snapshot(0x2, 0)
    table = {}
    try:
        e = _PE()
        e.dwSize = ctypes.sizeof(e)
        ok = k.Process32FirstW(snap, ctypes.byref(e))
        while ok:
            table[e.th32ProcessID] = (e.th32ParentProcessID, e.szExeFile.lower())
            ok = k.Process32NextW(snap, ctypes.byref(e))
    finally:
        k.CloseHandle(snap)
    pid = os.getpid()
    for _ in range(12):
        parent = table.get(pid)
        if not parent:
            return 0
        pid = parent[0]
        if table.get(pid, (0, ""))[1] == "claude.exe":
            return pid
    return 0


def main() -> None:
    event = sys.argv[1] if len(sys.argv) > 1 else "unknown"  # stop | prompt
    try:
        data = json.load(sys.stdin)
    except Exception:
        data = {}
    pid = claude_pid()
    if not pid:
        return
    SIGNAL_DIR.mkdir(parents=True, exist_ok=True)
    (SIGNAL_DIR / f"{pid}.{event}").write_text(
        json.dumps({"ts": time.time(), "session_id": data.get("session_id"), "hook": data.get("hook_event_name")}),
        encoding="utf-8")


try:
    main()
except Exception:
    pass
sys.exit(0)
