"""핸드파일럿 자체 로그.

- 위치: %LOCALAPPDATA%\\handpilot\\logs\\handpilot-YYYY-MM-DD.log (하루 한 파일, 한 줄 = JSON 하나)
- 여러 채팅창의 서버가 같은 파일에 덧붙여 쓴다(줄마다 pid·채팅창 이름 포함).
- 입력한 글자 내용은 기록하지 않는다(글자 수만) — 고객 정보가 로그에 남지 않게.
- log_retention_days(기본 30일)가 지난 파일은 서버가 켜질 때 지운다.
- 같은 내용은 stderr(Claude Code의 MCP 로그)에도 남긴다.
"""

import json
import os
import sys
import threading
import time
from pathlib import Path

LOG_DIR = Path(os.environ.get("LOCALAPPDATA", str(Path.home()))) / "handpilot" / "logs"
_lock = threading.Lock()
_local = threading.local()
_state = {"cfg": {}, "label": None}


def configure(cfg: dict, label_fn=None) -> None:
    """cfg는 서버와 같은 dict(설정이 바뀌면 자동 반영). label_fn은 채팅창 이름을 돌려주는 함수."""
    _state["cfg"] = cfg
    if label_fn is not None:
        _state["label"] = label_fn


def _label():
    fn = _state["label"]
    if fn is None or getattr(_local, "busy", False):
        return None
    _local.busy = True  # 이름 찾기 중 남기는 로그가 다시 이름을 찾지 않게(무한 반복 방지)
    try:
        return fn()
    except Exception:
        return None
    finally:
        _local.busy = False


def log(level: str, comp: str, msg: str, **fields) -> None:
    print(f"[{comp}] {msg}", file=sys.stderr, flush=True)
    cfg = _state["cfg"]
    if not cfg.get("log_enabled", True):
        return
    rec = {"ts": round(time.time(), 3), "time": time.strftime("%Y-%m-%d %H:%M:%S"), "level": level,
           "pid": os.getpid(), "comp": comp, "msg": msg}
    chat = _label()
    if chat:
        rec["chat"] = chat
    rec.update(fields)
    line = json.dumps(rec, ensure_ascii=False, default=str)
    path = LOG_DIR / f"handpilot-{time.strftime('%Y-%m-%d')}.log"
    try:
        with _lock:
            LOG_DIR.mkdir(parents=True, exist_ok=True)
            with open(path, "a", encoding="utf-8") as f:
                f.write(line + "\n")
    except OSError:
        pass  # 로그를 못 써도 동작은 계속


def cleanup(days: float | None = None) -> int:
    """보관 기간이 지난 로그 파일을 지운다. 지운 개수를 돌려준다."""
    days = float(days if days is not None else _state["cfg"].get("log_retention_days", 30))
    if days <= 0 or not LOG_DIR.exists():
        return 0
    cutoff = time.time() - days * 86400
    removed = 0
    for f in LOG_DIR.glob("handpilot-*.log"):
        try:
            day = time.mktime(time.strptime(f.stem.replace("handpilot-", ""), "%Y-%m-%d"))
        except ValueError:
            continue
        if day < cutoff:
            try:
                f.unlink()
                removed += 1
            except OSError:
                pass
    return removed
