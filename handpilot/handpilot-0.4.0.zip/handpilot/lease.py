"""핸드파일럿 조작권 잠금 — 여러 채팅창 중 한 번에 하나만 화면을 조작한다.

채팅창마다 핸드파일럿 서버가 따로 뜨므로, PC 전체에서 공유하는 잠금 파일로 조작권을 나눈다.

- 잠금: %LOCALAPPDATA%\\handpilot\\control.lock 의 첫 1바이트를 파일 핸들로 잠근다(msvcrt.locking).
  서버가 비정상 종료돼도 OS가 핸들을 닫으면서 잠금이 풀린다(남는 잠금 없음).
  (명명된 뮤텍스는 잠근 스레드만 풀 수 있어, 도구마다 다른 스레드에서 도는 MCP 서버엔 맞지 않는다.)
- 보유: 마지막 동작 후 lock_hold_sec(기본 15초) 동안 같은 서버가 계속 쥐고, 그 뒤 스스로 반납한다.
  일시정지 중에는 반납하지 않는다(사용자가 [재개] 또는 [종료]를 눌러야 함).
- 거부: 다른 서버가 쥐고 있으면 기다리지 않고 바로 거부한다. 누가 쥐고 있는지는
  control-owner.json(잠기지 않는 별도 파일)에 적어 두고, 거부할 때 읽어서 알려준다.
- 채팅창 이름: 이 서버를 띄운 Claude Code 프로세스의 세션 ID(--resume)로 앱의 세션 파일에서 제목을 찾는다.
  (앱이 한꺼번에 복원하면 시작 시각이 겹치므로 시각으로는 구분하지 않는다.) 못 찾으면 작업 폴더명.
"""

import ctypes
import glob
import json
import msvcrt
import os
import re
import sys
import threading
import time
from ctypes import wintypes
from pathlib import Path

import hplog

LOCK_DIR = Path(os.environ.get("LOCALAPPDATA", str(Path.home()))) / "handpilot"
LOCK_PATH = LOCK_DIR / "control.lock"
SIGNAL_DIR = LOCK_DIR / "signals"  # hook_signal.py가 남기는 "<claude.exe PID>.stop / .prompt"
OWNER_PATH = LOCK_DIR / "control-owner.json"
# 앱 세션 파일(채팅창 이름). 2026-11 Claude 앱 업데이트로 앱 데이터가 %APPDATA%\Claude → %LOCALAPPDATA%\Claude-Data\claude_<ID>로 옮겨 감
SESSIONS_GLOBS = [
    str(Path(os.environ.get("LOCALAPPDATA", "")) / "Claude-Data" / "claude_*" / "claude-code-sessions" / "*" / "*" / "local_*.json"),
    str(Path(os.environ.get("APPDATA", "")) / "Claude" / "claude-code-sessions" / "*" / "*" / "local_*.json"),
]
SESSIONS_GLOB = SESSIONS_GLOBS[-1]  # 예전 이름(호환)


def session_files() -> list[str]:
    return [p for g in SESSIONS_GLOBS for p in glob.glob(g)]


LABEL_MAX = 28


def _log(msg: str, level: str = "info") -> None:
    hplog.log(level, "lease", msg)


class Busy(Exception):
    """다른 채팅창이 조작권을 쥐고 있음. 메시지는 Claude에게 그대로 전달된다.
    key: 같은 상황(같은 소유자·같은 상태)인지 구분하는 값 — 반복 거부 때 안내를 짧게 하는 데 쓴다."""

    def __init__(self, message: str, key=None):
        super().__init__(message)
        self.key = key


# ---------------------------------------------------------------- 채팅창 이름 찾기

class _PROCESSENTRY32W(ctypes.Structure):
    _fields_ = [("dwSize", wintypes.DWORD), ("cntUsage", wintypes.DWORD), ("th32ProcessID", wintypes.DWORD),
                ("th32DefaultHeapID", ctypes.c_void_p), ("th32ModuleID", wintypes.DWORD),
                ("cntThreads", wintypes.DWORD), ("th32ParentProcessID", wintypes.DWORD),
                ("pcPriClassBase", ctypes.c_long), ("dwFlags", wintypes.DWORD),
                ("szExeFile", ctypes.c_wchar * 260)]


class _UNICODE_STRING(ctypes.Structure):
    _fields_ = [("Length", ctypes.c_ushort), ("MaximumLength", ctypes.c_ushort), ("Buffer", ctypes.c_void_p)]


_k32 = ctypes.WinDLL("kernel32", use_last_error=True)
_k32.CreateToolhelp32Snapshot.restype = ctypes.c_void_p
_k32.Process32FirstW.argtypes = [ctypes.c_void_p, ctypes.POINTER(_PROCESSENTRY32W)]
_k32.Process32NextW.argtypes = [ctypes.c_void_p, ctypes.POINTER(_PROCESSENTRY32W)]
_k32.CloseHandle.argtypes = [ctypes.c_void_p]
_k32.OpenProcess.restype = ctypes.c_void_p


def _process_table() -> dict[int, tuple[int, str]]:
    """pid -> (부모 pid, 실행 파일 이름)"""
    snap = _k32.CreateToolhelp32Snapshot(0x2, 0)  # TH32CS_SNAPPROCESS
    table = {}
    try:
        e = _PROCESSENTRY32W()
        e.dwSize = ctypes.sizeof(e)
        ok = _k32.Process32FirstW(snap, ctypes.byref(e))
        while ok:
            table[e.th32ProcessID] = (e.th32ParentProcessID, e.szExeFile.lower())
            ok = _k32.Process32NextW(snap, ctypes.byref(e))
    finally:
        _k32.CloseHandle(snap)
    return table


def _command_line(pid: int) -> str:
    h = _k32.OpenProcess(0x1000, False, pid)  # PROCESS_QUERY_LIMITED_INFORMATION
    if not h:
        return ""
    try:
        ntdll = ctypes.WinDLL("ntdll")
        size = ctypes.c_ulong(0)
        ntdll.NtQueryInformationProcess(ctypes.c_void_p(h), 60, None, 0, ctypes.byref(size))  # ProcessCommandLineInformation
        if not size.value:
            return ""
        buf = ctypes.create_string_buffer(size.value)
        if ntdll.NtQueryInformationProcess(ctypes.c_void_p(h), 60, buf, size, ctypes.byref(size)) != 0:
            return ""
        us = _UNICODE_STRING.from_buffer(buf)
        return ctypes.wstring_at(us.Buffer, us.Length // 2)
    finally:
        _k32.CloseHandle(h)


def session_process_pid() -> int:
    """이 서버를 띄운 Claude Code 프로세스(가장 가까운 claude.exe 조상)의 PID. 없으면 0."""
    table = _process_table()
    pid = os.getpid()
    for _ in range(12):
        parent = table.get(pid)
        if not parent:
            return 0
        pid = parent[0]
        if table.get(pid, (0, ""))[1] == "claude.exe":
            return pid
    return 0


def _session_id() -> str:
    """이 서버를 띄운 Claude Code 프로세스의 세션 ID(--resume / --session-id)."""
    pid = session_process_pid()
    if not pid:
        return ""
    m = re.search(r"--(?:resume|session-id)[= ]\"?([0-9a-fA-F-]{36})", _command_line(pid))
    return m.group(1) if m else ""


def _short(text: str) -> str:
    text = " ".join(text.split())
    return text if len(text) <= LABEL_MAX else text[:LABEL_MAX - 1] + "…"


class SessionLabel:
    """채팅창 제목을 찾아 기억한다. 제목은 첫 대화 뒤에 생기기도 하므로 가끔 다시 읽는다."""

    def __init__(self):
        self._sid = None
        self._file = None
        self._label = None
        self._read_at = 0.0

    def get(self) -> str:
        forced = os.environ.get("HANDPILOT_SESSION_LABEL")  # 테스트용
        if forced:
            return forced
        if self._label and time.monotonic() - self._read_at < 60:
            return self._label
        try:
            self._label = self._lookup()
        except Exception as e:  # 이름을 못 찾아도 잠금은 동작해야 한다
            _log(f"채팅창 이름 찾기 실패: {e!r}", "warn")
            self._label = self._label or "알 수 없는 채팅창"
        self._read_at = time.monotonic()
        return self._label

    def _lookup(self) -> str:
        if self._sid is None:
            self._sid = _session_id()
        if self._sid and self._file is None:
            for path in session_files():
                try:
                    text = Path(path).read_text(encoding="utf-8")
                except OSError:
                    continue
                if self._sid in text and json.loads(text).get("cliSessionId") == self._sid:
                    self._file = path
                    break
        if self._file:
            d = json.loads(Path(self._file).read_text(encoding="utf-8"))
            if d.get("title"):
                return _short(d["title"])
            if d.get("cwd"):
                return _short(Path(d["cwd"]).name + " 폴더 창")
        return "알 수 없는 채팅창"


# ---------------------------------------------------------------- 조작권

class ControlLease:
    def __init__(self, cfg: dict, guard):
        self.cfg = cfg
        self.guard = guard
        self.label = SessionLabel()
        self.held = False
        self.last_used = 0.0           # 마지막 동작이 끝난 시각 (time.time)
        self._fd = None
        self._lock = threading.Lock()
        self._written = None           # 마지막으로 owner 파일에 쓴 내용 (불필요한 쓰기 방지)
        self._started = False
        # 2단계: Claude Code 훅 신호 (hook_signal.py)
        self.session_pid = 0           # 이 채팅창의 claude.exe PID (신호 파일 이름)
        self.turn_active = False       # 사용자가 새 메시지를 보낸 뒤 아직 답변이 안 끝남
        self.hooks_seen = False        # 이 채팅창에서 훅 신호를 본 적 있음(훅이 동작함)
        self._seen = {"stop": 0.0, "prompt": 0.0}

    def start(self) -> None:
        if self._started:
            return
        LOCK_DIR.mkdir(parents=True, exist_ok=True)
        self._fd = os.open(str(LOCK_PATH), os.O_RDWR | os.O_CREAT, 0o600)
        self._init_signals()
        threading.Thread(target=self._keeper, name="handpilot-lease", daemon=True).start()
        self._started = True

    def hold_sec(self) -> float:
        """답변 중(훅으로 확인)이면 길게 쥐고(답변이 끝나면 Stop 훅으로 바로 반납), 아니면 기본 시간."""
        if self.turn_active:
            return float(self.cfg.get("lock_hold_turn_sec", 90))
        return float(self.cfg.get("lock_hold_sec", 15))

    # ---- 훅 신호 ----
    def _signal_mtime(self, event: str) -> float:
        try:
            return (SIGNAL_DIR / f"{self.session_pid}.{event}").stat().st_mtime
        except OSError:
            return 0.0

    def _init_signals(self) -> None:
        self.session_pid = int(os.environ.get("HANDPILOT_SESSION_PID") or 0) or session_process_pid()
        # 서버가 켜지기 전의 신호는 '이미 본 것'으로: 지난 답변의 Stop 신호로 방금 얻은 조작권을 놓지 않게
        self._seen = {"stop": self._signal_mtime("stop"), "prompt": self._signal_mtime("prompt")}
        self.hooks_seen = any(self._seen.values())
        self._update_turn()
        try:  # 오래된 신호 파일 정리(PID 재사용 혼동 방지)
            for f in SIGNAL_DIR.glob("*.*"):
                if time.time() - f.stat().st_mtime > 2 * 86400:
                    f.unlink()
        except OSError:
            pass

    def _update_turn(self) -> None:
        p, s = self._seen["prompt"], self._seen["stop"]
        self.turn_active = p > s and time.time() - p < 6 * 3600

    def _check_signals(self) -> None:
        if not self.session_pid:
            return
        p, s = self._signal_mtime("prompt"), self._signal_mtime("stop")
        if p > self._seen["prompt"]:
            self._seen["prompt"] = p
            self.hooks_seen = True
            self.guard.clear_ended(before=p)  # [종료] 뒤 사용자가 새로 지시함 → 종료 알림 정리
        if s > self._seen["stop"]:
            prev = self._seen["stop"]
            self._seen["stop"] = s
            self.hooks_seen = True
            self._update_turn()
            used = self.last_used > max(prev, self._seen["prompt"])  # 이번 답변에서 핸드파일럿을 썼나
            if self.held and not self.guard.paused and not self.guard.busy():
                self.release("답변 끝남(Stop 훅)")
            if used and hasattr(self.guard, "on_turn_done"):
                self.guard.on_turn_done()  # Claude 창을 맨 앞으로(설정)
        self._update_turn()

    def remaining(self) -> float:
        return max(0.0, self.last_used + self.hold_sec() - time.time())

    # ---- 잠금 기본 동작 ----
    def _try_lock(self) -> bool:
        os.lseek(self._fd, 0, os.SEEK_SET)
        try:
            msvcrt.locking(self._fd, msvcrt.LK_NBLCK, 1)
            return True
        except OSError:
            return False

    def _unlock(self) -> None:
        os.lseek(self._fd, 0, os.SEEK_SET)
        try:
            msvcrt.locking(self._fd, msvcrt.LK_UNLCK, 1)
        except OSError as e:
            _log(f"잠금 해제 실패: {e!r}", "error")

    # ---- 외부에서 쓰는 동작 ----
    def acquire(self) -> None:
        """조작권을 얻는다. 다른 채팅창이 쥐고 있으면 Busy."""
        with self._lock:
            if self.held:
                return
            if not self._try_lock():
                message, key = self._busy_message()
                raise Busy(message, key)
            self.held = True
            self.last_used = time.time()
            self._write_owner(force=True)
        _log(f"조작권 획득: {self.label.get()}")

    def touch(self) -> None:
        """동작이 끝날 때마다: 보유 시간을 다시 센다."""
        with self._lock:
            if self.held:
                self.last_used = time.time()
                self._write_owner(force=True)

    def release(self, why: str) -> None:
        with self._lock:
            if not self.held:
                return
            self.held = False
            self._unlock()
        _log(f"조작권 반납: {why}")

    def _keeper(self) -> None:
        """보유 시간이 지나면 반납하고, 일시정지 상태를 owner 파일에 반영한다."""
        while True:
            time.sleep(0.5)
            try:
                self._check_signals()
                if not self.held:
                    continue
                if self.guard.paused:
                    with self._lock:
                        if self.held:
                            self._write_owner()
                    continue
                if not self.guard.busy() and self.remaining() <= 0:
                    self.release(f"마지막 동작 후 {self.hold_sec():g}초 지남" + (" (답변 중 최대 시간)" if self.turn_active else ""))
                    continue
                with self._lock:
                    if self.held:
                        self._write_owner()
            except Exception as e:
                _log(f"조작권 관리 오류: {e!r}", "error")

    # ---- owner 파일 ----
    def _write_owner(self, force: bool = False) -> None:
        data = {
            "pid": os.getpid(),
            "label": self.label.get(),
            "last_used": round(self.last_used, 2),
            "hold_sec": self.hold_sec(),
            "paused": bool(self.guard.paused),
            "turn_active": bool(self.turn_active),
        }
        if not force and data == self._written:
            return
        tmp = OWNER_PATH.with_suffix(f".{os.getpid()}.tmp")
        try:
            tmp.write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")
            for _ in range(5):
                try:
                    os.replace(tmp, OWNER_PATH)
                    break
                except PermissionError:  # 다른 서버가 마침 읽는 중
                    time.sleep(0.02)
            self._written = data
        except OSError as e:
            _log(f"owner 파일 쓰기 실패: {e!r}", "warn")

    def _busy_message(self) -> str:
        try:
            o = json.loads(OWNER_PATH.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            o = {}
        key = (o.get("pid"), bool(o.get("paused")))
        who = f"(「{o['label']}」)" if o.get("label") else ""
        if o.get("paused"):
            state = ("그 채팅창이 일시정지 상태로 조작권을 갖고 있어, 사용자가 화면 구석 표시창에서 "
                     "[재개] 또는 [종료]를 눌러야 풀립니다")
        elif o:
            left = max(0, round(o.get("last_used", 0) + o.get("hold_sec", self.hold_sec()) - time.time()))
            if o.get("turn_active"):
                state = f"그 채팅창이 아직 답변 중이라, 답변이 끝나면 바로(늦어도 약 {left}초 뒤) 자동으로 반납됩니다"
            else:
                state = f"그 채팅창의 작업이 끝나면 약 {left}초 뒤 자동으로 반납됩니다"
        else:
            state = "잠시 뒤 자동으로 반납됩니다"
        return (f"다른 채팅창{who}이 핸드파일럿을 사용 중입니다. {state}. "
                "재시도하지 말고 사용자에게 알린 뒤, 사용자가 다시 지시할 때까지 기다리세요."), key
