"""핸드파일럿(handpilot) MCP 서버 — 고정 껍데기.

이 파일에는 도구 목록·입력 항목과 정지 장치(guard)만 있고, 서버가 켜질 때 한 번 읽힌다.
실제 동작은 actions.py에 있으며 파일이 바뀌면 다음 도구 호출 때 자동으로 다시 불러온다.
config.json도 바뀌면 자동으로 다시 읽는다. → 같은 채팅창에서 바로 반영된다.

이 파일(도구 추가·입력 항목 변경)이나 guard.py를 고쳤을 때만 서버 재연결(/mcp)이 필요하다.

메모리 절약 (채팅창마다 서버가 하나씩 켜지므로):
- 화면 처리(numpy 등)·마우스 조작·정지 감시·표시창은 첫 도구 호출 때 불러온다.
  핸드파일럿을 안 쓰는 채팅창은 MCP 통신 라이브러리만 올라간 상태(약 60MB)로 대기한다.
- idle_exit_min 동안 도구를 안 쓰면 서버가 스스로 종료해 메모리를 0으로 만든다.
  다음에 도구를 부르면 Claude Code가 서버를 다시 켠다(1~3초).

여러 채팅창 동시 사용 (lease.py):
- PC 전체에서 한 번에 한 서버만 조작권을 갖는다. 모든 도구(screenshot 포함)는 조작권이 있어야 실행되고,
  다른 채팅창이 쥐고 있으면 기다리지 않고 바로 거부한다.
- 같은 채팅창 안에서도 동작은 한 번에 하나씩 실행한다(동시에 부른 도구가 섞이지 않게).
"""

import ctypes
import functools
import importlib
import os
import sys
import threading
import time
import traceback
import types
from pathlib import Path

# numpy의 계산 스레드가 미리 잡는 메모리(약 490MB 예약)를 막는다. 화면 비교엔 1개로 충분하다.
for _var in ("OPENBLAS_NUM_THREADS", "OMP_NUM_THREADS", "MKL_NUM_THREADS"):
    os.environ.setdefault(_var, "1")

# 고DPI(125%, 150% 배율)에서 스크린샷 좌표와 마우스 좌표가 어긋나지 않도록
# pyautogui import 전에 DPI 인식을 켠다.
try:
    ctypes.windll.shcore.SetProcessDpiAwareness(2)
except (AttributeError, OSError):
    ctypes.windll.user32.SetProcessDPIAware()

from mcp.server.mcpserver import MCPServer
from mcp.server.mcpserver.exceptions import ToolError

from guard import CONFIG_PATH, LOCAL_CONFIG_PATH, Guard, Paused, load_config  # guard는 가벼움(무거운 건 start()에서)
from lease import Busy, ControlLease
import hplog

HERE = Path(__file__).resolve().parent
ACTIONS_PATH = HERE / "actions.py"

mcp = MCPServer(
    "handpilot",
    instructions=(
        "이 PC의 주 모니터를 조작하는 도구입니다. 작업할 프로그램이 정해져 있으면 처음에 windows(focus='크롬' 같은 프로그램 이름)로 "
        "그 창을 맨 앞으로 가져오세요(최소화 해제 + 전체 화면이 함께 옴). 정해져 있지 않으면 screenshot으로 화면을 확인하세요. "
        "클릭·입력·키·스크롤 같은 동작은 끝난 뒤 화면이 안정될 때까지 기다렸다가 결과를 함께 돌려줍니다: "
        "'변화 없음'(글자만), '화면 일부만 바뀜'(바뀐 부분 이미지 + 그 이미지의 스크린샷 좌표 시작점), "
        "'전체 화면' 중 하나입니다. 그러니 동작 후에 screenshot을 따로 부를 필요가 없습니다. "
        "좌표는 항상 전체 스크린샷 좌표계를 쓰세요. 잘린 이미지 안의 위치는 안내된 시작점을 더해서 계산하세요. "
        "전체 상황이 헷갈리면 screenshot(mode='full')을 부르세요. "
        "비밀번호 입력, 결제, 송금, 삭제처럼 되돌리기 어려운 동작은 실행 전에 반드시 사용자에게 확인을 받으세요. "
        "사용자가 마우스/키보드를 만지면 핸드파일럿이 일시정지되며, 이때는 재시도하지 말고 "
        "사용자가 [재개]할 때까지 기다리세요. "
        "'다른 채팅창이 핸드파일럿을 사용 중' 오류가 나면 재시도하지 말고 사용자에게 알린 뒤, "
        "사용자가 다시 지시할 때까지 기다리세요."
    ),
)


def _log(msg: str, level: str = "info", **fields) -> None:
    # stdout은 MCP 통신용이므로 stderr + 자체 로그 파일(hplog)에만 쓴다.
    hplog.log(level, "server", msg, **fields)


cfg = load_config()
guard = Guard(cfg)
control = ControlLease(cfg, guard)  # 여러 채팅창 중 한 곳만 조작 (lease.py)
guard.lease = control
hplog.configure(cfg)  # 채팅창 이름은 런타임이 켜질 때 연결(안 쓰는 채팅창은 찾지 않음)
_op_lock = threading.Lock()         # 같은 채팅창 안에서 동작을 한 번에 하나씩
# actions.py를 다시 불러와도 유지되는 공유 상태
ctx = types.SimpleNamespace(guard=guard, cfg=cfg, state={}, log=_log)

actions = None    # 첫 도구 호출 때 불러옴
pyautogui = None
_runtime_lock = threading.Lock()
_last_used = time.monotonic()


def _ensure_runtime() -> None:
    """첫 도구 호출 때 무거운 라이브러리를 불러오고 정지 감시를 시작한다."""
    global actions, pyautogui
    if actions is not None:
        return
    with _runtime_lock:
        if actions is not None:
            return
        import pyautogui as _pg

        _pg.FAILSAFE = True  # 마우스를 화면 왼쪽 위 모서리로 밀면 즉시 중단
        _pg.PAUSE = 0.15
        pyautogui = _pg
        control.start()
        guard.start()
        import actions as _actions

        _seen["actions"] = _mtime(ACTIONS_PATH)
        actions = _actions
        hplog.configure(cfg, control.label.get)
        removed = hplog.cleanup()
        _log("핸드파일럿 런타임 준비 완료", version=_plugin_version(), old_logs_removed=removed)


def _plugin_version() -> str:
    try:
        import json
        return json.loads((HERE / ".claude-plugin" / "plugin.json").read_text(encoding="utf-8"))["version"]
    except Exception:
        return "?"


def _idle_watchdog() -> None:
    """오래 안 쓰면 스스로 종료해 메모리를 돌려준다. 다음 호출 때 Claude Code가 다시 켠다."""
    while True:
        time.sleep(15)
        limit = float(cfg.get("idle_exit_min", 10) or 0) * 60
        if limit <= 0 or guard.paused or guard.watching():
            continue
        if time.monotonic() - _last_used >= limit:
            _log(f"{limit / 60:g}분 동안 사용하지 않아 서버를 종료합니다(다음 호출 때 자동 재시작).")
            os._exit(0)


def _mtime(path: Path) -> float:
    try:
        return path.stat().st_mtime
    except OSError:
        return 0.0


_seen = {"actions": _mtime(ACTIONS_PATH), "config": (_mtime(CONFIG_PATH), _mtime(LOCAL_CONFIG_PATH))}


def _refresh() -> None:
    """actions.py / config.json / config.local.json이 바뀌었으면 다시 불러온다."""
    m = (_mtime(CONFIG_PATH), _mtime(LOCAL_CONFIG_PATH))
    if m != _seen["config"]:
        _seen["config"] = m
        new = load_config()
        cfg.clear()
        cfg.update(new)  # guard와 ctx가 같은 dict를 보고 있으므로 제자리에서 바꾼다
        _log("설정 다시 읽음 (config.json / config.local.json)")
    m = _mtime(ACTIONS_PATH)
    if actions is not None and m != _seen["actions"]:
        try:
            importlib.reload(actions)
        except Exception as e:
            # _seen을 갱신하지 않으므로 고친 뒤 다음 호출에서 다시 시도한다
            _log(f"actions.py 다시 불러오기 실패: {e!r}", "error", trace=traceback.format_exc(limit=5))
            raise ToolError(f"actions.py를 다시 불러오지 못했습니다(코드 오류): {e!r}") from None
        _seen["actions"] = m
        _log("actions.py 다시 불러옴")


PAUSED_MSG = (
    "사용자가 핸드파일럿을 일시정지했습니다({reason}). 지금 하던 작업을 멈추고 다시 시도하지 마세요. "
    "사용자에게 정지됐다고 알리면서, 화면 구석 표시창에서 [재개](이어서 하기) 또는 [종료](이 작업 끝내기) 중 "
    "하나를 고르면 된다고 안내하세요. 이어서 하려면 [재개]를 먼저 누른 다음 채팅으로 '계속'이라고 보내고, "
    "보낸 뒤에는 마우스·키보드에서 손을 떼 달라고 함께 알리세요(순서가 바뀌거나 보낸 직후 마우스를 움직이면 다시 멈출 수 있음). "
    "그리고 사용자가 다시 지시할 때까지 기다리세요."
)
# 같은 정지·같은 '사용 중' 상태가 이어지는 동안 두 번째 거부부터는 짧게 (Claude가 도구를 한꺼번에 보낼 때 같은 긴 안내가 반복되지 않게)
PAUSED_SHORT = ("(일시정지 중 — 바로 앞의 안내와 같은 상태입니다. 재시도하지 말고 사용자가 [재개] 또는 [종료]를 고를 때까지 기다리세요.)")
BUSY_SHORT = ("(다른 채팅창이 사용 중 — 바로 앞의 안내와 같은 상태입니다. 재시도하지 말고 사용자에게 알린 뒤 기다리세요.)")
_last_notice = {"key": None}


def _notice(kind: str, key, full: str, short: str) -> str:
    """같은 상황을 연달아 알릴 때는 처음 한 번만 전체 안내."""
    if _last_notice["key"] == (kind, key):
        return short
    _last_notice["key"] = (kind, key)
    return full


ENDED_MSG = (
    "사용자가 화면 구석 표시창의 [종료]를 눌러 핸드파일럿 작업을 끝냈습니다(조작권도 반납됨). 그래서 이 호출은 실행하지 않았습니다. "
    "[종료] 전에 하던 작업을 이어서 하던 중이라면 여기서 중단하고, 지금까지 한 일과 하지 못한 일을 사용자에게 알린 뒤 기다리세요. "
    "사용자가 [종료] 뒤에 새로 지시한 작업이라면 이 호출을 한 번 다시 하면 됩니다(이 안내는 한 번만 나옵니다)."
)


UPDATE_MARKER = Path(os.environ.get("LOCALAPPDATA", str(Path.home()))) / "handpilot" / "update-available.json"
_update_told = {"done": False}


def _with_update_notice(result):
    """새 버전이 있으면(update.ps1 -Check가 남긴 표시) 이 서버의 첫 정상 결과에 한 줄 덧붙인다(서버당 한 번)."""
    if _update_told["done"]:
        return result
    _update_told["done"] = True
    try:
        import json
        m = json.loads(UPDATE_MARKER.read_text(encoding="utf-8"))
        if time.time() - float(m.get("checked", 0)) > 14 * 86400:
            return result
    except Exception:
        return result
    if m.get("auto"):  # 0.3.3~ 자동 설치: 이 PC의 핸드파일럿 서버가 모두 꺼지면(약 10분 미사용) 정기 확인이 띄운 설치가 진행됨
        note = (f"\n(참고: 핸드파일럿 새 버전({str(m.get('version') or m.get('latest', ''))[:60]})이 자동 설치를 기다리는 중입니다 — "
                "핸드파일럿을 약 10분 쓰지 않으면 저절로 설치되고 새 채팅창부터 적용됩니다. 작업을 마친 뒤 사용자에게 한 줄로 알려 주세요.)")
    else:
        note = (f"\n(참고: 핸드파일럿 새 버전이 있습니다 — 변경 {m.get('behind')}개, 최신: {str(m.get('latest', ''))[:60]}. "
                "작업을 마친 뒤 사용자에게 알려 주세요: 시작 메뉴 '핸드파일럿 관리' → 상태 탭 [지금 설치…])")
    _log("새 버전 알림 전달", behind=m.get("behind"))
    if isinstance(result, list):
        for i, r in enumerate(result):
            if isinstance(r, str):
                return result[:i] + [r + note] + result[i + 1:]
        return [note.strip()] + result
    return str(result) + note


def _brief_args(kwargs: dict) -> dict:
    """로그용 입력 요약. 입력한 글자 내용은 남기지 않는다(글자 수만)."""
    # focus(창 찾기)도 창 제목 일부일 수 있어 글자 수만 — 문서 이름 같은 업무 정보가 로그에 남지 않게
    return {k: (f"<{len(v)}자>" if k in ("text", "focus") and isinstance(v, str) else v) for k, v in kwargs.items()}


def _brief_result(result, name: str = "") -> tuple[str, int]:
    items = result if isinstance(result, list) else [result]
    text = next((r for r in items if isinstance(r, str)), "")
    if name == "windows":  # 결과에 창 제목(문서 이름 등)이 들어가므로 종류만 남긴다
        text = ("찾지 못함" if text.startswith("⚠") and "찾지 못" in text else "앞으로 못 가져옴" if text.startswith("⚠")
                else "앞으로 가져옴" if "맨 앞으로" in text else "목록")
    return text[:100], sum(1 for r in items if not isinstance(r, str))


def guarded(func):
    """모든 도구를 정지 장치 안에서 실행한다. 일시정지 상태면 실행하지 않는다. 호출마다 로그를 남긴다."""
    name = func.__name__

    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        global _last_used
        t0 = _last_used = time.monotonic()
        outcome, note, images = "ok", "", 0
        try:
            _refresh()
            _ensure_runtime()
            with _op_lock:
                if guard.take_ended():  # 사용자가 [종료]를 눌렀으면 이어서 하지 않도록 한 번 알린다
                    outcome = "ended"
                    raise ToolError(ENDED_MSG)
                try:
                    control.acquire()  # 다른 채팅창이 쥐고 있으면 Busy → 바로 거부
                    with guard.action():
                        result = func(*args, **kwargs)
                    _last_notice["key"] = None  # 정상 실행되면 다음 거부는 다시 전체 안내
                    result = _with_update_notice(result)
                    note, images = _brief_result(result, name)
                    return result
                except Busy as e:
                    outcome, note = "busy", str(e)[:100]
                    raise ToolError(_notice("busy", e.key, str(e), BUSY_SHORT)) from None
                except Paused as e:
                    outcome, note = "paused", str(e)
                    raise ToolError(_notice("paused", guard.paused_at, PAUSED_MSG.format(reason=e), PAUSED_SHORT)) from None
                except pyautogui.FailSafeException:
                    guard.pause("마우스를 화면 모서리로 밀어 FailSafe 작동")
                    outcome, note = "paused", guard.reason
                    raise ToolError(_notice("paused", guard.paused_at, PAUSED_MSG.format(reason=guard.reason), PAUSED_SHORT)) from None
                finally:
                    control.touch()  # 쥐고 있을 때만: 보유 시간을 다시 센다
                    _last_used = time.monotonic()
        except ToolError as e:
            if outcome == "ok":  # 동작 쪽에서 거부(알 수 없는 키, Claude 창 보호 등)
                outcome, note = "rejected", str(e)[:150]
            raise
        except Exception as e:
            outcome, note = "error", repr(e)[:200]
            _log(f"{name} 실행 중 오류: {e!r}", "error", trace=traceback.format_exc(limit=8))
            raise
        finally:
            hplog.log("error" if outcome == "error" else "info", "tool", name, args=_brief_args(kwargs),
                      ms=round((time.monotonic() - t0) * 1000), outcome=outcome, note=note, images=images)

    return wrapper


OBSERVE_DOC = " observe=True(기본)이면 동작 후 화면이 안정될 때까지 기다렸다가 바뀐 부분을 함께 돌려줍니다."


@mcp.tool(structured_output=False)
@guarded
def screenshot(mode: str = "auto"):
    """화면을 봅니다. mode='auto'(기본): 마지막으로 본 화면과 비교해 변화 없음이면 글자만, 일부만 바뀌었으면
    그 부분만, 많이 바뀌었으면 전체 화면을 줍니다. mode='full': 항상 전체 화면. 좌표는 전체 스크린샷 기준입니다."""
    return actions.screenshot(ctx, mode)


@mcp.tool(structured_output=False, description="(x, y)를 클릭합니다. button: left/right/middle, clicks: 2면 더블클릭." + OBSERVE_DOC)
@guarded
def click(x: int, y: int, button: str = "left", clicks: int = 1, observe: bool = True):
    return actions.click(ctx, x, y, button, clicks, observe)


@mcp.tool(structured_output=False, description="마우스를 (x, y)로 옮깁니다. 툴팁이나 hover 메뉴를 띄울 때 사용합니다." + OBSERVE_DOC)
@guarded
def move(x: int, y: int, observe: bool = True):
    return actions.move(ctx, x, y, observe)


@mcp.tool(structured_output=False, description="왼쪽 버튼을 누른 채 (from_x, from_y)에서 (to_x, to_y)로 끌어다 놓습니다." + OBSERVE_DOC)
@guarded
def drag(from_x: int, from_y: int, to_x: int, to_y: int, observe: bool = True):
    return actions.drag(ctx, from_x, from_y, to_x, to_y, observe)


@mcp.tool(structured_output=False, description=(
    "현재 포커스된 곳에 텍스트를 입력합니다(한글 포함). 클립보드 붙여넣기 방식이며 기존 클립보드는 복원합니다. "
    "여러 번 나눠 입력할 땐 마지막만 observe=True로 하면 빠릅니다." + OBSERVE_DOC))
@guarded
def type_text(text: str, observe: bool = True):
    return actions.type_text(ctx, text, observe)


@mcp.tool(structured_output=False, description="키 또는 단축키를 누릅니다. 예: 'enter', 'esc', 'tab', 'ctrl+s', 'alt+tab', 'win+r'." + OBSERVE_DOC)
@guarded
def key(combo: str, observe: bool = True):
    return actions.key(ctx, combo, observe)


@mcp.tool(structured_output=False, description="스크롤합니다. amount 양수=위, 음수=아래(1 = 휠 한 칸). x, y를 주면 그 위치에서 스크롤합니다." + OBSERVE_DOC)
@guarded
def scroll(amount: int, x: int | None = None, y: int | None = None, observe: bool = True):
    return actions.scroll(ctx, amount, x, y, observe)


@mcp.tool(structured_output=False)
@guarded
def wait(seconds: float = 1.0, until_stable: bool = False):
    """기다립니다(최대 10초). until_stable=True면 화면이 안정되는 즉시(최대 seconds초) 끝내고 바뀐 부분을 돌려줍니다."""
    return actions.wait(ctx, seconds, until_stable)


@mcp.tool(structured_output=False)
@guarded
def windows(focus: str = "", maximize: bool = False):
    """작업할 창을 찾아 맨 앞으로 가져옵니다. focus: 프로그램 이름('크롬', '엑셀', '메모장' 또는 chrome·excel 같은 실행 파일 이름),
    창 제목 일부, 또는 목록 번호. 최소화돼 있으면 복원하고, 다른 모니터에 있으면 작업 모니터로 옮겨 온 뒤, 앞으로 온 화면을 전체 스크린샷으로 돌려줍니다(따로 screenshot 불필요).
    maximize=True면 최대화. focus를 비우면 열린 창 목록만 돌려줍니다.
    맞는 창이 없으면 오류 대신 열린 창 목록과 함께 알려 줍니다 — 비슷한 창을 번호로 고르거나, 없으면 사용자에게 열어 달라고 하세요."""
    return actions.windows(ctx, focus, maximize)


@mcp.tool(structured_output=False)
@guarded
def zoom(x: int, y: int, width: int, height: int):
    """화면 일부를 원본 해상도로 확대해 봅니다(작은 글씨·숫자 읽기용). x, y, width, height는 스크린샷 좌표.
    결과 안내의 공식으로 확대 이미지의 위치를 스크린샷 좌표로 바꿔 클릭하세요. 읽기 전용(변화 감지 기준은 그대로)."""
    return actions.zoom(ctx, x, y, width, height)


if __name__ == "__main__":
    threading.Thread(target=_idle_watchdog, name="handpilot-idle", daemon=True).start()
    mcp.run()
