﻿# 핸드파일럿 설치 (처음 설치 / 다른 PC / 재설치 — 여러 번 실행해도 안전)
#
#   powershell -ExecutionPolicy Bypass -File install.ps1          # 필요하면 물어보면서 설치
#   powershell -ExecutionPolicy Bypass -File install.ps1 -Yes     # 묻지 않고 진행 (Python 자동 설치 포함)
#   powershell -ExecutionPolicy Bypass -File install.ps1 -SkipPlugin  # 플러그인 등록은 건너뜀(테스트용)
#   powershell -ExecutionPolicy Bypass -File install.ps1 -NoShortcut  # 시작 메뉴 바로가기를 만들지 않음
#
# 하는 일: Python 확인(없으면 winget 설치) → .venv 생성 → 라이브러리 설치(requirements.lock)
#          → .mcp.json을 이 폴더 경로로 생성 → Claude Code에 플러그인 등록 → 확인
# 폴더는 어디에 두어도 됩니다(경로는 자동 설정). 다른 위치로 옮겼다면 이 스크립트를 다시 실행하세요.

param([switch]$Yes, [switch]$SkipPlugin, [switch]$NoShortcut)

. (Join-Path $PSScriptRoot "scripts\common.ps1")
$root = Get-HandpilotRoot
Write-Host "핸드파일럿 설치 — $root" -ForegroundColor White

# 1) Python 3.10 이상
Write-Step "1/5 Python 확인"
function Find-Python {
    $cands = @()
    $cands += Get-ChildItem "$env:LOCALAPPDATA\Programs\Python\Python3*\python.exe" -ErrorAction SilentlyContinue
    $cands += Get-ChildItem "$env:ProgramFiles\Python3*\python.exe" -ErrorAction SilentlyContinue
    $best = $null; $bestVer = [version]"0.0"
    foreach ($c in $cands) {
        $v = & $c.FullName -c "import sys; print('%d.%d' % sys.version_info[:2])" 2>$null
        if ($v -and [version]$v -ge [version]"3.10" -and [version]$v -gt $bestVer) { $best = $c.FullName; $bestVer = [version]$v }
    }
    $best
}
$py = Find-Python
if (-not $py) {
    Write-Warn2 "Python 3.10 이상이 없습니다. 무료 공식 배포판 Python 3.12를 이 사용자 계정에 설치합니다(관리자 권한 불필요)."
    $ok = $Yes -or ((Read-Host "   설치할까요? (y/n)") -match '^[yY]')
    if (-not $ok) { throw "Python이 필요합니다. 설치 후 다시 실행해 주세요." }
    winget install --id Python.Python.3.12 -e --scope user --accept-source-agreements --accept-package-agreements --silent
    $py = Find-Python
    if (-not $py) { throw "Python 설치를 확인하지 못했습니다." }
}
Write-Ok "Python: $py"

# 2) 가상환경
Write-Step "2/5 가상환경(.venv)"
$venvPy = Join-Path $root ".venv\Scripts\python.exe"
if (-not (Test-Path $venvPy)) {
    & $py -m venv (Join-Path $root ".venv")
    & $venvPy -m pip install -q --disable-pip-version-check --upgrade pip
    Write-Ok "가상환경 생성"
} else {
    Write-Ok "가상환경 있음"
}

# 3) 라이브러리
Write-Step "3/5 라이브러리"
Sync-Requirements $root

# 4) 경로 설정 + 플러그인 등록
Write-Step "4/5 경로 설정 · 플러그인 등록"
Write-McpJson $root | Out-Null
if ($SkipPlugin) { Write-Note "플러그인 등록 건너뜀(-SkipPlugin)" } else { Sync-Plugin $root }
if (-not $NoShortcut) { New-SettingsShortcut $root }

# 5) 확인
Write-Step "5/5 확인"
$chk = & $venvPy -c "import mcp, mss, pyautogui, pyperclip, PIL, pynput, numpy; print('ok')" 2>&1
if ("$chk" -notmatch "ok") { throw "라이브러리 확인 실패: $chk" }
Write-Ok "라이브러리 불러오기"
Write-Ok "버전 $(Get-PluginVersion $root)"

Write-Step "점검 (doctor)"
& (Join-Path $root "doctor.ps1")

Write-Host "`n설치 완료. 새 채팅창에서 '/handpilot:handpilot 지금 화면 봐줘'로 확인하세요." -ForegroundColor Green
Write-Host "PC마다 다른 설정은 handpilot\config.local.json에 적으세요(업데이트 때 덮어쓰지 않음)."
