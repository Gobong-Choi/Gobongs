﻿# 핸드파일럿 설치·업데이트·릴리스 스크립트가 같이 쓰는 기능 (직접 실행하지 않음, dot-source용)

$ErrorActionPreference = "Stop"
$Utf8NoBom = New-Object Text.UTF8Encoding $false

function Write-Step([string]$msg) { Write-Host "`n== $msg" -ForegroundColor Cyan }
function Write-Ok([string]$msg) { Write-Host "   OK  $msg" -ForegroundColor Green }
function Write-Note([string]$msg) { Write-Host "   ..  $msg" }
function Write-Warn2([string]$msg) { Write-Host "   !!  $msg" -ForegroundColor Yellow }

function Get-HandpilotRoot { (Resolve-Path (Join-Path $PSScriptRoot "..")).Path }

function Find-ClaudeExe {
    # Claude 데스크톱 앱에 들어 있는 Claude Code CLI(PATH에 없음). 앱 업데이트로 자리가 바뀌어 와서 여러 곳을 보고 가장 높은 버전을 쓴다.
    #  ① 환경 변수 HANDPILOT_CLAUDE(직접 지정) ② 실행 중인 claude.exe 중 claude-code 경로(프로세스 목록 — 앱 폴더 전환과 상관없음)
    #  ③ %LOCALAPPDATA%\Claude-Data\claude_*\claude-code (2026-11 앱 4.23118에서 확인) ④ %APPDATA%\Claude\claude-code (예전)
    #  ⑤ %LOCALAPPDATA%\Packages\Claude_*\LocalCache\Roaming\Claude\claude-code (예전 스토어판을 앱 밖에서 볼 때)
    # web/setup.ps1 Find-Claude, tools/doctor.py find_claude도 같은 순서 — 고치면 같이 고칠 것
    if ($env:HANDPILOT_CLAUDE -and (Test-Path $env:HANDPILOT_CLAUDE)) { return $env:HANDPILOT_CLAUDE }
    $paths = @()
    try {
        $paths += Get-CimInstance Win32_Process -Filter "Name='claude.exe'" -ErrorAction Stop |
            Where-Object { $_.ExecutablePath -like '*\claude-code\*' } | ForEach-Object { $_.ExecutablePath }
    } catch {}
    foreach ($pat in @("$env:LOCALAPPDATA\Claude-Data\claude_*\claude-code\*\*\claude.exe",
                       "$env:APPDATA\Claude\claude-code\*\*\claude.exe",
                       "$env:LOCALAPPDATA\Packages\Claude_*\LocalCache\Roaming\Claude\claude-code\*\*\claude.exe")) {
        $paths += Get-ChildItem $pat -ErrorAction SilentlyContinue | ForEach-Object { $_.FullName }
    }
    $paths | Where-Object { $_ -and (Test-Path $_) } | Sort-Object -Unique |
        Sort-Object { if ($_ -match '\\claude-code\\([\d.]+)\\') { try { [version]$Matches[1] } catch { [version]"0.0" } } else { [version]"0.0" } } |
        Select-Object -Last 1
}

function Get-ClaudeExe {
    $c = Find-ClaudeExe
    if (-not $c) {
        throw ("Claude Code 실행 파일을 찾지 못했습니다. Claude 데스크톱 앱에서 Code 탭 채팅을 하나 연 채로 다시 하거나, " +
               "환경 변수 HANDPILOT_CLAUDE에 claude.exe 경로를 넣어 주세요.")
    }
    $c
}

function Get-InstalledPluginVersion {
    # Claude Code에 설치된 핸드파일럿 플러그인 버전(설치 기록). 없으면 $null
    $p = Join-Path $env:USERPROFILE ".claude\plugins\installed_plugins.json"
    if (-not (Test-Path $p)) { return $null }
    try {
        $j = [IO.File]::ReadAllText($p, [Text.Encoding]::UTF8) | ConvertFrom-Json
        return @($j.plugins.'handpilot@handpilot-local')[0].version
    } catch { return $null }
}

function Get-PluginVersion([string]$root) {
    $m = [regex]::Match([IO.File]::ReadAllText((Join-Path $root "handpilot\.claude-plugin\plugin.json")), '"version":\s*"([^"]+)"')
    $m.Groups[1].Value
}

function Write-FromTemplate([string]$root, [string]$rel) {
    # PC마다 경로가 다른 파일은 템플릿({{ROOT}})에서 만들어 쓴다(git에는 템플릿만 있음).
    $tpl = [IO.File]::ReadAllText((Join-Path $root "$rel.template"), [Text.Encoding]::UTF8)
    $out = $tpl.Replace("{{ROOT}}", ($root -replace '\\', '/'))
    $path = Join-Path $root $rel
    $old = if (Test-Path $path) { [IO.File]::ReadAllText($path, [Text.Encoding]::UTF8) } else { "" }
    if ($old -ne $out) {
        New-Item -ItemType Directory -Force (Split-Path $path) | Out-Null
        [IO.File]::WriteAllText($path, $out, $Utf8NoBom)
        Write-Ok "$(Split-Path $rel -Leaf) 경로 설정: $root"
        return $true
    }
    Write-Ok "$(Split-Path $rel -Leaf) 경로 이미 맞음"
    return $false
}

function Write-McpJson([string]$root) {
    # 실행 설정(.mcp.json) + 훅 설정(hooks/hooks.json)
    $a = Write-FromTemplate $root "handpilot\.mcp.json"
    $b = Write-FromTemplate $root "handpilot\hooks\hooks.json"
    return ($a -or $b)
}

function Get-ReqFile([string]$root) {
    $lock = Join-Path $root "requirements.lock"
    if (Test-Path $lock) { $lock } else { Join-Path $root "requirements.txt" }
}

function Sync-Requirements([string]$root, [switch]$Force) {
    # 라이브러리 목록이 바뀌었을 때만 설치한다(해시 비교).
    $py = Join-Path $root ".venv\Scripts\python.exe"
    $req = Get-ReqFile $root
    # 줄바꿈(CRLF/LF)과 무관한 해시 — git 설정·복사 방식에 따라 줄바꿈만 달라도 '바뀜'으로 보지 않게
    $bytes = [Text.Encoding]::UTF8.GetBytes(([IO.File]::ReadAllText($req) -replace "`r`n", "`n"))
    $hash = -join ([Security.Cryptography.SHA256]::Create().ComputeHash($bytes) | ForEach-Object { $_.ToString("X2") })
    $stamp = Join-Path $root ".venv\handpilot-req.sha256"
    if (-not $Force -and (Test-Path $stamp) -and ((Get-Content $stamp -Raw).Trim() -eq $hash)) {
        Write-Ok "라이브러리 변경 없음 ($(Split-Path $req -Leaf))"
        return
    }
    Write-Note "라이브러리 설치 중 ($(Split-Path $req -Leaf)) …"
    & $py -m pip install -q --disable-pip-version-check -r $req
    if ($LASTEXITCODE -ne 0) { throw "라이브러리 설치 실패" }
    Set-Content $stamp $hash -Encoding ascii
    Write-Ok "라이브러리 설치 완료"
}

function Get-MarketplacePath {
    $settings = Join-Path $env:USERPROFILE ".claude\settings.json"
    if (-not (Test-Path $settings)) { return $null }
    try {
        $s = [IO.File]::ReadAllText($settings, [Text.Encoding]::UTF8) | ConvertFrom-Json
        return $s.extraKnownMarketplaces.'handpilot-local'.source.path
    } catch { return $null }
}

function Sync-Plugin([string]$root) {
    $claude = Get-ClaudeExe
    $registered = Get-MarketplacePath
    if ($registered -and ((Resolve-Path $registered -ErrorAction SilentlyContinue).Path -ne $root)) {
        Write-Note "로컬 마켓플레이스가 다른 위치($registered)에 등록돼 있어 새 위치로 바꿉니다"
        & $claude plugin marketplace remove handpilot-local | Out-Null
        $registered = $null
    }
    if (-not $registered) {
        & $claude plugin marketplace add $root | Out-Null
        Write-Ok "로컬 마켓플레이스 등록: $root"
    } else {
        & $claude plugin marketplace update handpilot-local | Out-Null
        Write-Ok "로컬 마켓플레이스 갱신"
    }
    $list = (& $claude plugin list) -join "`n"
    if ($list -match "handpilot@handpilot-local") {
        $r = (& $claude plugin update handpilot@handpilot-local) -join " "
        Write-Ok ("플러그인 갱신: " + ($r -replace '\s+', ' ').Trim())
    } else {
        & $claude plugin install handpilot@handpilot-local --scope user | Out-Null
        Write-Ok "플러그인 설치 (사용자 전체)"
    }
}

function New-SettingsShortcut([string]$root) {
    # 시작 메뉴 "핸드파일럿 관리" (설정창 tools/settings.pyw). 폴더를 옮기면 install/update가 다시 만든다.
    $lnk = Join-Path ([Environment]::GetFolderPath("Programs")) "핸드파일럿 관리.lnk"
    $pyw = Join-Path $root ".venv\Scripts\pythonw.exe"
    if (-not (Test-Path $pyw)) { Write-Warn2 "pythonw.exe가 없어 바로가기를 만들지 않음"; return }
    $s = (New-Object -ComObject WScript.Shell).CreateShortcut($lnk)
    $s.TargetPath = $pyw
    $s.Arguments = '"' + (Join-Path $root "tools\settings.pyw") + '"'
    $s.WorkingDirectory = $root
    $s.Description = "핸드파일럿 상태 · 설정 · 로그"
    $s.Save()
    Write-Ok "시작 메뉴 바로가기: 핸드파일럿 관리"
}

$UpdateMarker = Join-Path $env:LOCALAPPDATA "handpilot\update-available.json"
$LastCheckFile = Join-Path $env:LOCALAPPDATA "handpilot\last-check.json"   # 사이트 배포판의 마지막 확인(관리 창 업데이트 카드용)
# 설치 안내 사이트(공개 묶음 zip + version.json). 시험할 때는 HANDPILOT_SITE_URL로 바꿈
$SiteUrl = if ($env:HANDPILOT_SITE_URL) { $env:HANDPILOT_SITE_URL.TrimEnd("/") } else { "https://gobong-choi.github.io/Gobongs/handpilot" }
$UpdateTaskName = "핸드파일럿 업데이트 확인"

function Set-UpdateMarker([int]$behind, [string]$latest, [string]$version = "", [switch]$Auto) {
    # 새 버전이 있다는 표시. 핸드파일럿 서버가 읽고 채팅창 결과에 한 번 알려준다(auto면 '자동 설치 대기' 안내).
    New-Item -ItemType Directory -Force (Split-Path $UpdateMarker) | Out-Null
    $json = @{ behind = $behind; latest = $latest; version = $version; auto = [bool]$Auto
               checked = [DateTimeOffset]::Now.ToUnixTimeSeconds() } | ConvertTo-Json -Compress
    [IO.File]::WriteAllText($UpdateMarker, $json, $Utf8NoBom)
}

function Clear-UpdateMarker { if (Test-Path $UpdateMarker) { Remove-Item $UpdateMarker -Force } }

# ---------------------------------------------------------------- 사이트 배포판 (0.4.0~)
# 설치 파일로 설치한 PC는 .git 없이 설치 안내 사이트의 공개 묶음(zip)을 받는다 — GitHub 로그인·Git 필요 없음.
# 예전 방식(GitHub clone)으로 설치한 PC는 .git이 있어 지금처럼 git으로 받는다.
function Test-SiteInstall([string]$root) { -not (Test-Path (Join-Path $root ".git")) }

function Invoke-SiteGet([string]$url, [string]$outFile = "") {
    # 사이트에서 받기(캐시 피하려고 주소 끝에 매번 다른 값). outFile이 있으면 파일로, 없으면 UTF-8 글자로
    [Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12
    $ProgressPreference = "SilentlyContinue"   # PowerShell 5.1 진행 막대는 받기를 크게 느리게 함
    $u = $url + $(if ($url.Contains("?")) { "&" } else { "?" }) + "nc=" + [DateTime]::UtcNow.Ticks
    if ($outFile) { Invoke-WebRequest $u -UseBasicParsing -TimeoutSec 300 -OutFile $outFile; return }
    $r = Invoke-WebRequest $u -UseBasicParsing -TimeoutSec 30
    [Text.Encoding]::UTF8.GetString($r.RawContentStream.ToArray())
}

function Get-SiteVersion {
    # 사이트의 최신 공개 묶음 정보(version.json): version, file, sha256, notes
    $j = Invoke-SiteGet "$SiteUrl/version.json" | ConvertFrom-Json
    if (-not $j.version -or -not $j.file -or -not $j.sha256) { throw "설치 안내 사이트의 버전 정보(version.json)가 올바르지 않습니다" }
    $j
}

function Test-NewerVersion([string]$a, [string]$b) {
    # a가 b보다 새 버전인가(사이트 버전이 이 PC보다 높을 때만 받음)
    try { return [version]$a -gt [version]$b } catch { return $a -ne $b }
}

function Install-Bundle([string]$root, $site) {
    # 사이트 묶음(zip)을 받아 확인값(sha256)을 맞춰 보고 이 폴더에 덮어쓴다.
    # 이 PC 전용 설정(config.local.json)·가상환경(.venv)·생성 파일은 묶음에 없어서 그대로 남는다. web/setup.ps1도 같은 방식.
    $tmp = Join-Path ([IO.Path]::GetTempPath()) ("handpilot-bundle-" + [guid]::NewGuid().ToString("N"))
    New-Item -ItemType Directory -Force $tmp | Out-Null
    try {
        $zip = Join-Path $tmp $site.file
        Invoke-SiteGet "$SiteUrl/$($site.file)" $zip
        $sha = (Get-FileHash $zip -Algorithm SHA256).Hash.ToLower()
        if ($sha -ne ([string]$site.sha256).ToLower()) {
            throw "내려받은 묶음의 확인값이 사이트 정보와 다릅니다(받는 중 손상 또는 위조 의심) — 설치하지 않았습니다"
        }
        Add-Type -AssemblyName System.IO.Compression.FileSystem
        $x = Join-Path $tmp "x"
        [IO.Compression.ZipFile]::ExtractToDirectory($zip, $x)
        $n = 0
        Get-ChildItem $x -Recurse -File | ForEach-Object {
            $dst = Join-Path $root $_.FullName.Substring($x.Length + 1)
            New-Item -ItemType Directory -Force (Split-Path $dst) | Out-Null
            Copy-Item $_.FullName $dst -Force
            $n++
        }
        Write-Ok "설치 안내 사이트의 묶음 $($site.version) 받아 덮어씀 ($n 개 파일, 확인값 일치)"
    } finally { Remove-Item $tmp -Recurse -Force -ErrorAction SilentlyContinue }
}

function Get-UpdateScriptHash([string]$root) {
    # 업데이트 스크립트(자기 자신·공통 기능)가 바뀌었는지 보는 값
    -join (@("update.ps1", "scripts\common.ps1") | ForEach-Object { (Get-FileHash (Join-Path $root $_) -Algorithm SHA256).Hash })
}

function Set-LastCheck([string]$latest) {
    New-Item -ItemType Directory -Force (Split-Path $LastCheckFile) | Out-Null
    $json = @{ latest = $latest; checked = [DateTimeOffset]::Now.ToUnixTimeSeconds() } | ConvertTo-Json -Compress
    [IO.File]::WriteAllText($LastCheckFile, $json, $Utf8NoBom)
}

function Show-Toast([string]$title, [string]$text) {
    # Windows 알림 (PowerShell 5.1 WinRT). 실패해도 업데이트 확인은 계속.
    if ($env:HANDPILOT_NO_TOAST) { Write-Note "알림(시험 — 표시 안 함): $title — $text"; return }
    try {
        [Windows.UI.Notifications.ToastNotificationManager, Windows.UI.Notifications, ContentType = WindowsRuntime] | Out-Null
        [Windows.Data.Xml.Dom.XmlDocument, Windows.Data.Xml.Dom.XmlDocument, ContentType = WindowsRuntime] | Out-Null
        $t = [Security.SecurityElement]::Escape($title); $b = [Security.SecurityElement]::Escape($text)
        $xml = New-Object Windows.Data.Xml.Dom.XmlDocument
        $xml.LoadXml("<toast><visual><binding template='ToastGeneric'><text>$t</text><text>$b</text></binding></visual></toast>")
        $appId = '{1AC14E77-02E7-4E5D-B744-2EB1AE5198B7}\WindowsPowerShell\v1.0\powershell.exe'
        [Windows.UI.Notifications.ToastNotificationManager]::CreateToastNotifier($appId).Show([Windows.UI.Notifications.ToastNotification]::new($xml))
        Write-Ok "알림 표시: $title"
    } catch { Write-Warn2 "알림 표시 실패: $_" }
}

function Get-HandpilotServers([string]$root) {
    # 지금 돌고 있는 이 폴더의 핸드파일럿 서버(채팅창마다 하나 — 마지막 사용 후 idle_exit_min(기본 10분) 뒤 저절로 꺼짐).
    # 프로세스 목록이라 Claude 앱(스토어 앱)의 폴더 전환과 상관없이 앱 밖(작업 스케줄러)에서도 보인다.
    # 다른 폴더의 복사본과 섞이지 않게 실행 경로로 거르고, 가상환경 python이 띄운 같은 명령줄의 자식은 빼고 하나로 센다.
    $mine = (($root -replace '\\', '/') + '/handpilot/server.py').ToLower()
    $all = Get-CimInstance Win32_Process -Filter "Name='python.exe'"
    $ids = @{}; $all | ForEach-Object { $ids[[int]$_.ProcessId] = $_ }
    $all | Where-Object {
        $_.CommandLine -and ($_.CommandLine -replace '\\', '/').ToLower().Contains($mine) -and $_.CommandLine -notlike '*--locktest*' -and
        $ids[[int]$_.ParentProcessId].Name -ne 'python.exe'
    }
}

function Get-StaleServers([string]$root) {
    # 이 폴더의 서버 코드(server.py·guard.py·lease.py)보다 먼저 켜진 핸드파일럿 서버 = 예전 코드
    $newest = (Get-ChildItem (Join-Path $root "handpilot") -Include server.py, guard.py, lease.py -Recurse |
        Sort-Object LastWriteTime | Select-Object -Last 1).LastWriteTime
    Get-HandpilotServers $root | Where-Object { $_.CreationDate -lt $newest }
}

function Get-HandpilotSetting([string]$root, [string]$key, $default) {
    # 공용 config.json → 이 PC 전용 config.local.json 순서로 덮어쓴 값(관리 창 설정 탭과 같은 규칙)
    $v = $default
    foreach ($name in @("config.json", "config.local.json")) {
        $p = Join-Path $root "handpilot\$name"
        if (-not (Test-Path $p)) { continue }
        try {
            $o = [IO.File]::ReadAllText($p, [Text.Encoding]::UTF8) | ConvertFrom-Json
            if ($o.PSObject.Properties.Name -contains $key) { $v = $o.$key }
        } catch { Write-Warn2 "$name 읽기 실패: $_" }
    }
    $v
}

function Get-UpstreamVersion {
    # 원격(@{u})의 plugin.json 버전 — 지금 폴더가 저장소 안이어야 함. 못 읽으면 $null
    try {
        $j = (git show "@{u}:handpilot/.claude-plugin/plugin.json" 2>$null) -join "`n"
        if ($j -match '"version"\s*:\s*"([^"]+)"') { return $Matches[1] }
    } catch {}
    $null
}

function Get-RootKey([string]$root) {
    # 폴더마다 다른 짧은 이름(자동 설치 중복 실행 막는 잠금 이름용)
    $b = [Text.Encoding]::UTF8.GetBytes($root.ToLower())
    -join ([Security.Cryptography.SHA1]::Create().ComputeHash($b)[0..5] | ForEach-Object { $_.ToString("x2") })
}
