﻿# 핸드파일럿 "정기 업데이트 확인" 작업 (Windows 작업 스케줄러) — 기본 매주 월요일 오전 10시
#
#   powershell -ExecutionPolicy Bypass -File scripts\update-check-task.ps1            # 상태 보기
#   powershell -ExecutionPolicy Bypass -File scripts\update-check-task.ps1 -Register  # 켜기 (매주 월요일 10:00)
#   powershell -ExecutionPolicy Bypass -File scripts\update-check-task.ps1 -Register -Day Thursday -Time 09:30
#   powershell -ExecutionPolicy Bypass -File scripts\update-check-task.ps1 -Remove    # 끄기
#
# 주 1회 update.ps1 -Check -Prompt 를 숨김 창으로 실행 → 새 버전(릴리스)이 있으면 자동 설치(0.3.3~, 설정 auto_update):
# 핸드파일럿 서버가 하나도 안 돌 때(마지막 사용 후 약 10분) 설치하고 Windows 알림. auto_update=false면 설치 창([지금 설치]/[나중에]).
# 작업 자체는 5분 안에 끝나고, 기다렸다 설치하는 일은 따로 띄운 update.ps1 -Auto가 한다. PC가 꺼져 있던 주는 켜진 뒤 실행(놓친 실행 보충).
# 관리자 권한 불필요(이 사용자 계정 작업). 매일은 너무 잦다는 의견으로 주 1회(0.2.1).

param([switch]$Register, [switch]$Remove, [string]$Time = "10:00",
      [ValidateSet("Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday")][string]$Day = "Monday")

. (Join-Path $PSScriptRoot "common.ps1")
$root = Get-HandpilotRoot
$DayKo = @{ Monday = "월요일"; Tuesday = "화요일"; Wednesday = "수요일"; Thursday = "목요일"; Friday = "금요일"; Saturday = "토요일"; Sunday = "일요일" }

if ($Register) {
    $arg = "-NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File `"$(Join-Path $root 'update.ps1')`" -Check -Prompt"
    $action = New-ScheduledTaskAction -Execute "powershell.exe" -Argument $arg -WorkingDirectory $root
    $trigger = New-ScheduledTaskTrigger -Weekly -DaysOfWeek $Day -At $Time
    $settings = New-ScheduledTaskSettingsSet -StartWhenAvailable -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries `
        -ExecutionTimeLimit (New-TimeSpan -Minutes 5)
    Register-ScheduledTask -TaskName $UpdateTaskName -Action $action -Trigger $trigger -Settings $settings `
        -Description "핸드파일럿 새 버전 확인 — 있으면 핸드파일럿을 안 쓸 때 자동 설치(관리 창 설정에서 끄면 설치 창). $root" -Force | Out-Null
    Write-Ok "매주 $($DayKo[$Day]) $Time 업데이트 확인 켜짐 (작업 이름: $UpdateTaskName)"
} elseif ($Remove) {
    if (Get-ScheduledTask -TaskName $UpdateTaskName -ErrorAction SilentlyContinue) {
        Unregister-ScheduledTask -TaskName $UpdateTaskName -Confirm:$false
        Write-Ok "정기 업데이트 확인 꺼짐"
    } else { Write-Ok "이미 꺼져 있음" }
} else {
    $t = Get-ScheduledTask -TaskName $UpdateTaskName -ErrorAction SilentlyContinue
    if ($t) {
        $i = $t | Get-ScheduledTaskInfo
        $when = if ($t.Triggers[0].CimClass.CimClassName -eq "MSFT_TaskWeeklyTrigger") { "매주" } else { "매일" }
        $next = if ($i.NextRunTime) { $i.NextRunTime.ToString("yyyy-MM-dd(ddd) HH:mm") } else { "없음" }
        $last = if ($i.LastRunTime -and $i.LastRunTime.Year -gt 2000) {
            $i.LastRunTime.ToString("yyyy-MM-dd HH:mm") + $(if ($i.LastTaskResult -eq 0) { " 정상" } else { " (결과 코드 $($i.LastTaskResult))" })
        } else { "아직 없음" }
        Write-Ok "켜짐($when) — 다음 확인 $next · 마지막 확인 $last"
    } else { Write-Note "꺼짐 — 켜려면 -Register" }
}
