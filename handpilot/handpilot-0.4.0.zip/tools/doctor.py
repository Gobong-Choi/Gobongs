"""핸드파일럿 상태 점검 (doctor).

실행: doctor.ps1  (또는 .venv/Scripts/python.exe tools/doctor.py [--json] [--fetch])
- 설치·라이브러리·경로·플러그인 등록·버전 일치·실행 중 서버·조작권 잠금·채팅창 이름 파일 형식·git·로그·화면을 점검하고
  문제가 있으면 해결 방법을 알려준다.
- 설정창(tools/settings.pyw)이 run_checks()를 그대로 불러 화면에 보여준다.
- 읽기만 한다(아무것도 고치지 않음). 조작권 잠금 확인만 아주 잠깐(1ms 미만) 잠갔다 푼다.
"""

import ctypes
import glob
import hashlib
import importlib.metadata as md
import json
import os
import re
import subprocess
import sys
import time
from dataclasses import asdict, dataclass, field
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
HP = ROOT / "handpilot"
sys.path.insert(0, str(HP))

OK, WARN, FAIL, INFO = "ok", "warn", "fail", "info"
ICON = {OK: "✅", WARN: "⚠️", FAIL: "❌", INFO: "ℹ️"}
NO_WINDOW = 0x08000000  # CREATE_NO_WINDOW — 관리 창(pythonw)에서 점검할 때 콘솔 창이 깜빡이지 않게(출력은 그대로 받음)


@dataclass
class Check:
    name: str
    status: str
    detail: str
    fix: str = ""
    data: dict = field(default_factory=dict)


def _ps(cmd: str) -> str:
    return subprocess.run(["powershell", "-NoProfile", "-Command", cmd], capture_output=True, text=True,
                          encoding="utf-8", errors="replace", creationflags=NO_WINDOW).stdout


def plugin_version() -> str:
    return json.loads((HP / ".claude-plugin" / "plugin.json").read_text(encoding="utf-8"))["version"]


# ---------------------------------------------------------------- 개별 점검

def check_python() -> Check:
    py = ROOT / ".venv" / "Scripts" / "python.exe"
    if not py.exists():
        return Check("Python 가상환경", FAIL, ".venv가 없습니다", "install.ps1 실행")
    return Check("Python 가상환경", OK, f"Python {sys.version.split()[0]} ({py})")


def check_libraries() -> Check:
    lock = ROOT / "requirements.lock"
    if not lock.exists():
        return Check("라이브러리", WARN, "requirements.lock 없음", "개발 PC에서 pip freeze로 생성")
    want = {}
    for line in lock.read_text(encoding="utf-8").splitlines():
        if "==" in line:
            n, v = line.strip().split("==", 1)
            want[n.lower().replace("_", "-")] = v
    bad = []
    for n, v in want.items():
        try:
            have = md.version(n)
        except md.PackageNotFoundError:
            bad.append(f"{n} 없음")
            continue
        if have != v:
            bad.append(f"{n} {have}≠{v}")
    stamp = ROOT / ".venv" / "handpilot-req.sha256"
    h = hashlib.sha256(lock.read_bytes().replace(b"\r\n", b"\n")).hexdigest().upper()  # 줄바꿈 무관(common.ps1과 같게)
    stamped = stamp.exists() and stamp.read_text().strip() == h
    if bad:
        return Check("라이브러리", FAIL, f"버전 불일치 {len(bad)}개: " + ", ".join(bad[:4]), "update.ps1 실행")
    core = ", ".join(f"{n} {md.version(n)}" for n in ("mcp", "mss", "pynput", "numpy"))
    if not stamped:
        return Check("라이브러리", WARN, f"버전은 맞지만 설치 표시가 오래됨 ({core})", "update.ps1 실행(표시만 갱신)")
    return Check("라이브러리", OK, f"{len(want)}개 고정 버전 일치 ({core})")


def check_mcp_json() -> Check:
    path = HP / ".mcp.json"
    tpl = HP / ".mcp.json.template"
    if not path.exists():
        return Check("실행 경로(.mcp.json)", FAIL, "handpilot/.mcp.json이 없습니다", "install.ps1 실행")
    want = tpl.read_text(encoding="utf-8").replace("{{ROOT}}", str(ROOT).replace("\\", "/"))
    have = path.read_text(encoding="utf-8")
    try:
        srv = json.loads(have)["mcpServers"]["handpilot"]
        missing = [p for p in [srv["command"], *srv["args"]] if not Path(p).exists()]
    except Exception as e:
        return Check("실행 경로(.mcp.json)", FAIL, f"읽기 실패: {e}", "install.ps1 실행")
    if missing:
        return Check("실행 경로(.mcp.json)", FAIL, "없는 경로: " + ", ".join(missing), "폴더를 옮겼다면 install.ps1 다시 실행")
    if have.strip() != want.strip():
        return Check("실행 경로(.mcp.json)", WARN, "템플릿과 다름(폴더 이동 또는 템플릿 변경)", "update.ps1 실행")
    return Check("실행 경로(.mcp.json)", OK, f"이 폴더 기준 ({ROOT})")


def check_hooks() -> Check:
    """조작권 2단계: 답변이 끝나면 반납(Stop 훅), 새 메시지 때 [종료] 알림 정리(UserPromptSubmit 훅)."""
    path = HP / "hooks" / "hooks.json"
    if not path.exists():
        return Check("훅(답변 단위 조작권)", WARN, "hooks/hooks.json 없음 → 시간 기반(15초)으로만 동작", "update.ps1 실행")
    want = (HP / "hooks" / "hooks.json.template").read_text(encoding="utf-8").replace("{{ROOT}}", str(ROOT).replace("\\", "/"))
    if path.read_text(encoding="utf-8").strip() != want.strip():
        return Check("훅(답변 단위 조작권)", WARN, "hooks.json이 템플릿과 다름", "update.ps1 실행")
    sig = Path(os.environ.get("LOCALAPPDATA", "")) / "handpilot" / "signals"
    recent = [f for f in sig.glob("*.*") if time.time() - f.stat().st_mtime < 86400] if sig.exists() else []
    if not recent:
        return Check("훅(답변 단위 조작권)", INFO, "설정 정상, 최근 24시간 훅 신호 없음(새 채팅창부터 동작)")
    last = max(f.stat().st_mtime for f in recent)
    return Check("훅(답변 단위 조작권)", OK, f"동작 중 — 최근 24시간 신호 {len(recent)}개, 마지막 {time.strftime('%H:%M:%S', time.localtime(last))}")


def known_config_keys() -> tuple[set, set]:
    from guard import DEFAULTS
    try:
        import actions
        observe = set(actions.OBSERVE_DEFAULTS)
    except Exception:
        observe = set()
    top = set(DEFAULTS) | {"observe", "protect_claude_window", "auto_update"}  # auto_update: update.ps1이 읽음(서버는 안 씀)
    return top, observe


def check_config() -> Check:
    top, observe = known_config_keys()
    notes, fails = [], []
    for name in ("config.json", "config.local.json"):
        p = HP / name
        if not p.exists():
            if name == "config.json":
                fails.append("config.json 없음")
            continue
        try:
            d = json.loads(p.read_text(encoding="utf-8"))
        except ValueError as e:
            fails.append(f"{name} 형식 오류({e})")
            continue
        unknown = [k for k in d if k not in top] + [f"observe.{k}" for k in d.get("observe", {}) if observe and k not in observe]
        if unknown:
            notes.append(f"{name}에 모르는 항목: {', '.join(unknown)}")
    if fails:
        return Check("설정 파일", FAIL, "; ".join(fails), "JSON 형식을 고치세요(쉼표·따옴표)")
    if notes:
        return Check("설정 파일", WARN, "; ".join(notes), "철자를 확인하세요(무시됨)")
    local = " + config.local.json" if (HP / "config.local.json").exists() else ""
    return Check("설정 파일", OK, f"config.json{local} 정상")


# 앱 안의 Claude Code CLI 자리 — 앱 업데이트로 바뀌어 옴(scripts/common.ps1 Find-ClaudeExe와 같은 순서, 고치면 같이)
CLAUDE_GLOBS = [r"%LOCALAPPDATA%\Claude-Data\claude_*\claude-code\*\*\claude.exe",                  # 2026-11 앱 4.23118~
                r"%APPDATA%\Claude\claude-code\*\*\claude.exe",                                       # 예전
                r"%LOCALAPPDATA%\Packages\Claude_*\LocalCache\Roaming\Claude\claude-code\*\*\claude.exe"]  # 예전 스토어판(앱 밖)


def find_claude() -> Path | None:
    env = os.environ.get("HANDPILOT_CLAUDE")
    if env and Path(env).exists():
        return Path(env)
    c = [p for g in CLAUDE_GLOBS for p in glob.glob(os.path.expandvars(g))]
    if not c:  # 마지막 수단: 실행 중인 claude.exe(프로세스 목록 — 폴더 전환과 상관없음)
        r = subprocess.run(["powershell", "-NoProfile", "-Command",
                            "Get-CimInstance Win32_Process -Filter \"Name='claude.exe'\" | ForEach-Object { $_.ExecutablePath }"],
                           capture_output=True, text=True, creationflags=NO_WINDOW)
        c = [line.strip() for line in r.stdout.splitlines() if "\\claude-code\\" in line]

    def ver(p):
        try:
            return tuple(int(x) for x in Path(p).parent.parent.name.split("."))
        except ValueError:
            return (0,)
    return Path(max(c, key=ver)) if c else None


def check_claude() -> Check:
    c = find_claude()
    if not c:
        return Check("Claude Code", FAIL, "앱 안의 Claude Code를 찾지 못함", "Claude 데스크톱 앱 설치 후 Code 탭을 한 번 열기")
    return Check("Claude Code", OK, f"{c.parent.parent.name} (앱 내장 CLI)", data={"path": str(c)})


def check_plugin() -> Check:
    home = Path.home() / ".claude"
    try:
        s = json.loads((home / "settings.json").read_text(encoding="utf-8"))
    except Exception:
        return Check("플러그인 등록", FAIL, "Claude 설정 파일을 읽지 못함", "install.ps1 실행")
    path = (((s.get("extraKnownMarketplaces") or {}).get("handpilot-local") or {}).get("source") or {}).get("path")
    enabled = (s.get("enabledPlugins") or {}).get("handpilot@handpilot-local")
    if not path:
        return Check("플러그인 등록", FAIL, "로컬 마켓플레이스가 등록되지 않음", "install.ps1 실행")
    if Path(path).resolve() != ROOT.resolve():
        return Check("플러그인 등록", FAIL, f"다른 폴더가 등록됨: {path}", "이 폴더에서 install.ps1 실행")
    if not enabled:
        return Check("플러그인 등록", WARN, "등록됐지만 꺼져 있음", "settings.json enabledPlugins에서 true로")
    try:
        inst = json.loads((home / "plugins" / "installed_plugins.json").read_text(encoding="utf-8"))
        rec = inst["plugins"]["handpilot@handpilot-local"][0]
    except Exception:
        return Check("플러그인 등록", FAIL, "설치 기록 없음", "install.ps1 실행")
    repo = plugin_version()
    cache = Path(rec["installPath"])
    if rec.get("version") != repo:
        return Check("플러그인 등록", WARN, f"설치본 {rec.get('version')} ≠ 저장소 {repo}", "update.ps1 실행",
                     data={"installed": rec.get("version"), "repo": repo})
    if not cache.exists():
        return Check("플러그인 등록", FAIL, f"설치본 폴더 없음 ({cache})", "update.ps1 실행")
    local_mcp = HP / ".mcp.json"
    if local_mcp.exists() and (cache / ".mcp.json").exists() and \
            (cache / ".mcp.json").read_text(encoding="utf-8").strip() != local_mcp.read_text(encoding="utf-8").strip():
        return Check("플러그인 등록", WARN, "설치본의 실행 경로가 이 폴더와 다름", "release.ps1(개발 PC) 또는 update.ps1")
    return Check("플러그인 등록", OK, f"사용 중, 설치본 {repo} = 저장소 {repo}", data={"installed": repo, "repo": repo})


def list_servers() -> list[dict]:
    out = _ps("Get-CimInstance Win32_Process -Filter \"Name='python.exe'\" | Where-Object { $_.CommandLine -like '*handpilot*server.py*' } | "
              "ForEach-Object { '{0}|{1}|{2}|{3}' -f $_.ProcessId, $_.ParentProcessId, $_.CreationDate.ToString('yyyy-MM-dd HH:mm:ss'), $_.WorkingSetSize }")
    rows = [l.split("|") for l in out.splitlines() if l.count("|") == 3]
    pids = {int(r[0]) for r in rows}
    servers = []
    for pid, ppid, started, ws in rows:
        if int(ppid) in pids:  # 가상환경 실행기의 자식(실제 python)은 부모 쪽에 합친다
            continue
        child = next((r for r in rows if int(r[1]) == int(pid)), None)
        mem = int(ws) + (int(child[3]) if child else 0)
        servers.append({"pid": int(pid), "started": started, "mb": round(mem / 2**20)})
    return servers


def check_servers() -> Check:
    servers = list_servers()
    newest = max((HP / f).stat().st_mtime for f in ("server.py", "guard.py", "lease.py"))
    stale = [s for s in servers if time.mktime(time.strptime(s["started"], "%Y-%m-%d %H:%M:%S")) < newest]
    total = sum(s["mb"] for s in servers)
    data = {"servers": servers, "stale": [s["pid"] for s in stale]}
    if not servers:
        return Check("실행 중인 서버", INFO, "없음 (채팅창에서 부르면 자동으로 켜짐)", data=data)
    if stale:
        return Check("실행 중인 서버", WARN, f"{len(servers)}개, {total}MB — 그중 {len(stale)}개가 예전 코드",
                     "그냥 두면 10분 미사용 후 자동 교체, 바로 바꾸려면 update.ps1 -RestartServers", data=data)
    return Check("실행 중인 서버", OK, f"{len(servers)}개, {total}MB, 모두 최신 코드", data=data)


def check_lock() -> Check:
    import msvcrt
    from lease import LOCK_PATH, OWNER_PATH
    if not LOCK_PATH.exists():
        return Check("조작권", INFO, "아직 사용한 적 없음")
    fd = os.open(str(LOCK_PATH), os.O_RDWR)
    try:
        os.lseek(fd, 0, 0)
        try:
            msvcrt.locking(fd, msvcrt.LK_NBLCK, 1)
            os.lseek(fd, 0, 0)
            msvcrt.locking(fd, msvcrt.LK_UNLCK, 1)
            held = False
        except OSError:
            held = True
    finally:
        os.close(fd)
    try:
        o = json.loads(OWNER_PATH.read_text(encoding="utf-8"))
    except Exception:
        o = {}
    if not held:
        return Check("조작권", OK, "비어 있음 (어느 채팅창이든 사용 가능)", data={"held": False})
    who = o.get("label", "알 수 없는 채팅창")
    if o.get("paused"):
        return Check("조작권", WARN, f"「{who}」이 일시정지 상태로 보유 중", "화면 구석 표시창에서 [재개] 또는 [종료]",
                     data={"held": True, **o})
    return Check("조작권", INFO, f"「{who}」이 사용 중", data={"held": True, **o})


def check_session_files() -> Check:
    from lease import session_files
    files = session_files()
    if not files:
        return Check("채팅창 이름 읽기", WARN, "앱 세션 파일을 찾지 못함 → 표시창에 폴더명으로 표시됨",
                     "Claude 앱 업데이트로 위치가 바뀌었을 수 있음 (OPERATIONS.md)")
    good = 0
    for f in files[:30]:
        try:
            d = json.loads(Path(f).read_text(encoding="utf-8"))
            good += bool(d.get("cliSessionId")) and "title" in d
        except Exception:
            pass
    if good == 0:
        return Check("채팅창 이름 읽기", WARN, "세션 파일 형식이 바뀐 것 같음(cliSessionId/title 없음)", "lease.py SessionLabel 확인")
    return Check("채팅창 이름 읽기", OK, f"세션 파일 {len(files)}개, 형식 정상")


def check_git(fetch: bool = False) -> Check:
    if not (ROOT / ".git").exists():
        return Check("git", INFO, "사이트 배포판(설치 파일로 설치) — 업데이트는 설치 안내 사이트에서 받음(GitHub·Git 필요 없음)")

    def git(*a):
        try:
            r = subprocess.run(["git", *a], cwd=ROOT, capture_output=True, text=True, encoding="utf-8", errors="replace",
                               creationflags=NO_WINDOW)
        except OSError:
            return 1, ""
        return r.returncode, r.stdout.strip()
    code, _ = git("rev-parse", "--is-inside-work-tree")
    if code != 0:
        return Check("git", INFO, "git 저장소 아님(폴더 복사 설치)")
    _, branch = git("rev-parse", "--abbrev-ref", "HEAD")
    _, desc = git("describe", "--tags", "--always")
    _, dirty = git("status", "--porcelain", "--untracked-files=no")
    _, remote = git("remote")
    parts = [f"{branch} @ {desc}"]
    status, fix = OK, ""
    if dirty:
        parts.append(f"수정된 파일 {len(dirty.splitlines())}개")
        status, fix = WARN, "개발 중이 아니라면 PC 전용 설정은 config.local.json으로 옮기세요(업데이트가 멈춤)"
    if not remote:
        parts.append("원격 저장소 없음")
        if status == OK:
            status = INFO
    else:
        if fetch:
            git("fetch", "-q")
        _, behind = git("rev-list", "--count", "HEAD..@{u}")
        if behind and behind != "0":
            parts.append(f"새 커밋 {behind}개")
            status, fix = WARN, "update.ps1 실행"
    return Check("git", status, ", ".join(parts), fix)


def auto_update_on() -> bool:
    """새 버전 자동 설치(auto_update, 기본 켜짐) — 공용 config.json → 이 PC 전용 config.local.json 순서."""
    on = True
    for name in ("config.json", "config.local.json"):
        try:
            d = json.loads((HP / name).read_text(encoding="utf-8"))
        except (OSError, ValueError):
            continue
        if "auto_update" in d:
            on = bool(d["auto_update"])
    return on


def check_update_notice() -> Check:
    marker = Path(os.environ.get("LOCALAPPDATA", "")) / "handpilot" / "update-available.json"
    r = subprocess.run(["schtasks", "/Query", "/TN", "핸드파일럿 업데이트 확인"], capture_output=True, creationflags=NO_WINDOW)
    auto = auto_update_on()
    task = ("정기 확인(매주) 켜짐" if r.returncode == 0 else "정기 확인 꺼짐") + (" · 자동 설치 켜짐" if auto else " · 자동 설치 꺼짐(설치 창)")
    data = {"task": r.returncode == 0, "auto": auto}
    if marker.exists():
        try:
            m = json.loads(marker.read_text(encoding="utf-8"))
            if m.get("auto"):
                return Check("업데이트 알림", INFO, f"새 버전 {m.get('version') or m.get('latest', '')} 자동 설치 대기 · {task}",
                             "핸드파일럿을 약 10분 안 쓰면 저절로 설치(지금 하려면 [지금 설치…])", data={**data, "available": True})
            return Check("업데이트 알림", WARN, f"새 버전 있음(변경 {m.get('behind')}개: {m.get('latest', '')}) · {task}",
                         "관리 창 상태 탭의 [지금 설치…] 또는 update.ps1", data={**data, "available": True})
        except ValueError:
            pass
    return Check("업데이트 알림", INFO, f"알려진 새 버전 없음 · {task}", data={**data, "available": False})


def check_logs() -> Check:
    log_dir = Path(os.environ.get("LOCALAPPDATA", "")) / "handpilot" / "logs"
    files = sorted(log_dir.glob("handpilot-*.log")) if log_dir.exists() else []
    if not files:
        return Check("로그", INFO, "로그 없음")
    size = sum(f.stat().st_size for f in files)
    cutoff = time.time() - 86400
    errors = 0
    for f in files[-2:]:
        for line in f.read_text(encoding="utf-8", errors="replace").splitlines():
            if '"level": "error"' in line or '"level":"error"' in line:
                try:
                    if json.loads(line).get("ts", 0) >= cutoff:
                        errors += 1
                except ValueError:
                    pass
    detail = f"{len(files)}개 파일, {size / 2**20:.1f}MB, 최근 24시간 오류 {errors}건"
    return Check("로그", WARN if errors else OK, detail, "로그 폴더에서 error 줄 확인" if errors else "",
                 data={"dir": str(log_dir), "errors_24h": errors})


def check_screen() -> Check:
    try:
        ctypes.windll.shcore.SetProcessDpiAwareness(2)
    except Exception:
        pass
    u = ctypes.windll.user32
    w, h = u.GetSystemMetrics(0), u.GetSystemMetrics(1)
    dpi = u.GetDpiForSystem()
    mons = u.GetSystemMetrics(80)
    note = f"주 모니터 {w}×{h}, 배율 {round(dpi / 96 * 100)}%, 모니터 {mons}개"
    if mons > 1:
        return Check("화면", INFO, note + " (주 모니터만 조작)")
    return Check("화면", OK, note)


def run_checks(fetch: bool = False) -> list[Check]:
    checks = []
    for fn in (check_python, check_libraries, check_mcp_json, check_hooks, check_config, check_claude, check_plugin,
               check_servers, check_lock, check_session_files, lambda: check_git(fetch), check_update_notice, check_logs,
               check_screen):
        try:
            checks.append(fn())
        except Exception as e:  # 점검 하나가 실패해도 나머지는 계속
            name = getattr(fn, "__name__", "점검").replace("check_", "")
            checks.append(Check(name, FAIL, f"점검 중 오류: {e!r}"))
    return checks


def main() -> int:
    as_json = "--json" in sys.argv
    checks = run_checks(fetch="--fetch" in sys.argv)
    if as_json:
        print(json.dumps({"version": plugin_version(), "root": str(ROOT), "checks": [asdict(c) for c in checks]},
                         ensure_ascii=False, indent=1))
    else:
        print(f"핸드파일럿 상태 점검 — 버전 {plugin_version()} — {ROOT}\n")
        for c in checks:
            print(f"{ICON[c.status]} {c.name}: {c.detail}")
            if c.fix and c.status in (WARN, FAIL):
                print(f"     → 해결: {c.fix}")
        n = {s: sum(c.status == s for c in checks) for s in (OK, WARN, FAIL, INFO)}
        print(f"\n정상 {n[OK]} · 주의 {n[WARN]} · 문제 {n[FAIL]} · 참고 {n[INFO]}")
    return 1 if any(c.status == FAIL for c in checks) else 0


if __name__ == "__main__":
    sys.exit(main())
