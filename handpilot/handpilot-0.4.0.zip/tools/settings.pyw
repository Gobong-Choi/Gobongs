"""핸드파일럿 관리 창 (설정창).

실행: 시작 메뉴 "핸드파일럿 관리" 바로가기, 또는 .venv\\Scripts\\pythonw.exe tools\\settings.pyw
화면: 머리말(버전·전체 상태·새 버전 꼬리표) + 탭 4개 (Ctrl+Tab / Ctrl+1~4 로 이동)
  상태 — 전체 상태 카드(다시 점검·예전 코드 서버 교체), 업데이트 카드(버전·릴리스·이 PC에 설치·마지막 확인 →
         [업데이트 확인…] / [새 버전 보기·설치…] → 설치 창에서 [지금 설치]), 점검 목록(문제 먼저, 색 구분)
  설정 — 이 PC 전용 config.local.json. SECTIONS 묶음(두 열), 고급은 접힘. 저장 안 한 변경 표시, 닫을 때 확인
  로그 — 오류·주의 줄 색 구분, 대기 측정 요약
  정보 — 버전·폴더(열기), 정기 업데이트 확인 스위치, 문서

- 설정은 공용 config.json과 다른 값만 config.local.json에 저장한다(업데이트·git과 충돌 없음).
  저장하면 실행 중인 채팅창 서버에도 다음 호출부터 바로 적용된다.
- 모양은 tools/ui_style.py(표준 라이브러리만, 업데이트 설치 창과 같이 씀).
- 테스트용: --snapshot <폴더> 를 주면 탭마다 자기 창을 캡처해 PNG로 저장하고 닫힌다(마우스를 쓰지 않음).
"""

import ctypes
import datetime
import json
import os
import queue
import re
import subprocess
import sys
import threading
import time
import tkinter as tk
from pathlib import Path
from tkinter import messagebox, ttk

ROOT = Path(__file__).resolve().parents[1]
HP = ROOT / "handpilot"
sys.path.insert(0, str(HP))
sys.path.insert(0, str(Path(__file__).resolve().parent))

try:
    ctypes.windll.shcore.SetProcessDpiAwareness(2)
except Exception:
    pass

import doctor  # noqa: E402
import ui_style as ui  # noqa: E402
from guard import CONFIG_PATH, DEFAULTS, LOCAL_CONFIG_PATH, load_config  # noqa: E402

STATE_DIR = Path(os.environ.get("LOCALAPPDATA", "")) / "handpilot"
LOG_DIR = STATE_DIR / "logs"
NO_WINDOW = 0x08000000  # CREATE_NO_WINDOW — pythonw에서 git 콘솔 창이 깜빡이지 않게

POSITIONS = {"top-right": "오른쪽 위", "top-left": "왼쪽 위", "bottom-right": "오른쪽 아래", "bottom-left": "왼쪽 아래"}

# (키, 설명, 종류, 최소, 최대, 도움말) — observe.x 는 화면 변화 감지 항목
FIELDS = [
    ("overlay_enabled", "작동 중 표시창 사용", "bool", None, None, "화면 구석의 작동 중 / 일시정지 표시"),
    ("overlay_position", "표시창 위치", "choice", None, None, ""),
    ("focus_claude_on_done", "끝나면 Claude 창을 앞으로", "bool", None, None,
     "핸드파일럿을 쓴 답변이 끝나면 Claude 앱을 맨 앞으로. 그때 사람이 입력 중이면 작업 표시줄만 깜빡임"),
    ("move_threshold_px", "정지 민감도 (px)", "int", 5, 300, "작업 중 마우스를 이만큼 움직이면 일시정지. 작을수록 민감"),
    ("active_window_sec", "사람 입력 감시 시간 (초)", "float", 1, 60, "마지막 동작 후 이 시간 동안 사람 입력을 감시"),
    ("lock_hold_sec", "조작권 유지 (초)", "int", 3, 300, "훅이 없는 채팅창에서 마지막 동작 후 유지 시간"),
    ("lock_hold_turn_sec", "답변 중 최대 유지 (초)", "int", 10, 1800, "답변이 끝나면 바로 반납. 이건 최대 안전 시간"),
    ("idle_exit_min", "자동 종료 (분, 0=안 함)", "float", 0, 240, "이 시간 동안 안 쓰면 서버가 꺼져 메모리를 돌려줌"),
    ("protect_claude_window", "Claude 앱 창 보호", "bool", None, None, "끄면 Claude 채팅창에 입력이 가능해져 위험"),
    ("esc_stop", "Esc로 정지", "bool", None, None, "핸드파일럿이 작업하는 동안(답변 중)엔 언제든 Esc로 즉시 정지. 안 쓸 때의 Esc는 무시"),
    ("stop_on_other_input", "다른 프로그램 입력에도 정지", "bool", None, None,
     "PowerToys 마우스 공유처럼 다른 PC에서 넘어온 마우스·키보드도 사람으로 보고 정지. 마우스 흔들기 같은 자동화 프로그램을 쓰면 끄기"),
    ("observe.max_crops", "바뀐 부분 최대 이미지 수", "int", 1, 6, "멀리 떨어진 변화를 따로 보낼 최대 장수"),
    ("observe.full_every", "전체 화면 주기 (회)", "int", 1, 50, "잘린 이미지를 이만큼 보내면 전체 화면 1번"),
    ("observe.wait_watch", "대기 측정 기록", "bool", None, None, "고정 대기 동안 화면이 언제 멈추는지 숫자만 기록(이 PC에만). 끄면 CPU 절약"),
    ("log_enabled", "로그 기록", "bool", None, None, "%LOCALAPPDATA%\\handpilot\\logs"),
    ("auto_update", "새 버전 자동 설치", "bool", None, None,
     "정기 확인(정보 탭)에서 새 버전을 찾으면 핸드파일럿을 안 쓸 때(약 10분 뒤) 알아서 설치하고 Windows 알림. 끄면 설치 창만 띄움"),
    ("log_retention_days", "로그 보관 (일)", "int", 1, 3650, "지난 로그는 자동 삭제"),
]

# 설정 탭 묶음 (제목, 설명, FIELDS 키들, 처음에 접어 둘지). 여기 없는 새 항목은 '기타' 묶음에 자동으로 들어간다.
SECTIONS = [
    ("작동 중 표시창", "Claude가 조작하는 동안 화면 구석에 뜨는 표시, 끝났을 때 Claude 창", ["overlay_enabled", "overlay_position", "focus_claude_on_done"], False),
    ("정지·안전", "사람이 마우스·키보드를 만지면 멈추는 기준", ["move_threshold_px", "active_window_sec", "esc_stop", "stop_on_other_input", "protect_claude_window"], False),
    ("조작권·자동 종료", "여러 채팅창이 번갈아 쓸 때의 순서와 메모리", ["lock_hold_sec", "lock_hold_turn_sec", "idle_exit_min"], False),
    ("로그", "입력한 글자 내용은 남기지 않음(글자 수만)", ["log_enabled", "log_retention_days"], False),
    ("업데이트", "정기 확인에서 새 버전을 찾았을 때", ["auto_update"], False),
    ("화면 변화 감지 (고급)", "보통은 바꿀 필요 없음", ["observe.max_crops", "observe.full_every", "observe.wait_watch"], True),
]
# 앞 항목이 켜져 있어야 의미가 있는 항목 — 꺼져 있으면 흐리게
DEPENDS = {"overlay_position": "overlay_enabled", "log_retention_days": "log_enabled"}

ORDER = {doctor.FAIL: 0, doctor.WARN: 1, doctor.INFO: 2, doctor.OK: 3}


def _get(d: dict, key: str):
    if "." in key:
        a, b = key.split(".", 1)
        return (d.get(a) or {}).get(b)
    return d.get(key)


def shared_config() -> dict:
    """기본값 + 공용 config.json (이 PC 전용 설정 제외)."""
    cfg = json.loads(json.dumps(DEFAULTS))
    cfg.setdefault("protect_claude_window", True)
    cfg.setdefault("auto_update", True)  # update.ps1이 읽는 항목(서버 기본값엔 없음)
    try:
        import actions
        cfg["observe"] = dict(actions.OBSERVE_DEFAULTS)
    except Exception:
        cfg["observe"] = {}
    try:
        shared = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
    except Exception:
        shared = {}
    for k, v in shared.items():
        if isinstance(v, dict):
            cfg.setdefault(k, {}).update(v)
        else:
            cfg[k] = v
    return cfg


def _num(val) -> str:
    """숫자 칸에 보일 글자: 10.0 → '10', 2.5 → '2.5' (되돌리기 후에도 처음과 같게)."""
    if val is None:
        return ""
    return f"{val:g}" if isinstance(val, float) else str(val)


def read_local() -> dict:
    try:
        return json.loads(LOCAL_CONFIG_PATH.read_text(encoding="utf-8"))
    except Exception:
        return {}


# ---------------------------------------------------------------- 업데이트 카드에 보일 사실들


def _git(*args) -> tuple[int, str]:
    try:
        r = subprocess.run(["git", *args], cwd=ROOT, capture_output=True, text=True, encoding="utf-8",
                           errors="replace", creationflags=NO_WINDOW)
    except OSError:  # Git이 없는 PC(사이트 배포판)
        return 1, ""
    return r.returncode, r.stdout.strip()


def release_date(version: str) -> str:
    """CHANGELOG의 '## [버전] - 날짜'에서 날짜."""
    try:
        text = (ROOT / "CHANGELOG.md").read_text(encoding="utf-8")
    except OSError:
        return ""
    m = re.search(rf"^## \[{re.escape(version)}\]\s*-\s*(\S+)", text, re.M)
    return m.group(1) if m else ""


def update_facts() -> dict:
    """읽기만 한다(원격에 묻지 않음 — 확인은 [업데이트 확인…]이 설치 창에서).

    installed: 이 PC에서 코드가 마지막으로 바뀐 시각(git reflog — 업데이트 받기·커밋). git이 없으면 plugin.json 시각.
    checked:   마지막으로 원격을 확인한 시각(FETCH_HEAD — 정기 확인·[업데이트 확인]·update.ps1 모두 갱신).
    behind:    마지막 확인 기준으로 받을 변경 수(None = 원격 없음).
    """
    ver = doctor.plugin_version()
    f = {"version": ver, "released": release_date(ver), "installed": None, "checked": None,
         "behind": None, "latest": "", "git": False, "site": not (ROOT / ".git").exists()}
    try:
        marker = json.loads((STATE_DIR / "update-available.json").read_text(encoding="utf-8"))
        f["checked"] = marker.get("checked")
    except (OSError, ValueError):
        marker = None
    if f["site"]:
        # 사이트 배포판: 정기 확인·update.ps1이 남긴 마지막 확인(last-check.json)과 새 버전 표시로
        try:
            last = json.loads((STATE_DIR / "last-check.json").read_text(encoding="utf-8"))
            f["checked"] = max(f["checked"] or 0, last.get("checked") or 0) or None
            f["behind"] = 0
        except (OSError, ValueError):
            pass
        if marker:
            f["behind"] = int(marker.get("behind") or 1)
            f["latest"] = str(marker.get("version") or "")
    elif _git("rev-parse", "--is-inside-work-tree")[0] == 0:
        f["git"] = True
        m = re.search(r"\{(\d+)\}", _git("reflog", "-1", "--format=%gd", "--date=unix", "HEAD")[1])
        if m:
            f["installed"] = int(m.group(1))
        p = Path(_git("rev-parse", "--git-path", "FETCH_HEAD")[1])
        p = p if p.is_absolute() else ROOT / p
        if p.exists():
            f["checked"] = max(f["checked"] or 0, p.stat().st_mtime)
        f["remote"] = bool(_git("remote")[1])
        code, n = _git("rev-list", "--count", "HEAD..@{u}")
        if code == 0:
            f["behind"] = int(n or 0)
            if f["behind"]:
                try:
                    f["latest"] = json.loads(_git("show", "@{u}:handpilot/.claude-plugin/plugin.json")[1])["version"]
                except Exception:
                    pass
    elif marker:
        f["behind"] = int(marker.get("behind") or 1)
    if f["installed"] is None:
        try:
            f["installed"] = (HP / ".claude-plugin" / "plugin.json").stat().st_mtime
        except OSError:
            pass
    return f


def when(ts) -> str:
    """'2026-10-06 16:18 · 오늘' 꼴."""
    if not ts:
        return "—"
    t = time.localtime(ts)
    days = (datetime.date.today() - datetime.date(t.tm_year, t.tm_mon, t.tm_mday)).days
    rel = "오늘" if days == 0 else "어제" if days == 1 else f"{days}일 전" if days > 1 else ""
    return time.strftime("%Y-%m-%d %H:%M", t) + (f" · {rel}" if rel else "")


class App:
    TABS = ("상태", "설정", "로그", "정보")

    def __init__(self, root: tk.Tk):
        self.root = root
        root.title(f"핸드파일럿 관리 — {doctor.plugin_version()}")
        ui.fit_window(root, 960, 700, 760, 540)  # 화면 배율에 맞춤(배율 큰 PC에서 잘림 방지)
        ui.apply(root)
        self.k = ui.scale(root)
        self.checks = []
        self.facts = {}
        self.current = None
        self.done: queue.Queue = queue.Queue()
        self._poll_id = root.after(100, self._poll)
        # 창을 닫을 때 예약해 둔 확인을 취소(남아 있으면 'invalid command name' 경고)
        root.bind("<Destroy>", lambda e: e.widget is root and root.after_cancel(self._poll_id), add="+")
        self.header()
        body = tk.Frame(root, background=ui.BG)
        body.pack(fill="both", expand=True, padx=18, pady=(14, 16))
        self.pages = {}
        for name, build in zip(self.TABS, (self.status_tab, self.settings_tab, self.log_tab, self.info_tab)):
            page = tk.Frame(body, background=ui.BG)
            self.pages[name] = page
            build(page)
        self.show("상태")
        root.bind("<Control-Tab>", lambda e: self.cycle(1))
        root.bind("<Control-Shift-Tab>", lambda e: self.cycle(-1))
        for i, name in enumerate(self.TABS, start=1):
            root.bind(f"<Control-Key-{i}>", lambda e, n=name: self.show(n) or "break")
        root.protocol("WM_DELETE_WINDOW", self.on_close)
        self.refresh_status()

    # ------------------------------------------------------------------ 뒤에서 하는 일
    def bg(self, work, then):
        """work()를 뒤에서 돌리고, 끝나면 화면 쪽에서 then(결과)를 부른다.
        뒤 스레드에서 tkinter를 직접 부르지 않는다(메인 반복 전이면 'main thread is not in main loop' 오류)."""
        def run():
            try:
                self.done.put((then, work()))
            except Exception as e:  # 실패해도 화면이 '확인 중…'에 멈추지 않게 알린다
                self.done.put((lambda _: messagebox.showerror("핸드파일럿", f"작업 중 오류: {e!r}"), None))
        threading.Thread(target=run, daemon=True).start()

    def _poll(self):
        try:
            while True:
                then, result = self.done.get_nowait()
                then(result)
        except queue.Empty:
            pass
        finally:  # then()이 오류를 내도 다음 결과를 계속 받는다
            self._poll_id = self.root.after(100, self._poll)

    # ------------------------------------------------------------------ 머리말·탭
    def header(self):
        h = tk.Frame(self.root, background=ui.CARD)
        h.pack(fill="x")
        top = tk.Frame(h, background=ui.CARD)
        top.pack(fill="x", padx=22, pady=(14, 4))
        ui.label(top, "핸드파일럿 관리", font=ui.FONT_H1).pack(side="left")
        ui.muted(top, f"v{doctor.plugin_version()}", font=ui.FONT).pack(side="left", padx=(8, 0), pady=(4, 0))
        self.head_status = ui.pill(top, "점검 중…")
        self.head_status.pack(side="right")
        self.head_update = ui.pill(top, "새 버전 있음", "warn", cursor="hand2")
        self.head_update.bind("<Button-1>", lambda e: self.show("상태"))
        nav = tk.Frame(h, background=ui.CARD)
        nav.pack(fill="x", padx=12)
        self.nav = {}
        for name in self.TABS:
            cell = tk.Frame(nav, background=ui.CARD)
            cell.pack(side="left", padx=2)
            lab = tk.Label(cell, text=name, font=ui.FONT_B, background=ui.CARD, foreground=ui.MUTED,
                           padx=14, pady=7, cursor="hand2")
            lab.pack()
            bar = tk.Frame(cell, height=3, background=ui.CARD)
            bar.pack(fill="x")
            lab.bind("<Button-1>", lambda e, n=name: self.show(n))
            lab.bind("<Enter>", lambda e, n=name: n != self.current and self.nav[n][0].config(foreground=ui.TEXT))
            lab.bind("<Leave>", lambda e, n=name: n != self.current and self.nav[n][0].config(foreground=ui.MUTED))
            self.nav[name] = (lab, bar)
        tk.Frame(self.root, height=1, background=ui.BORDER).pack(fill="x")

    def show(self, name: str):
        if self.current:
            self.pages[self.current].pack_forget()
        self.current = name
        self.pages[name].pack(fill="both", expand=True)
        for n, (lab, bar) in self.nav.items():
            lab.config(foreground=ui.ACCENT if n == name else ui.MUTED)
            bar.config(background=ui.ACCENT if n == name else ui.CARD)

    def cycle(self, step: int):
        i = self.TABS.index(self.current)
        self.show(self.TABS[(i + step) % len(self.TABS)])
        return "break"  # 'all'의 Tab(포커스 이동)까지 가지 않게

    def on_close(self):
        n = len(self.dirty_keys())
        if n:
            ans = messagebox.askyesnocancel("핸드파일럿", f"저장하지 않은 설정 변경이 {n}개 있어요.\n저장하고 닫을까요?\n\n"
                                                      "[예] 저장하고 닫기 · [아니요] 저장하지 않고 닫기 · [취소] 돌아가기")
            if ans is None:
                return
            if ans and not self.save_settings():
                return
        self.root.destroy()

    # ------------------------------------------------------------------ 상태
    def status_tab(self, f):
        top = tk.Frame(f, background=ui.BG)
        top.pack(fill="x")
        top.columnconfigure(0, weight=1, uniform="c")
        top.columnconfigure(1, weight=1, uniform="c")

        c = ui.card(top)
        c.grid(row=0, column=0, sticky="nsew", padx=(0, 8))
        ui.muted(c, "전체 상태", font=ui.FONT_B).pack(anchor="w")
        self.st_head = ui.label(c, "점검 중…", font=ui.FONT_BIG)
        self.st_head.pack(anchor="w", pady=(6, 2))
        self.st_sub = ui.muted(c, "", font=ui.FONT, wraplength=int(390 * self.k))
        self.st_sub.pack(anchor="w")
        bar = tk.Frame(c, background=ui.CARD)
        bar.pack(anchor="w", pady=(14, 0))
        ttk.Button(bar, text="다시 점검", command=self.refresh_status).pack(side="left")
        self.st_stale = ttk.Button(bar, text="예전 코드 서버 교체…", command=self.restart_stale)

        u = ui.card(top)
        u.grid(row=0, column=1, sticky="nsew", padx=(8, 0))
        row = tk.Frame(u, background=ui.CARD)
        row.pack(fill="x")
        ui.muted(row, "업데이트", font=ui.FONT_B).pack(side="left")
        self.up_pill = ui.pill(row, "확인 중…")
        self.up_pill.pack(side="right")
        ui.label(u, f"버전 {doctor.plugin_version()}", font=ui.FONT_BIG).pack(anchor="w", pady=(6, 4))
        g = tk.Frame(u, background=ui.CARD)
        g.pack(anchor="w")
        self.up_rows = {}
        for i, k in enumerate(("릴리스", "이 PC에 설치", "마지막 확인")):
            ui.muted(g, k).grid(row=i, column=0, sticky="w", pady=1)
            v = ui.label(g, "…", font=ui.FONT_SMALL)
            v.grid(row=i, column=1, sticky="w", padx=(14, 0))
            self.up_rows[k] = v
        ub = tk.Frame(u, background=ui.CARD)
        ub.pack(anchor="w", fill="x", pady=(12, 0))
        self.up_btn = ttk.Button(ub, text="업데이트 확인…", style="Accent.TButton", command=self.on_update_button)
        self.up_btn.pack(side="left")
        self.up_note = ui.muted(ub, "설치는 다음 창에서\n[지금 설치]를 눌러야 시작돼요")
        self.up_note.pack(side="left", padx=(12, 0))

        lc = ui.card(f, padding=0)
        lc.pack(fill="both", expand=True, pady=(16, 0))
        lh = tk.Frame(lc, background=ui.CARD)
        lh.pack(fill="x", padx=16, pady=(12, 6))
        ui.label(lh, "점검 항목", font=ui.FONT_H2).pack(side="left")
        self.st_counts = ui.muted(lh, "")
        self.st_counts.pack(side="right")
        self.fix = tk.Label(lc, text="", font=ui.FONT, foreground=ui.TONE["warn"][0], background=ui.CARD,
                            anchor="w", justify="left", wraplength=int(860 * self.k))
        self.fix.pack(side="bottom", fill="x", padx=16, pady=(6, 12))
        box = tk.Frame(lc, background=ui.CARD)
        box.pack(fill="both", expand=True, padx=(8, 4))
        self.tree = ttk.Treeview(box, columns=("icon", "item", "detail"), show="", style="Flat.Treeview",
                                 selectmode="browse")
        self.tree.column("icon", width=int(36 * self.k), stretch=False, anchor="center")
        self.tree.column("item", width=int(170 * self.k), stretch=False)
        self.tree.column("detail", width=int(600 * self.k))
        for st in (doctor.FAIL, doctor.WARN):
            self.tree.tag_configure(st, background=ui.TONE[st][1])
        self.tree.tag_configure(doctor.OK, foreground=ui.TEXT)
        ui.autohide_scrollbar(box, self.tree)
        self.tree.bind("<<TreeviewSelect>>", self.on_select)

    def refresh_status(self):
        self.st_head.config(text="점검 중…", foreground=ui.MUTED)
        ui.set_pill(self.head_status, "점검 중…", "neutral")
        self.bg(self._run_checks, lambda r: self._show_checks(*r))

    @staticmethod
    def _run_checks():
        checks = doctor.run_checks()
        try:
            facts = update_facts()
        except Exception as e:  # 업데이트 정보가 안 돼도 점검 결과는 보여 준다
            facts = {"error": repr(e)}
        return checks, facts

    def _show_checks(self, checks, facts):
        self.checks = sorted(checks, key=lambda c: ORDER.get(c.status, 9))  # 문제 먼저(같은 등급은 원래 순서)
        self.tree.delete(*self.tree.get_children())
        for i, c in enumerate(self.checks):
            self.tree.insert("", "end", iid=str(i), values=(doctor.ICON[c.status], c.name, c.detail), tags=(c.status,))
        n = {s: sum(c.status == s for c in checks) for s in (doctor.OK, doctor.WARN, doctor.FAIL, doctor.INFO)}
        self.st_counts.config(text=f"정상 {n['ok']} · 주의 {n['warn']} · 문제 {n['fail']} · 참고 {n['info']}")
        stamp = time.strftime("%H:%M:%S")
        bad = [c for c in self.checks if c.status in (doctor.FAIL, doctor.WARN)]
        if n["fail"]:
            head, tone = f"문제 {n['fail']}개", "fail"
        elif n["warn"]:
            head, tone = f"확인할 것 {n['warn']}개", "warn"
        else:
            head, tone = "정상 작동 중", "ok"
        self.st_head.config(text=head, foreground=ui.TONE[tone][0])
        ui.set_pill(self.head_status, head, tone)
        if bad:
            names = ", ".join(c.name for c in bad[:3]) + (" 외" if len(bad) > 3 else "")
            self.st_sub.config(text=f"{names} — 아래 목록에서 눌러 해결 방법을 보세요. ({stamp} 점검)")
        else:
            self.st_sub.config(text=f"점검 {len(checks)}개 모두 이상 없어요. ({stamp} 점검)")
        self.fix.config(text=f"→ {bad[0].name}: {bad[0].fix}" if bad and bad[0].fix else "")
        srv = next((c for c in checks if c.name == "실행 중인 서버"), None)
        if srv and (srv.data or {}).get("stale"):
            self.st_stale.pack(side="left", padx=(8, 0))
        else:
            self.st_stale.pack_forget()
        self._show_update(facts)

    def _show_update(self, f):
        self.facts = f
        if f.get("error"):
            ui.set_pill(self.up_pill, "확인 못 함", "neutral")
            return
        self.up_rows["릴리스"].config(text=f.get("released") or "—")
        self.up_rows["이 PC에 설치"].config(text=when(f.get("installed")))
        self.up_rows["마지막 확인"].config(text=when(f["checked"]) if f.get("checked") else "아직 확인 안 함")
        if f.get("behind"):
            ui.set_pill(self.up_pill, f"새 버전 {f.get('latest') or ''} 있음".replace("  ", " "), "warn")
            self.up_btn.config(text="새 버전 보기·설치…")
            self.head_update.pack(side="right", padx=(0, 8))
        else:
            self.head_update.pack_forget()
            self.up_btn.config(text="업데이트 확인…")
            if f.get("behind") is None:
                kind = (("원격 추적 없는 브랜치" if f.get("remote") else "원격 저장소 없음") if f.get("git")
                        else "사이트 배포판" if f.get("site") else "폴더 복사 설치")
                ui.set_pill(self.up_pill, kind, "neutral")
            elif f.get("checked"):
                ui.set_pill(self.up_pill, "최신 버전", "ok")
            else:
                ui.set_pill(self.up_pill, "확인 필요", "neutral")

    def on_select(self, _):
        sel = self.tree.selection()
        if sel:
            c = self.checks[int(sel[0])]
            self.fix.config(text=f"→ {c.name}: {c.fix}" if c.fix else "")

    def restart_stale(self):
        c = next((c for c in self.checks if c.name == "실행 중인 서버"), None)
        stale = (c.data or {}).get("stale", []) if c else []
        if not stale:
            messagebox.showinfo("핸드파일럿", "예전 코드로 도는 서버가 없습니다.")
            return
        if not messagebox.askyesno("핸드파일럿", f"예전 코드로 도는 서버 {len(stale)}개를 종료할까요?\n"
                                                 "각 채팅창에서 핸드파일럿을 다음에 부를 때 최신 코드로 자동으로 켜집니다.\n"
                                                 "(그 채팅창에서 지금 작업 중인 동작이 있으면 1번 실패할 수 있음)"):
            return
        for pid in stale:
            subprocess.run(["taskkill", "/PID", str(pid), "/T", "/F"], capture_output=True, creationflags=NO_WINDOW)
        self.refresh_status()

    def on_update_button(self):
        # 새 버전을 이미 알면 받아 둔 정보로 바로(오프라인이어도 보임), 아니면 원격에서 먼저 확인
        self.open_update(fetch=not self.facts.get("behind"))

    def open_update(self, fetch: bool):
        """업데이트 설치 창(tools/update_prompt.pyw)을 띄우고, 닫히면 상태를 다시 점검한다."""
        self.st_sub.config(text="업데이트 창에서 확인 중… (창을 닫으면 다시 점검해요)")
        self.up_btn.state(["disabled"])
        args = [sys.executable, str(ROOT / "tools" / "update_prompt.pyw")] + (["--fetch"] if fetch else [])
        self.bg(lambda: subprocess.run(args, cwd=ROOT),
                lambda _: (self.up_btn.state(["!disabled"]), self.refresh_status()))

    @staticmethod
    def open_path(p: Path):
        p.mkdir(parents=True, exist_ok=True)
        os.startfile(str(p))

    # ------------------------------------------------------------------ 설정
    def settings_tab(self, f):
        intro = tk.Frame(f, background=ui.BG)
        intro.pack(fill="x", pady=(0, 12))
        ui.label(intro, "이 PC 전용 설정", font=ui.FONT_H2).pack(anchor="w")
        ui.muted(intro, "저장하면 실행 중인 채팅창에도 다음 동작부터 적용돼요. "
                        "공용 기본값과 다른 값만 handpilot\\config.local.json에 저장해요.").pack(anchor="w", pady=(2, 0))

        bar = tk.Frame(f, background=ui.BG)
        bar.pack(side="bottom", fill="x", pady=(12, 0))
        self.save_btn = ttk.Button(bar, text="저장", style="Accent.TButton", command=self.save_settings)
        self.save_btn.pack(side="left")
        self.revert_btn = ttk.Button(bar, text="되돌리기", command=self.revert_settings)
        self.revert_btn.pack(side="left", padx=8)
        self.saved = ui.label(bar, "")
        self.saved.pack(side="left", padx=4)
        ttk.Button(bar, text="기본값으로…", command=self.reset_settings).pack(side="right")

        sf = ui.ScrollFrame(f)
        sf.pack(fill="both", expand=True)
        body = sf.body
        body.columnconfigure(0, weight=1, uniform="s")
        body.columnconfigure(1, weight=1, uniform="s")
        self.meta = {k: (label, kind, lo, hi, help_) for k, label, kind, lo, hi, help_ in FIELDS}
        self.shared = shared_config()
        self.vars, self.rows, self.expanders = {}, {}, []
        sections = list(SECTIONS)
        rest = [k for k in self.meta if all(k not in s[2] for s in SECTIONS)]
        if rest:
            sections.append(("기타", "", rest, False))
        cols = [tk.Frame(body, background=ui.BG), tk.Frame(body, background=ui.BG)]
        cols[0].grid(row=0, column=0, sticky="new", padx=(0, 8))
        cols[1].grid(row=0, column=1, sticky="new", padx=(8, 0))
        eff = load_config()
        normal = [s for s in sections if not s[3]]
        for i, sec in enumerate(normal):
            self._section(cols[i % 2], sec, eff).pack(fill="x", pady=(0, 16))
        for j, sec in enumerate(s for s in sections if s[3]):
            self._section(body, sec, eff).grid(row=1 + j, column=0, columnspan=2, sticky="ew", pady=(0, 16))
        self.loaded = self._snapshot_values()
        for v in self.vars.values():
            v[0].trace_add("write", lambda *a: self._on_change())
        self._on_change()

    def _section(self, parent, sec, eff) -> tk.Frame:
        title, desc, keys, collapsed = sec
        c = ui.card(parent)
        head = tk.Frame(c, background=ui.CARD)
        head.pack(fill="x")
        rows = tk.Frame(c, background=ui.CARD)
        t = ui.label(head, title, font=ui.FONT_H2)
        t.pack(side="left")
        d = ui.muted(c, desc) if desc else None
        if d:
            d.pack(anchor="w", pady=(2, 0))
        if collapsed:  # 고급: 제목 줄을 누르면 펼침/접힘
            arrow = ui.label(head, "펼치기 ▾", fg=ui.ACCENT, font=ui.FONT_B, cursor="hand2")
            arrow.pack(side="right")
            t.config(cursor="hand2")

            def toggle(_=None):
                opening = not rows.winfo_manager()  # 탭이 숨어 있어도 맞게(ismapped 아님)
                arrow.config(text="접기 ▴" if opening else "펼치기 ▾")
                if opening:
                    rows.pack(fill="x")
                else:
                    rows.pack_forget()
            for w in (head, t, arrow):
                w.bind("<Button-1>", toggle)
            self.expanders.append(toggle)
        else:
            rows.pack(fill="x")
        for r, key in enumerate(keys):
            self._field(rows, r, key, eff)
        return c

    def _field(self, rows, r, key, eff):
        label, kind, lo, hi, help_ = self.meta[key]
        if r:
            tk.Frame(rows, height=1, background="#edf0f4").pack(fill="x", pady=(10, 0))
        row = tk.Frame(rows, background=ui.CARD)
        row.pack(fill="x", pady=(10, 0))
        txt = tk.Frame(row, background=ui.CARD)
        txt.pack(side="left", fill="x", expand=True)
        name = ui.label(txt, label)
        name.pack(anchor="w")
        hint = ui.muted(txt, help_, wraplength=int(250 * self.k))
        hint.pack(anchor="w")
        val = _get(eff, key)
        if kind == "bool":
            v = tk.BooleanVar(value=bool(val if val is not None else True))
            w = ui.Switch(row, variable=v)
        elif kind == "choice":
            v = tk.StringVar(value=POSITIONS.get(val or "top-right", "오른쪽 위"))
            w = ttk.Combobox(row, textvariable=v, values=list(POSITIONS.values()), state="readonly", width=11)
        else:
            v = tk.StringVar(value=_num(val))
            w = ttk.Spinbox(row, from_=lo, to=hi, textvariable=v, width=7, increment=0.5 if kind == "float" else 1)
        w.pack(side="right", padx=(12, 0))
        self.vars[key] = (v, kind, lo, hi)
        self.rows[key] = (name, hint, w, help_)

    def _parse(self, key):
        v, kind, lo, hi = self.vars[key]
        raw = v.get()
        if kind == "bool":
            return bool(raw)
        if kind == "choice":
            return {b: a for a, b in POSITIONS.items()}.get(raw, "top-right")
        try:
            num = float(raw)
        except ValueError:
            raise ValueError(f"'{self.meta[key][0]}' 값이 숫자가 아닙니다: {raw}")
        if not lo <= num <= hi:
            raise ValueError(f"'{self.meta[key][0]}' 값은 {lo:g}~{hi:g} 사이여야 합니다: {raw}")
        return int(num) if kind == "int" else num

    def _snapshot_values(self) -> dict:
        out = {}
        for key in self.vars:
            try:
                out[key] = self._parse(key)
            except ValueError:
                out[key] = None
        return out

    def dirty_keys(self) -> list:
        if not hasattr(self, "loaded"):
            return []
        cur = self._snapshot_values()
        return [k for k in self.vars if cur[k] != self.loaded.get(k) or cur[k] is None]

    def _on_change(self):
        dirty = set(self.dirty_keys())
        cur = self._snapshot_values()
        for key, (name, hint, w, help_) in self.rows.items():
            name.config(foreground=ui.ACCENT if key in dirty else ui.TEXT,
                        font=ui.FONT_B if key in dirty else ui.FONT)
            base = _get(self.shared, key)
            shown = POSITIONS.get(base, base) if self.vars[key][1] == "choice" else (
                ("켜짐" if base else "꺼짐") if self.vars[key][1] == "bool" else base)
            differs = base is not None and cur[key] is not None and cur[key] != base
            text = " · ".join(s for s in (help_, f"기본값 {shown}" if differs else "") if s)
            hint.config(text=text)
            if text:
                hint.pack(anchor="w")
            else:
                hint.pack_forget()
        for key, parent in DEPENDS.items():
            if key in self.rows and parent in self.vars:
                on = bool(self.vars[parent][0].get())
                w = self.rows[key][2]
                if isinstance(w, ttk.Combobox):
                    w.state(["!disabled", "readonly"] if on else ["disabled"])
                else:
                    w.state(["!disabled"] if on else ["disabled"])
                self.rows[key][0].config(foreground=(ui.ACCENT if key in dirty else ui.TEXT) if on else ui.SUBTLE)
        n = len(dirty)
        for b in (self.save_btn, self.revert_btn):
            b.state(["!disabled"] if n else ["disabled"])
        if n:
            self.saved.config(text=f"저장 안 한 변경 {n}개", foreground=ui.TONE["warn"][0])
        elif self.saved.cget("foreground") == ui.TONE["warn"][0]:
            self.saved.config(text="")
        self.nav["설정"][0].config(text="설정 •" if n else "설정")

    def _set_var(self, key, val):
        v, kind, lo, hi = self.vars[key]
        if kind == "bool":
            v.set(bool(val if val is not None else True))
        elif kind == "choice":
            v.set(POSITIONS.get(val, "오른쪽 위"))
        else:
            v.set(_num(val))

    def _form_values(self) -> dict:
        return {key: self._parse(key) for key in self.vars}

    def save_settings(self) -> bool:
        try:
            form = self._form_values()
        except ValueError as e:
            messagebox.showerror("핸드파일럿", str(e))
            return False
        shared = shared_config()
        local = read_local()
        for key, val in form.items():
            same = _get(shared, key) == val
            if "." in key:
                a, b = key.split(".", 1)
                sub = dict(local.get(a) or {})
                if same:
                    sub.pop(b, None)
                else:
                    sub[b] = val
                if sub:
                    local[a] = sub
                else:
                    local.pop(a, None)
            elif same:
                local.pop(key, None)
            else:
                local[key] = val
        if local:
            LOCAL_CONFIG_PATH.write_text(json.dumps(local, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        elif LOCAL_CONFIG_PATH.exists():
            LOCAL_CONFIG_PATH.unlink()
        n = len(local) + sum(len(v) - 1 for v in local.values() if isinstance(v, dict))
        self.loaded = form
        self.saved.config(text=f"저장됨 {time.strftime('%H:%M:%S')} — 공용과 다른 항목 {n}개", foreground=ui.TONE["ok"][0])
        self._on_change()
        return True

    def revert_settings(self):
        for key, val in self.loaded.items():
            if val is not None:
                self._set_var(key, val)
        self.saved.config(text="저장한 값으로 되돌림", foreground=ui.MUTED)

    def reset_settings(self):
        if not messagebox.askyesno("핸드파일럿", "이 PC 전용 설정(config.local.json)을 지우고 공용 설정으로 돌아갈까요?"):
            return
        if LOCAL_CONFIG_PATH.exists():
            LOCAL_CONFIG_PATH.unlink()
        eff = load_config()
        for key in self.vars:
            self._set_var(key, _get(eff, key))
        self.loaded = self._snapshot_values()
        self.saved.config(text="공용 설정으로 돌아감", foreground=ui.TONE["ok"][0])
        self._on_change()

    # ------------------------------------------------------------------ 로그
    def log_tab(self, f):
        bar = tk.Frame(f, background=ui.BG)
        bar.pack(fill="x")
        self.only_err = tk.BooleanVar(value=False)
        ttk.Checkbutton(bar, text="오류·주의만", variable=self.only_err, command=self.load_log).pack(side="left")
        ttk.Button(bar, text="새로고침", command=self.load_log).pack(side="left", padx=8)
        ttk.Button(bar, text="대기 측정 요약", command=self.wait_summary).pack(side="left")
        ttk.Button(bar, text="로그 폴더 열기", command=lambda: self.open_path(LOG_DIR)).pack(side="right")
        ui.muted(f, "입력한 글자 내용은 기록되지 않아요(글자 수만). 최근 300줄까지, 새것부터 보여요.").pack(anchor="w", pady=(8, 8))
        c = ui.card(f, padding=0)
        c.pack(fill="both", expand=True)
        box = tk.Frame(c, background=ui.CARD)
        box.pack(fill="both", expand=True, padx=(1, 1), pady=(1, 1))
        cols = ("time", "chat", "what", "result")
        self.log = ttk.Treeview(box, columns=cols, show="headings", style="Flat.Treeview")
        for col, t, w in (("time", "시각", 80), ("chat", "채팅창", 190), ("what", "내용", 330), ("result", "결과", 240)):
            self.log.heading(col, text=t, anchor="w")
            self.log.column(col, width=int(w * self.k), stretch=(col == "what"))
        self.log.tag_configure("error", foreground=ui.TONE["fail"][0], background=ui.TONE["fail"][1])
        self.log.tag_configure("warn", foreground=ui.TONE["warn"][0], background=ui.TONE["warn"][1])
        ui.autohide_scrollbar(box, self.log)
        self.load_log()

    def load_log(self):
        self.log.delete(*self.log.get_children())
        files = sorted(LOG_DIR.glob("handpilot-*.log")) if LOG_DIR.exists() else []
        rows = []
        for fpath in files[-2:]:
            for line in fpath.read_text(encoding="utf-8", errors="replace").splitlines()[-400:]:
                try:
                    rows.append(json.loads(line))
                except ValueError:
                    pass
        rows = [r for r in rows if "watch" not in r]  # 대기 측정 기록은 [대기 측정 요약]에서
        rows = [r for r in rows if not self.only_err.get() or r.get("level") in ("error", "warn")][-300:]
        for r in reversed(rows):
            what = r.get("msg", "")
            if r.get("comp") == "tool":
                args = r.get("args", {})
                what = f"{what}({', '.join(f'{k}={v}' for k, v in args.items())})"
                result = f"{r.get('outcome')} · {r.get('ms')}ms · {str(r.get('note', ''))[:40]}"
            else:
                result = f"{r.get('level')} · {r.get('comp')}"
            level = r.get("level")
            self.log.insert("", "end", values=(str(r.get("time", ""))[11:], r.get("chat", ""), what, result),
                            tags=(level,) if level in ("error", "warn") else ())

    def wait_summary(self):
        """고정 대기 기록(숫자만)으로 '대기 방식을 바꿨다면'을 계산해 보여 준다. 내보내기에는 채팅창 이름·시각·좌표가 없다."""
        import wait_report
        from tkinter import filedialog
        win = tk.Toplevel(self.root, background=ui.BG)
        win.title("대기 측정 요약 (최근 30일, 이 PC)")
        ui.fit_window(win, 760, 520, 480, 320)
        c = ui.card(win, padding=0)
        c.pack(fill="both", expand=True, padx=12, pady=(12, 8))
        box = tk.Frame(c, background=ui.CARD)
        box.pack(fill="both", expand=True, padx=8, pady=8)
        txt = tk.Text(box, wrap="word", font=ui.FONT_SMALL, relief="flat", borderwidth=0, background=ui.CARD,
                      foreground=ui.TEXT)
        ui.autohide_scrollbar(box, txt)
        txt.insert("end", wait_report.summary_text(30))
        txt.configure(state="disabled")
        bar = tk.Frame(win, background=ui.BG)
        bar.pack(fill="x", padx=12, pady=(0, 12))

        def save():
            p = filedialog.asksaveasfilename(parent=win, defaultextension=".json",
                                             initialfile=f"handpilot-대기측정-{time.strftime('%Y%m%d')}.json",
                                             filetypes=[("JSON", "*.json")])
            if p:
                wait_report.export(Path(p), 30)
                messagebox.showinfo("핸드파일럿", "숫자 요약만 저장했습니다(채팅창 이름·시각·좌표 없음).", parent=win)
        ttk.Button(bar, text="파일로 저장…", command=save).pack(side="left")
        ttk.Button(bar, text="닫기", command=win.destroy).pack(side="right")

    # ------------------------------------------------------------------ 정보
    def info_tab(self, f):
        sf = ui.ScrollFrame(f)
        sf.pack(fill="both", expand=True)
        body = sf.body

        c = ui.card(body)
        c.pack(fill="x")
        ui.label(c, "버전·위치", font=ui.FONT_H2).pack(anchor="w", pady=(0, 8))
        g = tk.Frame(c, background=ui.CARD)
        g.pack(fill="x")
        g.columnconfigure(1, weight=1)
        lines = [
            ("버전", doctor.plugin_version(), None),
            ("프로그램 폴더", str(ROOT), ROOT),
            ("Python", sys.version.split()[0], None),
            ("이 PC 전용 설정", str(LOCAL_CONFIG_PATH) + (" (있음)" if LOCAL_CONFIG_PATH.exists() else " (없음)"),
             LOCAL_CONFIG_PATH.parent),
            ("로그 폴더", str(LOG_DIR), LOG_DIR),
        ]
        for i, (k, v, p) in enumerate(lines):
            ui.muted(g, k, font=ui.FONT).grid(row=i, column=0, sticky="w", pady=3)
            ui.label(g, v, wraplength=int(640 * self.k)).grid(row=i, column=1, sticky="w", padx=14)
            if p is not None:
                ttk.Button(g, text="열기", style="Link.TButton", command=lambda p=p: self.open_path(p)).grid(
                    row=i, column=2, sticky="e")

        t = ui.card(body)
        t.pack(fill="x", pady=(16, 0))
        row = tk.Frame(t, background=ui.CARD)
        row.pack(fill="x")
        txt = tk.Frame(row, background=ui.CARD)
        txt.pack(side="left", fill="x", expand=True)
        ui.label(txt, "정기 업데이트 확인", font=ui.FONT_H2).pack(anchor="w")
        ui.muted(txt, "매주 월요일 오전 10시(Windows 작업 스케줄러)에 새 버전을 확인해, 있으면 핸드파일럿을 안 쓸 때"
                      "(마지막 사용 후 약 10분) 알아서 설치하고 Windows 알림으로 알려 줘요. 설정 탭 '새 버전 자동 설치'를 끄면 "
                      "대신 설치 창을 띄워요. PC가 꺼져 있던 주는 켜진 뒤 확인해요.", wraplength=int(720 * self.k)).pack(anchor="w", pady=(2, 0))
        self.task_var = tk.BooleanVar(value=False)
        self.task_switch = ui.Switch(row, variable=self.task_var, before=self._confirm_task)
        self.task_switch.pack(side="right", padx=(16, 0))
        self.task_switch.set_enabled(False)
        self.task_label = ui.label(t, "상태 확인 중…", fg=ui.MUTED)
        self.task_label.pack(anchor="w", pady=(10, 0))

        d = ui.card(body)
        d.pack(fill="x", pady=(16, 0))
        ui.label(d, "문서", font=ui.FONT_H2).pack(anchor="w", pady=(0, 8))
        bar = tk.Frame(d, background=ui.CARD)
        bar.pack(anchor="w")
        for name in ("README.md", "CHANGELOG.md", "docs/OPERATIONS.md", "docs/SETUP.md"):
            if (ROOT / name).exists():  # 사이트 배포판엔 README만 있음(작업 기록 문서는 공개 묶음에 넣지 않음)
                ttk.Button(bar, text=name, command=lambda n=name: os.startfile(str(ROOT / n))).pack(side="left", padx=(0, 6))
        ui.muted(d, "명령: 업데이트 update.ps1  ·  점검 doctor.ps1  ·  설치 install.ps1").pack(anchor="w", pady=(10, 0))
        self.refresh_task()

    def _task_script(self, *args) -> str:
        cmd = ("[Console]::OutputEncoding=[Text.Encoding]::UTF8; "
               f"& '{ROOT / 'scripts' / 'update-check-task.ps1'}' {' '.join(args)}")
        r = subprocess.run(["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", cmd],
                           capture_output=True, text=True, encoding="utf-8", errors="replace", creationflags=NO_WINDOW)
        return " ".join((r.stdout + r.stderr).split())

    def refresh_task(self):
        self.bg(self._task_script, self._set_task_label)

    def _set_task_label(self, text):
        text = text.replace("OK ", "").replace(".. ", "").split(" — 켜려면")[0]  # 스크립트용 안내 문구는 화면에서 뺌
        on = text.startswith("켜짐")
        self.task_var.set(on)
        self.task_switch.set_enabled(True)
        self.task_label.config(text=re.sub(r"^켜짐\(\S+\)\s*—\s*", "켜짐 · ", text) if on else text,
                               foreground=ui.TONE["ok"][0] if on else ui.MUTED)

    def _confirm_task(self, on: bool) -> bool:
        q = ("매주 월요일 오전 10시에 핸드파일럿 업데이트 확인을 Windows 작업 스케줄러에 등록할까요?\n"
             "(새 버전이 있으면 핸드파일럿을 안 쓸 때 자동 설치 — 설정 탭에서 끄면 설치 창만 띄움)"
             if on else "정기 업데이트 확인 작업을 작업 스케줄러에서 지울까요?")
        if not messagebox.askyesno("핸드파일럿", q):
            return False
        self.task_switch.set_enabled(False)
        self.task_label.config(text="적용 중…", foreground=ui.MUTED)
        self.bg(lambda: self._task_script("-Register" if on else "-Remove"), lambda _: self.refresh_task())
        return True


def snapshot(app: App, out: Path):
    """테스트용: 탭마다 창을 캡처해 저장하고 닫는다."""
    import mss
    from PIL import Image
    out.mkdir(parents=True, exist_ok=True)
    root = app.root

    def shoot(i=0):
        if i >= len(app.TABS):
            root.destroy()
            return
        app.show(app.TABS[i])
        root.update()

        def grab():
            x, y, w, h = root.winfo_rootx(), root.winfo_rooty(), root.winfo_width(), root.winfo_height()
            with mss.MSS() as s:
                raw = s.grab({"left": x, "top": y, "width": w, "height": h})
            Image.frombytes("RGB", raw.size, raw.rgb).save(out / f"settings_tab{i + 1}.png")
            shoot(i + 1)
        root.after(2500 if i == 0 else 600, grab)  # 첫 탭은 점검이 끝날 때까지
    root.attributes("-topmost", True)
    root.after(300, shoot)


def main():
    root = tk.Tk()
    if os.environ.get("HANDPILOT_TK_SCALING"):  # 테스트용: 화면 배율 흉내(2.0 = 150%, 2.67 = 200%)
        root.tk.call("tk", "scaling", float(os.environ["HANDPILOT_TK_SCALING"]))
    app = App(root)
    if "--snapshot" in sys.argv:
        snapshot(app, Path(sys.argv[sys.argv.index("--snapshot") + 1]))
    root.mainloop()


if __name__ == "__main__":
    main()
