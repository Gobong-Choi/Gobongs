"""핸드파일럿 업데이트 설치 창.

새 버전이 있으면 바뀐 내용(CHANGELOG, 사이트 배포판은 사이트의 한 줄 요약)을 보여 주고 [지금 설치] / [나중에] / [관리 창 열기] 를 고르게 한다.
사이트 배포판(설치 파일로 설치해 .git이 없는 폴더)은 설치 안내 사이트의 version.json으로 확인한다(GitHub·Git 필요 없음).
[지금 설치]는 update.ps1을 실행하고 진행 상황을 창에 보여 준다.

실행:
  pythonw tools\\update_prompt.pyw              # 이미 받아 둔 원격 정보로 표시 (update.ps1 -Check -Prompt가 부름)
  pythonw tools\\update_prompt.pyw --fetch      # 원격에서 먼저 확인 (관리 창 [업데이트 확인])
  --wait-idle   핸드파일럿이 작업 중이면 끝날 때까지 기다렸다가 띄운다(정기 확인용 — 조작 중에 창이 끼어들지 않게)
  --quiet       새 버전이 없으면 창을 띄우지 않고 끝낸다
  테스트용: --snapshot <png> (창을 캡처하고 닫음), --auto-install (바로 설치 시작), --skip-plugin (설치본은 건드리지 않음)

일부러 표준 라이브러리만 쓴다 — 설치 중 라이브러리 파일을 바꿀 때 이 창이 파일을 붙잡지 않도록.
모양은 관리 창과 같은 tools/ui_style.py(이것도 tkinter만 씀).
Enter·Space로 설치되지 않게 기본 포커스는 [나중에].
"""

import ctypes
import json
import os
import queue
import re
import subprocess
import sys
import threading
import time
import tkinter as tk
from pathlib import Path
from tkinter import ttk

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(Path(__file__).resolve().parent))
import ui_style as ui  # noqa: E402  (관리 창과 같은 모양 — 이것도 표준 라이브러리만)

PLUGIN_JSON = "handpilot/.claude-plugin/plugin.json"
# 설치 안내 사이트(공개 묶음) — scripts/common.ps1 $SiteUrl과 같은 값. 시험할 때는 HANDPILOT_SITE_URL
SITE_URL = (os.environ.get("HANDPILOT_SITE_URL") or "https://gobong-choi.github.io/Gobongs/handpilot").rstrip("/")
STATE_DIR = Path(os.environ.get("LOCALAPPDATA", "")) / "handpilot"
OWNER_PATH = STATE_DIR / "control-owner.json"
NO_WINDOW = 0x08000000  # CREATE_NO_WINDOW
FONT = ("Malgun Gothic", 10)
FONT_B = ("Malgun Gothic", 11, "bold")

try:
    ctypes.windll.shcore.SetProcessDpiAwareness(2)
except Exception:
    pass


def git(*args) -> tuple[int, str]:
    r = subprocess.run(["git", *args], cwd=ROOT, capture_output=True, text=True, encoding="utf-8",
                       errors="replace", creationflags=NO_WINDOW)
    return r.returncode, r.stdout.strip()


def local_version() -> str:
    try:
        return json.loads((ROOT / PLUGIN_JSON).read_text(encoding="utf-8"))["version"]
    except Exception:
        return "?"


def changelog_since(text: str, current: str, max_lines: int = 60) -> str:
    """원격 CHANGELOG에서 지금 버전보다 위(새) 항목만."""
    lines = text.splitlines()
    start = next((i for i, l in enumerate(lines) if re.match(r"## \[\d", l)), None)  # 머리말의 '## [버전]' 예시는 제외
    if start is None:
        return ""
    out = []
    for l in lines[start:]:
        if l.startswith(f"## [{current}]"):
            break
        out.append(l)
    out = [l for l in out if l.strip() != "---"]
    if len(out) > max_lines:
        out = out[:max_lines] + ["…(이하 생략 — CHANGELOG.md 참고)"]
    return "\n".join(out).strip()


def readable(md: str) -> str:
    """창에 보이기 좋게: '## [0.2.1] - 날짜' → '■ 0.2.1 (날짜)', '### 추가' → '[추가]', 굵게·코드 표시 제거."""
    out = []
    for l in md.splitlines():
        m = re.match(r"## \[(.+?)\]\s*-?\s*(.*)", l)
        if m:
            out.append(f"■ {m.group(1)}" + (f" ({m.group(2).strip()})" if m.group(2).strip() else ""))
            continue
        if l.startswith("### "):
            l = f"[{l[4:].strip()}]"
        out.append(l.replace("**", "").replace("`", ""))
    return "\n".join(out)


def changelog_section(text: str, version: str, max_lines: int = 30) -> str:
    """CHANGELOG에서 그 버전 항목 하나만."""
    out, on = [], False
    for l in text.splitlines():
        if l.startswith("## ["):
            if on:
                break
            on = l.startswith(f"## [{version}]")
        if on and l.strip() != "---":
            out.append(l)
    if len(out) > max_lines:
        out = out[:max_lines] + ["…(이하 생략 — CHANGELOG.md 참고)"]
    return "\n".join(out).strip()


def site_mode() -> bool:
    """설치 파일로 설치한 사이트 배포판인가(.git 없음) — update.ps1 Test-SiteInstall과 같은 기준."""
    return not (ROOT / ".git").exists()


def _vtuple(v: str) -> tuple:
    try:
        return tuple(int(x) for x in str(v).split("."))
    except ValueError:
        return (0,)


def site_info(info: dict) -> dict:
    """사이트의 version.json과 비교(받기만 — 설치는 update.ps1)."""
    import urllib.request
    info["site"] = True
    try:
        with urllib.request.urlopen(f"{SITE_URL}/version.json?nc={time.time_ns()}", timeout=20) as r:
            v = json.loads(r.read().decode("utf-8"))
    except Exception:
        info["error"] = "설치 안내 사이트에 연결하지 못했습니다(인터넷 연결 확인)"
        return info
    info["remote"] = True
    info["latest"] = str(v.get("version") or "?")
    info["behind"] = 1 if _vtuple(info["latest"]) > _vtuple(info["current"]) else 0
    info["changelog"] = str(v.get("notes") or "")
    info["dirty"] = False
    return info


def update_info(fetch: bool) -> dict:
    info = {"current": local_version(), "behind": 0, "remote": False}
    if site_mode():
        return site_info(info)
    if fetch:
        code, _ = git("fetch", "-q")
        if code != 0:
            info["error"] = "원격 저장소에 연결하지 못했습니다(인터넷·GitHub 로그인 확인)"
            return info
    code, up = git("rev-parse", "--abbrev-ref", "@{u}")
    if code != 0:
        info["error"] = "원격 저장소가 연결돼 있지 않습니다(이 PC의 코드만 사용)"
        return info
    info["remote"] = True
    _, n = git("rev-list", "--count", "HEAD..@{u}")
    info["behind"] = int(n or 0)
    if not info["behind"]:
        return info
    try:
        info["latest"] = json.loads(git("show", f"@{{u}}:{PLUGIN_JSON}")[1])["version"]
    except Exception:
        info["latest"] = "?"
    info["changelog"] = changelog_since(git("show", "@{u}:CHANGELOG.md")[1], info["current"])
    info["commits"] = git("log", "--format=%s", "-15", "HEAD..@{u}")[1].splitlines()
    info["dirty"] = bool(git("status", "--porcelain", "--untracked-files=no")[1])
    return info


def handpilot_busy() -> bool:
    """어느 채팅창이 핸드파일럿을 쓰는 중인지 — 조작권 파일을 읽기만 한다(잠금을 건드리지 않음)."""
    try:
        o = json.loads(OWNER_PATH.read_text(encoding="utf-8"))
    except Exception:
        return False
    return bool(o.get("paused")) or time.time() < float(o.get("last_used", 0)) + float(o.get("hold_sec", 15)) + 5


_mutex = None


def single_instance() -> bool:
    """설치 창은 하나만(정기 확인과 관리 창이 겹쳐도)."""
    global _mutex
    k32 = ctypes.WinDLL("kernel32", use_last_error=True)
    _mutex = k32.CreateMutexW(None, False, "Local\\handpilot-update-prompt")
    return ctypes.get_last_error() != 183  # ERROR_ALREADY_EXISTS


class Prompt:
    def __init__(self, root: tk.Tk, info: dict, args: list[str]):
        self.root, self.info, self.args = root, info, args
        self.q: queue.Queue = queue.Queue()
        root.title("핸드파일럿 업데이트")
        ui.fit_window(root, 680, 560, 520, 400)  # 화면 배율에 맞춤(배율 큰 PC에서 버튼 잘림 방지)
        ui.apply(root)
        f = ttk.Frame(root, padding=16)
        f.pack(fill="both", expand=True)
        cur = info["current"]
        if info.get("error"):
            head, sub = "업데이트를 확인하지 못했습니다", info["error"]
        elif not info["behind"]:
            head, sub = f"최신 버전입니다 ({cur})", "받을 새 변경이 없습니다."
        else:
            head = f"새 버전이 있습니다: {cur} → {info['latest']}"
            sub = ("설치하면 설치 안내 사이트에서 새 버전을 받아 라이브러리 → 플러그인 설치본까지 맞춥니다(1분 안팎)." if info.get("site") else
                   f"변경 {info['behind']}개. 설치하면 코드 받기 → 라이브러리 → 플러그인 설치본 순으로 진행합니다(1분 안팎).")
        self.head = ttk.Label(f, text=head, font=FONT_B)
        self.head.pack(anchor="w")
        self.sub = ttk.Label(f, text=sub, foreground=ui.MUTED, wraplength=630)
        self.sub.pack(anchor="w", pady=(2, 10))

        # 아래쪽(버튼 줄 → 안내 → 체크)을 먼저 고정하고, 바뀐 내용 칸은 남는 공간만 쓴다(넘치면 스크롤).
        # 창이 작거나 배율이 커도 [지금 설치]가 잘리지 않게.
        self.restart = tk.BooleanVar(value=False)
        bar = ttk.Frame(f)
        bar.pack(side="bottom", fill="x", pady=(10, 0))
        self.warn = ttk.Label(f, text="", foreground="#b45309", wraplength=630)
        self.warn.pack(side="bottom", anchor="w", pady=(4, 0))
        if info["behind"]:
            self.restart_chk = ttk.Checkbutton(f, variable=self.restart,
                                               text="실행 중인 채팅창의 핸드파일럿도 바로 새 코드로 교체\n"
                                                    "(안 고르면 각 채팅창에서 10분 안 쓸 때 자동 교체)")
            self.restart_chk.pack(side="bottom", anchor="w", pady=(10, 0))
            if info.get("dirty"):
                self.warn.config(text="이 PC에서 고친 파일이 있어 설치가 멈춥니다. 개발 중이 아니라면 PC 전용 설정은 "
                                      "config.local.json으로 옮긴 뒤 다시 시도하세요(관리 창 → 상태 → git).")
            elif handpilot_busy():
                self.warn.config(text="지금 핸드파일럿이 작업 중입니다. 설치는 작업이 끝난 뒤 하는 것이 안전합니다.")

        card = ui.card(f, padding=10)
        card.pack(fill="both", expand=True)
        box = tk.Frame(card, background=ui.CARD)
        box.pack(fill="both", expand=True)
        self.text = tk.Text(box, wrap="word", font=ui.FONT_SMALL, height=6, relief="flat", borderwidth=0,
                            background=ui.CARD, foreground=ui.TEXT)
        ui.autohide_scrollbar(box, self.text)
        body = readable(info.get("changelog") or "") or "\n".join(f"· {c}" for c in info.get("commits", []))
        if not info["behind"] and not info.get("error"):
            try:
                now = readable(changelog_section((ROOT / "CHANGELOG.md").read_text(encoding="utf-8"), cur))
            except OSError:
                now = ""
            body = ("이미 최신 버전이라 설치할 것이 없습니다.\n"
                    "새 버전이 올라오면 이 창에 [지금 설치] 버튼이 나타납니다"
                    "(정기 확인을 켜 두면 매주 월요일 오전 10시에 자동으로 확인).")
            if now:
                body += f"\n\n지금 버전({cur})에서 바뀐 내용:\n\n{now}"
        self.text.insert("end", body or "")
        self.text.configure(state="disabled")

        def rewrap(e):  # 창 폭에 맞춰 안내 문구 줄바꿈
            for w in (self.sub, self.warn):
                w.configure(wraplength=max(240, e.width - 40))
        f.bind("<Configure>", rewrap, add="+")
        self.install_btn = ttk.Button(bar, text="지금 설치", style="Accent.TButton", command=self.install)
        later = ttk.Button(bar, text="나중에" if info["behind"] else "닫기", command=root.destroy)
        if info["behind"]:
            self.install_btn.pack(side="left")
            if info.get("dirty"):
                self.install_btn.state(["disabled"])
        later.pack(side="left", padx=6)
        ttk.Button(bar, text="관리 창 열기", command=self.open_settings).pack(side="right")
        self.later = later
        later.focus_set()  # Enter·Space가 실수로 설치를 누르지 않게

    def open_settings(self):
        subprocess.Popen([sys.executable, str(ROOT / "tools" / "settings.pyw")], cwd=ROOT)

    def _set_text(self, s: str, append: bool = False):
        self.text.configure(state="normal")
        if not append:
            self.text.delete("1.0", "end")
        self.text.insert("end", s)
        self.text.see("end")
        self.text.configure(state="disabled")

    def install(self):
        self.install_btn.state(["disabled"])
        self.later.state(["disabled"])
        self.head.config(text=f"설치 중… {self.info['current']} → {self.info['latest']}")
        self.sub.config(text="창을 닫지 마세요. 끝나면 결과를 알려 드립니다.")
        self.warn.config(text="")
        self._set_text("")
        flags = (" -RestartServers" if self.restart.get() else "") + (" -SkipPlugin" if "--skip-plugin" in self.args else "")
        cmd = f"[Console]::OutputEncoding=[Text.Encoding]::UTF8; & '{ROOT / 'update.ps1'}'{flags}"

        def work():
            p = subprocess.Popen(["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", cmd],
                                 cwd=ROOT, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True,
                                 encoding="utf-8", errors="replace", creationflags=NO_WINDOW)
            for line in p.stdout:
                self.q.put(("line", line))
            self.q.put(("done", p.wait()))
        threading.Thread(target=work, daemon=True).start()
        self.root.after(100, self._pump)

    def _pump(self):
        try:
            while True:
                kind, val = self.q.get_nowait()
                if kind == "line":
                    if val.strip():
                        self._set_text(val, append=True)
                else:
                    self._finished(val)
                    return
        except queue.Empty:
            pass
        self.root.after(100, self._pump)

    def _finished(self, code: int):
        new = local_version()
        self.later.config(text="닫기")
        self.later.state(["!disabled"])
        if code == 0:
            self.head.config(text=f"설치 완료: {self.info['current']} → {new}")
            self.sub.config(text=("실행 중인 채팅창도 다음 호출부터 새 코드로 켜집니다. " if self.restart.get() else
                                  "실행 중인 채팅창은 10분 안 쓰면 새 코드로 바뀝니다. ")
                            + "새 도구·사용설명서는 새 채팅창부터 보입니다.")
        else:
            self.head.config(text="설치가 끝나지 못했습니다")
            self.sub.config(text="아래 기록의 마지막 줄을 확인하세요. 관리 창 → 상태에서 점검할 수 있습니다.")
        print(f"RESULT code={code} version={new}", flush=True)
        if "--auto-install" in self.args:
            if "--snapshot" in self.args:  # 테스트: 설치가 끝난 화면을 찍음
                snapshot(self.root, Path(self.args[self.args.index("--snapshot") + 1]), 500)
            else:
                self.root.after(1500, self.root.destroy)


def snapshot(root: tk.Tk, out: Path, delay: int = 800):
    def grab():
        import mss  # 테스트에서만
        from PIL import Image
        root.update()
        x, y, w, h = root.winfo_rootx(), root.winfo_rooty(), root.winfo_width(), root.winfo_height()
        with mss.MSS() as s:
            raw = s.grab({"left": x, "top": y, "width": w, "height": h})
        out.parent.mkdir(parents=True, exist_ok=True)
        Image.frombytes("RGB", raw.size, raw.rgb).save(out)
        root.destroy()
    root.attributes("-topmost", True)
    root.after(delay, grab)


def main():
    args = sys.argv[1:]
    if not single_instance():
        return  # 이미 떠 있음
    if "--wait-idle" in args:
        deadline = time.time() + 6 * 3600
        while handpilot_busy() and time.time() < deadline:
            time.sleep(20)
    info = update_info(fetch="--fetch" in args)
    print(json.dumps({k: info.get(k) for k in ("current", "latest", "behind", "error", "dirty")}, ensure_ascii=False),
          flush=True)
    if "--quiet" in args and not info["behind"]:
        return
    root = tk.Tk()
    if os.environ.get("HANDPILOT_TK_SCALING"):  # 테스트용: 화면 배율 흉내(2.0 = 150%, 2.67 = 200%)
        root.tk.call("tk", "scaling", float(os.environ["HANDPILOT_TK_SCALING"]))
    app = Prompt(root, info, args)
    if "--auto-install" in args and info["behind"]:
        root.after(300, app.install)
    elif "--snapshot" in args:
        snapshot(root, Path(args[args.index("--snapshot") + 1]))
    root.mainloop()


if __name__ == "__main__":
    main()
