"""대기 측정 요약 — 핸드파일럿 로그의 '고정 대기 기록'(숫자만)을 읽어, 대기 방식을 바꿨다면 어땠을지 계산한다.

  .venv/Scripts/python.exe tools/wait_report.py                 # 최근 30일 요약
  .venv/Scripts/python.exe tools/wait_report.py --days 7
  .venv/Scripts/python.exe tools/wait_report.py --export 파일.json  # 숫자 요약만 저장(채팅창 이름·시각·좌표 없음)

기록은 actions.py가 고정 대기 wait(초) 동안 남긴다(대기·결과는 그대로, 설정 observe.wait_watch).
각 기록: 요청 초(req), 변화 구간 목록 all(자동 무시 없이)·clean(계속 바뀌는 칸 자동 무시 적용) = [시작초, 끝초, 최대 칸 수].

가정한 규칙 (대기 시작 기준):
  - 지금 방식(until_stable): 0.4초 조용하면 끝, 0.7초 안에 변화가 없으면 끝, 자동 무시 적용 (현재 코드)
  - 제안 N초: 자동 무시 없이, 화면이 바뀌기 시작할 때까지는 최대 시간까지 기다리고, 바뀐 뒤 N초 조용하면 끝
'일찍 끝남(의심)': 그 규칙이 끝냈을 시각 뒤에 화면이 다시 바뀐 경우(로딩 2단계 등). 알림 창·광고처럼 기다리던 것과
무관한 변화도 섞일 수 있어 최대치로 본다. 커서 깜빡임 같은 아주 작은 변화(TINY칸 이하)는 무시한다.
"""

import argparse
import json
import os
import statistics
import sys
import time
from collections import defaultdict
from pathlib import Path

LOG_DIR = Path(os.environ.get("LOCALAPPDATA", "")) / "handpilot" / "logs"
TINY = 2          # 이 칸 수 이하 변화(커서 깜빡임)는 변화로 보지 않음 (칸 = 원본 16px)
SETTLE = 0.1      # 현재 코드: 첫 비교 전 대기
RULES = {
    "지금 방식(0.4초)": dict(q=0.4, src="clean", need_change=False, no_change=0.7),
    "제안 1초": dict(q=1.0, src="all", need_change=True),
    "제안 2초": dict(q=2.0, src="all", need_change=True),
}


def load_records(days: float = 30, log_dir: Path = LOG_DIR) -> list[dict]:
    cutoff = time.time() - days * 86400
    out = []
    for f in sorted(log_dir.glob("handpilot-*.log")) if log_dir.exists() else []:
        for line in f.read_text(encoding="utf-8", errors="replace").splitlines():
            if '"watch"' not in line:
                continue
            try:
                r = json.loads(line)
            except ValueError:
                continue
            if r.get("ts", 0) >= cutoff and isinstance(r.get("watch"), dict):
                out.append(r["watch"])
    return out


def _real(bursts: list) -> list:
    return [b for b in bursts if b[2] > TINY]


def rule_end(rec: dict, q: float, src: str, need_change: bool, no_change: float = 0.7) -> float:
    """그 규칙이었다면 대기가 끝났을 시각(초)."""
    req = rec["req"]
    bursts = _real(rec.get(src) or [])
    if not need_change:
        limit = SETTLE + no_change
        if not bursts or bursts[0][0] > limit:
            return min(req, limit)
    if not bursts:
        return req
    for i, b in enumerate(bursts):
        cand = b[1] + q
        nxt = bursts[i + 1][0] if i + 1 < len(bursts) else None
        if nxt is None or nxt > cand:
            return min(req, cand)
    return req


def premature(rec: dict, end: float) -> bool:
    """끝냈을 시각 뒤에 화면이 다시(자동 무시 없이) 바뀌었나."""
    return end < rec["req"] and any(b[0] > end + 0.05 for b in _real(rec.get("all") or []))


def _q(v: list, p: float):
    v = sorted(v)
    return round(v[min(len(v) - 1, int(len(v) * p))], 1) if v else None


def summarize(recs: list[dict]) -> dict:
    recs = [r for r in recs if not r.get("paused") and r.get("req")]
    s = {"기록 수": len(recs), "요청 대기 합(초)": round(sum(r["req"] for r in recs), 1)}
    if not recs:
        return s
    changed = [r for r in recs if _real(r.get("all") or [])]
    s["대기 중 화면 변화 없음"] = len(recs) - len(changed)
    s["끝까지 바뀌는 중(대기 부족·계속 움직이는 화면)"] = sum(1 for r in recs if r.get("busy_end"))
    s["처음 바뀐 시각(초) 중앙값/80%/95%"] = [_q([_real(r["all"])[0][0] for r in changed], p) for p in (.5, .8, .95)]
    s["마지막으로 바뀐 시각(초) 중앙값/80%/95%"] = [_q([_real(r["all"])[-1][1] for r in changed], p) for p in (.5, .8, .95)]
    rules = {}
    for name, kw in RULES.items():
        ends = [rule_end(r, **kw) for r in recs]
        bad = [premature(r, e) for r, e in zip(recs, ends)]
        rules[name] = {
            "대기 합(초)": round(sum(ends), 1),
            "절약(초)": round(sum(r["req"] - e for r, e in zip(recs, ends)), 1),
            "일찍 끝남 의심(회)": sum(bad),
            "일찍 끝남 의심(%)": round(100 * sum(bad) / len(recs), 1),
        }
    s["규칙별"] = rules
    by = defaultdict(list)
    for r in recs:
        by[f"{r.get('after') or '?'} 뒤"].append(r)
    s["앞 동작별"] = {k: {"기록 수": len(v), "요청 합(초)": round(sum(x["req"] for x in v), 1),
                         "제안 1초 절약(초)": round(sum(x["req"] - rule_end(x, **RULES["제안 1초"]) for x in v), 1)}
                     for k, v in sorted(by.items(), key=lambda kv: -len(kv[1]))}
    return s


def summary_text(days: float = 30, log_dir: Path = LOG_DIR) -> str:
    s = summarize(load_records(days, log_dir))
    lines = [f"대기 측정 요약 (최근 {days:g}일, 이 PC)", ""]
    if not s["기록 수"]:
        lines.append("아직 기록이 없습니다. 핸드파일럿으로 작업하다 Claude가 고정 대기(wait)를 쓰면 쌓입니다.")
        return "\n".join(lines)
    for k, v in s.items():
        if isinstance(v, dict):
            lines.append(f"\n[{k}]")
            for kk, vv in v.items():
                lines.append(f"  {kk}: " + (", ".join(f"{a} {b}" for a, b in vv.items()) if isinstance(vv, dict) else str(vv)))
        else:
            lines.append(f"{k}: {v}")
    lines += ["", "· '일찍 끝남 의심'은 끝냈을 시각 뒤에 화면이 다시 바뀐 경우(무관한 변화도 섞일 수 있어 최대치).",
              "· 기록은 시각·칸 수만 남고 화면 내용·채팅창 이름은 이 요약에 들어가지 않습니다."]
    return "\n".join(lines)


def export(path: Path, days: float = 30, log_dir: Path = LOG_DIR) -> dict:
    """숫자 요약만 저장 — 채팅창 이름·시각·좌표 없음."""
    data = {"kind": "handpilot-wait-summary", "days": days, "made": time.strftime("%Y-%m-%d"),
            "summary": summarize(load_records(days, log_dir))}
    Path(path).write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    return data


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--days", type=float, default=30)
    ap.add_argument("--export")
    a = ap.parse_args()
    if a.export:
        export(Path(a.export), a.days)
        print(f"저장: {a.export}")
    print(summary_text(a.days))


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8")
    main()
