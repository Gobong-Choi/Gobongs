﻿# 핸드파일럿 업데이트 (최신 코드 받기 → 라이브러리 → 경로 → 플러그인 → 예전 서버 확인)
#
#   powershell -ExecutionPolicy Bypass -File update.ps1                  # 업데이트
#   powershell -ExecutionPolicy Bypass -File update.ps1 -Check           # 새 버전이 있는지만 확인
#   powershell -ExecutionPolicy Bypass -File update.ps1 -Check -Notify   # 확인 + 새 버전이 있으면 Windows 알림
#   powershell -ExecutionPolicy Bypass -File update.ps1 -Check -Prompt   # 정기 확인용: 새 버전이 있으면 자동 설치(-Auto를 따로 띄움)
#                                                                        #   설정 auto_update=false면 대신 설치 창([지금 설치]/[나중에])
#   powershell -ExecutionPolicy Bypass -File update.ps1 -Auto            # 자동 설치: 이 폴더의 핸드파일럿 서버가 하나도 안 돌 때까지
#                                                                        #   기다렸다가(최대 12시간) 설치하고 Windows 알림. 결과는 %LOCALAPPDATA%\handpilot\auto-update.log
#   powershell -ExecutionPolicy Bypass -File update.ps1 -RestartServers  # 예전 코드로 도는 서버도 바로 종료
#   -SkipPlugin : 플러그인 설치본·바로가기는 건드리지 않음 (테스트용 복사본에서)
#   -Resume -FromVersion <버전> : (내부용) 코드를 받은 뒤 업데이트 스크립트가 바뀌었으면 새 판이 이어서 실행할 때
#
# 받는 곳: 설치 파일로 설치한 PC(.git 없음)는 설치 안내 사이트의 공개 묶음(zip, 확인값 검사 — GitHub·Git 필요 없음, 0.4.0~),
#          GitHub에서 clone한 PC는 지금처럼 git(원격이 없으면 이 폴더의 코드로 설치본만 맞춤).
# '새 버전' = 사이트 version.json(또는 원격 plugin.json)의 버전이 이 PC보다 높을 때(릴리스). 버전이 같은 커밋(문서 등)은 정기 확인·자동 설치 대상이 아닙니다.
# 종료된 서버는 각 채팅창에서 핸드파일럿을 다음에 부를 때 최신 코드로 자동 재시작됩니다.

param([switch]$Check, [switch]$Notify, [switch]$Prompt, [switch]$Auto, [switch]$RestartServers, [switch]$SkipPlugin,
      [switch]$Resume, [string]$FromVersion)

. (Join-Path $PSScriptRoot "scripts\common.ps1")
$root = Get-HandpilotRoot
if ($Resume -and $env:HANDPILOT_OUT_CP) {
    # 이어서 실행: 부모와 같은 출력 인코딩으로(설치 창·시험이 UTF-8로 읽음)
    try { [Console]::OutputEncoding = [Text.Encoding]::GetEncoding([int]$env:HANDPILOT_OUT_CP) } catch {}
}

trap {
    # 자동 설치는 지켜보는 사람이 없으므로 실패를 Windows 알림으로 알린다
    if ($Auto) { Show-Toast "핸드파일럿 자동 업데이트 실패" "$($_.Exception.Message) — 관리 창 → [지금 설치…]로 다시 해 보세요." }
    break
}

if ($Auto -and $Resume) {
    # 이어서 실행: 부모가 쓰던 기록 파일에 이어 씀(기다리기·잠금은 부모가 이미 함)
    try { Start-Transcript -Path (Join-Path $env:LOCALAPPDATA "handpilot\auto-update.log") -Append | Out-Null } catch {}
} elseif ($Auto) {
    # 무인 실행: 결과를 파일로 남기고, 같은 폴더의 자동 설치는 하나만 기다리게
    $autoLog = Join-Path $env:LOCALAPPDATA "handpilot\auto-update.log"
    New-Item -ItemType Directory -Force (Split-Path $autoLog) | Out-Null
    try { Start-Transcript -Path $autoLog -Force | Out-Null } catch {}
    $mutexName = "Local\handpilot-auto-update-" + (Get-RootKey $root)  # 인수 목록 안에서 + 를 쓰면 쉼표가 먼저 묶임
    $autoMutex = New-Object Threading.Mutex($false, $mutexName)
    $owned = $false
    try { $owned = $autoMutex.WaitOne(0) } catch [Threading.AbandonedMutexException] { $owned = $true }
    if (-not $owned) { Write-Note "이미 자동 설치가 기다리는 중 — 끝"; return }

    # 핸드파일럿을 쓰는 채팅창이 없을 때까지 기다림: 서버는 마지막 사용 후 약 10분 뒤 저절로 꺼지므로
    # '서버가 하나도 없음' = 적어도 10분 동안 아무도 안 씀 → 작업 중에 코드·라이브러리가 바뀌지 않음
    $poll = if ($env:HANDPILOT_AUTO_POLL_SEC) { [double]$env:HANDPILOT_AUTO_POLL_SEC } else { 60 }
    $maxWait = if ($env:HANDPILOT_AUTO_MAX_WAIT_SEC) { [double]$env:HANDPILOT_AUTO_MAX_WAIT_SEC } else { 12 * 3600 }
    $deadline = (Get-Date).AddSeconds($maxWait)
    $n = @(Get-HandpilotServers $root).Count
    if ($n -gt 0) { Write-Note "핸드파일럿 서버 $n 개가 돌고 있어 기다림 (다 쓰고 약 10분 뒤 꺼지면 설치)" }
    while (@(Get-HandpilotServers $root).Count -gt 0) {
        if ((Get-Date) -gt $deadline) {
            Write-Warn2 "최대 대기 시간이 지나 이번엔 설치하지 않음"
            Show-Toast "핸드파일럿 새 버전 설치를 미뤘어요" "핸드파일럿이 계속 쓰이고 있었어요. 다음 정기 확인 때 다시 시도해요(지금 하려면 관리 창 → [지금 설치…])."
            return
        }
        Start-Sleep -Seconds $poll
    }
    Write-Ok "핸드파일럿을 쓰는 채팅창 없음 — 설치 시작"
}

$before = if ($FromVersion) { $FromVersion } else { Get-PluginVersion $root }
Write-Host "핸드파일럿 업데이트 — 현재 버전 $before" -ForegroundColor White

# 1) 코드 받기 — 사이트 배포판은 설치 안내 사이트의 묶음에서, git으로 설치한 PC는 GitHub에서
Write-Step "1/5 최신 코드 확인"
$siteMode = Test-SiteInstall $root
if ($Resume) {
    Write-Ok "코드는 이미 받음 — 바뀐 업데이트 스크립트로 이어서 실행"
} else {
    Push-Location $root
    try {
        $known = $true
        if ($siteMode) {
            # 사이트 배포판: 사이트의 version.json과 비교(GitHub·Git 필요 없음)
            $site = Get-SiteVersion
            $upVer = [string]$site.version
            $release = Test-NewerVersion $upVer $before
            $behind = [int]$release
            $latest = "v$upVer" + $(if ($site.notes) { " — $($site.notes)" } else { "" })
            Set-LastCheck $upVer
        } elseif (-not [bool](git remote 2>$null)) {
            Write-Note "원격 저장소가 없습니다 — 이 폴더의 코드를 그대로 씁니다"
            if ($Check -or $Auto) { Clear-UpdateMarker; return }
            $known = $false
        } else {
            git fetch -q
            $behind = [int](git rev-list --count "HEAD..@{u}" 2>$null)
            $upVer = if ($behind -gt 0) { Get-UpstreamVersion } else { $before }
            $release = $behind -gt 0 -and (-not $upVer -or $upVer -ne $before)  # 버전을 못 읽으면 예전처럼 새 버전으로 봄
            $latest = if ($behind -gt 0) { (git log -1 --format=%s "@{u}") } else { "" }
        }
        if ($known) {
            # 지난 업데이트가 플러그인 단계에서 멈췄으면(코드는 새 판, 설치본은 옛 판) 받을 게 없어도 설치본을 맞춘다
            $installed = if ($SkipPlugin) { $null } else { Get-InstalledPluginVersion }
            $mine = $false
            try { $mine = (Resolve-Path (Get-MarketplacePath) -ErrorAction Stop).Path -eq $root } catch {}
            $repair = (-not $release) -and $mine -and $installed -and ($installed -ne $before)
            if ($release) { Write-Note $(if ($siteMode) { "설치 안내 사이트에 새 버전 $upVer 있음" } else { "새 커밋 $behind 개 있음 — 새 버전 $upVer" }) }
            elseif ($behind -gt 0) { Write-Note "새 커밋 $behind 개 있음 — 버전은 그대로($before, 문서 등)" }
            else { Write-Ok $(if ($siteMode) { "이미 최신 ($before, 설치 안내 사이트 기준)" } else { "이미 최신 코드" }); Clear-UpdateMarker }
            if ($repair) { Write-Note "설치본($installed)이 이 폴더($before)와 달라 맞춤 필요(지난 업데이트가 중간에 멈춘 경우)" }
            if ($Check) {
                $autoOn = [bool](Get-HandpilotSetting $root "auto_update" $true)
                if ($release -or ($repair -and $Prompt -and $autoOn)) {
                    if (-not $siteMode) { git log --oneline "HEAD..@{u}" | Select-Object -First 10 }
                    Set-UpdateMarker $behind $latest $upVer -Auto:($Prompt -and $autoOn)
                    if ($Notify) { Show-Toast "핸드파일럿 새 버전" "$latest`n시작 메뉴 '핸드파일럿 관리' → [지금 설치]" }
                    if ($Prompt -and $autoOn) {
                        # 자동 설치는 따로 띄운다: 정기 확인 작업은 5분 제한이라 오래 기다릴 수 없음
                        $aa = @("-NoProfile", "-WindowStyle", "Hidden", "-ExecutionPolicy", "Bypass", "-File", "`"$(Join-Path $root 'update.ps1')`"", "-Auto")
                        if ($SkipPlugin) { $aa += "-SkipPlugin" }
                        Start-Process powershell.exe -ArgumentList $aa -WorkingDirectory $root -WindowStyle Hidden
                        Write-Ok "자동 설치를 시작함 (핸드파일럿을 쓰는 중이면 다 쓴 뒤 — 끝나면 Windows 알림)"
                    } elseif ($Prompt) {
                        # 설치 창: 핸드파일럿이 작업 중이면 끝날 때까지 기다렸다가 뜬다(조작 중에 끼어들지 않게)
                        $pyw = Join-Path $root ".venv\Scripts\pythonw.exe"
                        Start-Process $pyw -ArgumentList @("`"$(Join-Path $root 'tools\update_prompt.pyw')`"", "--wait-idle") -WorkingDirectory $root
                        Write-Ok "설치 창을 띄움 (핸드파일럿 작업 중이면 끝난 뒤)"
                    }
                } else {
                    Clear-UpdateMarker
                }
                return
            }
            if ($Auto -and -not $release -and -not $repair) { Write-Ok "설치할 새 버전 없음 — 자동 설치 끝"; return }
            $changed = $false
            if ($siteMode) {
                if ($release) {
                    $oldHash = Get-UpdateScriptHash $root
                    Install-Bundle $root $site
                    Write-Ok "코드 받기 완료"
                    Clear-UpdateMarker  # 받았으니 '새 버전 있음' 표시 지움
                    $changed = (Get-UpdateScriptHash $root) -ne $oldHash
                }
            } elseif ($behind -gt 0) {
                if (git status --porcelain --untracked-files=no) {
                    throw "이 PC에서 고친 파일이 있어 업데이트를 멈춥니다(git status로 확인). 이 PC 전용 설정은 config.local.json에 두세요."
                }
                $oldHead = (git rev-parse HEAD)
                git pull -q --ff-only
                if ($LASTEXITCODE -ne 0) { throw "git pull 실패" }
                Write-Ok "코드 받기 완료"
                Clear-UpdateMarker  # 받았으니 '새 버전 있음' 표시 지움
                $changed = @(git diff --name-only $oldHead HEAD -- update.ps1 scripts/common.ps1).Count -gt 0
            }
            if ($changed) {
                # 이 스크립트는 시작할 때 읽은 판으로 끝까지 돈다 → 업데이트 스크립트가 바뀌었으면 나머지는 새 판이 이어서 한다
                # (옛 판의 버그로 뒤 단계가 실패하지 않게 — 0.3.4까지는 Claude 위치 변경으로 플러그인 단계가 실패했음)
                Write-Note "업데이트 스크립트가 바뀌어 새 판으로 이어서 실행"
                $a = @("-NoProfile", "-ExecutionPolicy", "Bypass", "-File", (Join-Path $root "update.ps1"), "-Resume", "-FromVersion", $before)
                if ($Auto) { $a += "-Auto" }
                if ($RestartServers) { $a += "-RestartServers" }
                if ($SkipPlugin) { $a += "-SkipPlugin" }
                try { $env:HANDPILOT_OUT_CP = [string][Console]::OutputEncoding.CodePage } catch {}
                if ($Auto) { try { Stop-Transcript | Out-Null } catch {} }
                & powershell.exe @a
                exit $LASTEXITCODE
            }
        }
    } finally { Pop-Location }
}

# 2) 라이브러리
Write-Step "2/5 라이브러리"
Sync-Requirements $root

# 3) 경로
Write-Step "3/5 경로 설정"
Write-McpJson $root | Out-Null

# 4) 플러그인 설치본
Write-Step "4/5 플러그인 설치본"
if ($SkipPlugin) {
    Write-Note "건너뜀 (-SkipPlugin)"
} else {
    Sync-Plugin $root
    $lnk = Join-Path ([Environment]::GetFolderPath("Programs")) "핸드파일럿 관리.lnk"
    if (Test-Path $lnk) { New-SettingsShortcut $root }  # 있으면 경로 갱신(사용자가 지웠으면 다시 만들지 않음)
}

# 5) 예전 코드로 도는 서버
Write-Step "5/5 실행 중인 서버"
$stale = @(Get-StaleServers $root)
if ($stale.Count -eq 0) {
    Write-Ok "예전 코드로 도는 서버 없음"
} elseif ($RestartServers) {
    foreach ($s in $stale) {
        Get-CimInstance Win32_Process | Where-Object { $_.ParentProcessId -eq $s.ProcessId } |
            ForEach-Object { Stop-Process -Id $_.ProcessId -Force -Confirm:$false }
        Stop-Process -Id $s.ProcessId -Force -Confirm:$false
    }
    Write-Ok "예전 서버 $($stale.Count)개 종료 — 다음 호출 때 최신으로 자동 재시작"
} else {
    Write-Warn2 "예전 코드로 도는 서버 $($stale.Count)개 — 10분 안 쓰면 자동으로 바뀝니다(바로 바꾸려면 -RestartServers)"
}

Write-Step "점검 (doctor)"
& (Join-Path $root "doctor.ps1")

$after = Get-PluginVersion $root
Write-Host "`n업데이트 완료: $before → $after" -ForegroundColor Green
if ($before -ne $after) { Write-Host "새 옵션·사용설명서는 새 채팅창(또는 Claude 앱 재시작)부터 적용됩니다." }
if ($Auto) {
    if ($before -ne $after) { Show-Toast "핸드파일럿 자동 업데이트: $before → $after" "새 채팅창부터 적용돼요." }
    else { Show-Toast "핸드파일럿 설치본을 맞췄어요 ($after)" "지난 업데이트가 중간에 멈춰 있던 것을 마저 했어요. 새 채팅창부터 적용돼요." }
    try { Stop-Transcript | Out-Null } catch {}
}
