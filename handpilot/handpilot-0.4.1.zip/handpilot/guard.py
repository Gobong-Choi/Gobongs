"""핸드파일럿 정지 장치.

Claude가 작업하는 동안 사람이 마우스/키보드를 만지면 즉시 일시정지하고, 화면 구석의
작동 중 표시창에서 [재개]를 직접 클릭해야 다시 움직인다. Claude는 정지를 풀 수 없다.

- 사람 입력과 핸드파일럿 입력은 '보낸 쪽 표시'(dwExtraInfo = SELF_TAG)로 구분한다. 핸드파일럿이 보내는 클릭·휠·키에는
  표시를 붙이고(_install_self_tag), 표시가 있는 입력만 무시한다. 다른 프로그램이 만든 입력(injected)도 사람으로 본다 —
  PowerToys 마우스 공유처럼 다른 PC의 마우스·키보드를 이 PC에서 재현하는 경우에도 멈추고 [재개]·[종료]도 눌리게(0.2.5).
  (pyautogui의 SetCursorPos 이동은 저수준 훅에 아예 잡히지 않음 — 2026-10-07 실험)
- 감시는 Claude가 동작 중이거나 마지막 동작 후 active_window_sec 동안만 한다. 단 Esc는 조작권을 쥔 동안(답변 중) 언제나 정지(esc_stop).
- 다른 프로그램 입력을 사람으로 볼지는 stop_on_other_input(관리 창에서 켜기/끄기, 입력이 올 때마다 설정을 읽음).
- 핸드파일럿을 쓴 답변이 끝나면 Claude 창을 맨 앞으로(focus_claude_on_done, lease가 Stop 훅을 받으면 on_turn_done 호출).
- 표시창은 화면 캡처에서 제외되어 스크린샷에 찍히지 않는다.
- 메모리 절약: pynput·tkinter는 start()가 불릴 때(첫 도구 호출 때) 불러온다.
- 조작권(lease.py)과 함께 동작: 일시정지 중엔 조작권을 계속 쥐고, [종료]를 누르면 정지 해제 + 조작권 반납.
"""

import ctypes
import json
import math
import sys
import threading
import time
from contextlib import contextmanager
from ctypes import wintypes
from pathlib import Path

import hplog

CONFIG_PATH = Path(__file__).with_name("config.json")
LOCAL_CONFIG_PATH = Path(__file__).with_name("config.local.json")  # 이 PC 전용 설정(git·업데이트 대상 아님)
DEFAULTS = {
    "active_window_sec": 5.0,      # 마지막 동작 후 사람 입력을 감시하는 시간
    "move_threshold_px": 30,       # 이 거리 이상 움직여야 정지 (책상 진동 무시)
    "overlay_enabled": True,
    "overlay_position": "top-right",  # top-right | top-left | bottom-right | bottom-left
    "overlay_margin_x": 16,
    "overlay_margin_y": 60,
    "idle_exit_min": 10,           # 이 시간(분) 동안 도구를 안 쓰면 서버가 스스로 종료 (0 = 안 함)
    "lock_hold_sec": 15,           # 마지막 동작 후 이 시간(초) 동안 조작권 유지, 그 뒤 자동 반납
    "lock_hold_turn_sec": 90,      # 답변 중(훅 확인)일 때 최대 유지 시간. 답변이 끝나면(Stop 훅) 바로 반납
    "log_enabled": True,           # 자체 로그(%LOCALAPPDATA%\\handpilot\\logs) 기록
    "log_retention_days": 30,      # 이 기간(일)이 지난 로그는 서버가 켜질 때 삭제
    "stop_on_other_input": True,   # 다른 프로그램이 만든 입력(PowerToys 마우스 공유 등)도 사람으로 보고 정지. 마우스 흔들기 같은 자동화 프로그램을 쓰면 끔
    "esc_stop": True,              # 이 채팅창이 핸드파일럿을 쓰는 동안(조작권 보유 중)엔 사람의 Esc로 언제든 즉시 정지. 안 쓸 때의 Esc는 무시
    "focus_claude_on_done": True,  # 핸드파일럿을 쓴 답변이 끝나면(Stop 훅) Claude 앱 창을 맨 앞으로. 사람이 막 입력 중이면 작업 표시줄 깜빡임만
}

user32 = ctypes.windll.user32
user32.GetAncestor.restype = wintypes.HWND
user32.GetWindowLongW.restype = ctypes.c_long
GA_ROOT = 2
GWL_EXSTYLE = -20
WS_EX_TRANSPARENT = 0x20        # 클릭 통과
WS_EX_TOOLWINDOW = 0x80         # 작업표시줄/Alt+Tab에 안 보임
WS_EX_LAYERED = 0x80000
WS_EX_NOACTIVATE = 0x08000000   # 포커스를 빼앗지 않음
WDA_EXCLUDEFROMCAPTURE = 0x11   # 화면 캡처에서 제외 (Windows 10 2004+)
SW_SHOWNOACTIVATE = 4


def _log(msg: str, level: str = "info") -> None:
    hplog.log(level, "guard", msg)


# ---------- Claude 창을 맨 앞으로 (답변이 끝났을 때) ----------
kernel32 = ctypes.windll.kernel32
user32.GetForegroundWindow.restype = wintypes.HWND
_WNDENUMPROC = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)


class _RECT(ctypes.Structure):
    _fields_ = [("left", ctypes.c_long), ("top", ctypes.c_long), ("right", ctypes.c_long), ("bottom", ctypes.c_long)]


class _FLASHWINFO(ctypes.Structure):
    _fields_ = [("cbSize", wintypes.UINT), ("hwnd", wintypes.HWND), ("dwFlags", wintypes.DWORD),
                ("uCount", wintypes.UINT), ("dwTimeout", wintypes.DWORD)]


def _window_exe(hwnd) -> str:
    pid = wintypes.DWORD()
    user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
    h = kernel32.OpenProcess(0x1000, False, pid.value)  # PROCESS_QUERY_LIMITED_INFORMATION
    if not h:
        return ""
    try:
        buf = ctypes.create_unicode_buffer(1024)
        size = wintypes.DWORD(len(buf))
        return buf.value.rsplit("\\", 1)[-1].lower() if kernel32.QueryFullProcessImageNameW(h, 0, buf, ctypes.byref(size)) else ""
    finally:
        kernel32.CloseHandle(h)


def _claude_main_window():
    """Claude 앱(claude.exe)의 보이는 최상위 창 중 가장 큰 것."""
    found = []

    def cb(hwnd, _):
        if (user32.IsWindowVisible(hwnd) and not user32.GetWindow(hwnd, 4)  # GW_OWNER: 딸린 창 제외
                and user32.GetWindowTextLengthW(hwnd) > 0 and _window_exe(hwnd) == "claude.exe"):
            r = _RECT()
            user32.GetWindowRect(hwnd, ctypes.byref(r))
            found.append(((r.right - r.left) * (r.bottom - r.top), hwnd))
        return True
    user32.EnumWindows(_WNDENUMPROC(cb), 0)
    return max(found)[1] if found else None


def _is_front(hwnd) -> bool:
    fg = user32.GetForegroundWindow()
    return bool(fg) and user32.GetAncestor(fg, GA_ROOT) == hwnd


def _bring_to_front(hwnd) -> bool:
    """창을 맨 앞으로. Windows는 다른 프로그램이 창을 앞으로 가져오는 걸 막으므로 입력 연결(AttachThreadInput) → Alt 순서로 시도."""
    if user32.IsIconic(hwnd):
        user32.ShowWindow(hwnd, 9)  # SW_RESTORE
    if _is_front(hwnd):
        return True
    fg = user32.GetForegroundWindow()
    me = kernel32.GetCurrentThreadId()
    other = user32.GetWindowThreadProcessId(fg, None) if fg else 0
    attached = bool(other and other != me and user32.AttachThreadInput(me, other, True))
    try:
        user32.BringWindowToTop(hwnd)
        user32.SetForegroundWindow(hwnd)
    finally:
        if attached:
            user32.AttachThreadInput(me, other, False)
    time.sleep(0.05)
    if _is_front(hwnd):
        return True
    user32.keybd_event(0x12, 0, 0, 0)  # Alt — 핸드파일럿 입력 표시가 붙어 정지 장치는 무시
    user32.SetForegroundWindow(hwnd)
    user32.keybd_event(0x12, 0, 2, 0)
    time.sleep(0.05)
    return _is_front(hwnd)


def _flash(hwnd) -> None:
    """작업 표시줄 버튼 깜빡임(그 창을 볼 때까지)."""
    fi = _FLASHWINFO(ctypes.sizeof(_FLASHWINFO), hwnd, 0x2 | 0xC, 0, 0)  # FLASHW_TRAY | FLASHW_TIMERNOFG
    user32.FlashWindowEx(ctypes.byref(fi))


def _merge(base: dict, extra: dict) -> None:
    for k, v in extra.items():
        if isinstance(v, dict) and isinstance(base.get(k), dict):
            base[k] = dict(base[k])
            _merge(base[k], v)
        else:
            base[k] = v


def load_config() -> dict:
    """기본값 ← config.json(공용) ← config.local.json(이 PC 전용) 순서로 덮어쓴다."""
    cfg = dict(DEFAULTS)
    for path in (CONFIG_PATH, LOCAL_CONFIG_PATH):
        try:
            _merge(cfg, json.loads(path.read_text(encoding="utf-8")))
        except FileNotFoundError:
            pass
        except (OSError, ValueError) as e:
            _log(f"{path.name} 읽기 실패, 이 파일은 무시: {e}", "warn")
    return cfg


class Paused(Exception):
    """사용자가 일시정지한 상태에서 동작을 시도함."""


SELF_TAG = 0x48504C54  # 'HPLT' — 핸드파일럿이 보낸 입력 표시(저수준 훅의 dwExtraInfo)


def _install_self_tag() -> None:
    """이 프로세스에서 pyautogui가 보내는 클릭·휠·키(user32.mouse_event / keybd_event)에 SELF_TAG를 붙인다.
    pyautogui는 호출할 때마다 ctypes.windll.user32.<함수>를 찾으므로 그 두 함수만 바꿔 끼운다(이 서버 프로세스 안에서만)."""
    u = ctypes.windll.user32
    if getattr(u, "_hp_self_tag", False):
        return
    real = ctypes.WinDLL("user32")  # 바꾸지 않은 원래 함수
    tag = ctypes.c_size_t(SELF_TAG)

    def mouse_event(flags, dx, dy, data, extra=0):
        return real.mouse_event(flags, dx, dy, data, tag)

    def keybd_event(vk, scan, flags, extra=0):
        return real.keybd_event(vk, scan, flags, tag)

    u.mouse_event = mouse_event
    u.keybd_event = keybd_event
    u._hp_self_tag = True


def _not_mine(msg, data) -> bool:
    """저수준 훅 필터: 핸드파일럿이 보낸 입력(SELF_TAG)이면 False → 감시 콜백으로 보내지 않는다."""
    return (data.dwExtraInfo or 0) != SELF_TAG


class Guard:
    def __init__(self, cfg: dict):
        self.cfg = cfg
        self._lock = threading.Lock()
        self.paused = False
        self.reason = ""
        self.paused_at = 0.0  # 이번 일시정지가 시작된 시각 (같은 정지인지 구분용)
        self._busy = 0
        self._active_until = 0.0
        self._move_acc = 0.0
        self._last_pos: tuple[int, int] | None = None
        self._last_human_press = (0.0, 0, 0)
        self._overlay: Overlay | None = None
        self.lease = None  # server.py가 ControlLease를 연결한다
        self.ended = False  # 사용자가 [종료]를 눌렀음 → 다음 도구 호출 때 Claude에게 한 번 알린다
        self.ended_at = 0.0  # [종료]를 누른 시각 (time.time)
        self._esc = None  # pynput Key.esc (start()에서)
        self.last_human_input = 0.0  # 사람(표시 없는 입력)이 마지막으로 마우스·키보드를 쓴 시각 (time.monotonic)

    # ---------- 시작 ----------
    def start(self) -> None:
        from pynput import keyboard, mouse

        _install_self_tag()  # 첫 동작 전에 — 핸드파일럿 입력에 표시
        self._esc = keyboard.Key.esc
        mouse.Listener(on_move=self._on_move, on_click=self._on_click,
                       on_scroll=self._on_scroll, win32_event_filter=_not_mine, daemon=True).start()
        keyboard.Listener(on_press=self._on_press, win32_event_filter=_not_mine, daemon=True).start()
        if self.cfg["overlay_enabled"]:
            self._overlay = Overlay(self)
            self._overlay.start()

    # ---------- 상태 ----------
    def watching(self) -> bool:
        return self._busy > 0 or time.monotonic() < self._active_until

    def busy(self) -> bool:
        return self._busy > 0

    def state(self) -> str:
        if self.paused:
            return "paused"
        if self.watching():
            return "working"
        if self.lease is not None and self.lease.held:
            return "holding"
        return "idle"

    def pause(self, reason: str) -> None:
        with self._lock:
            if self.paused:
                return
            self.paused = True
            self.reason = reason
            self.paused_at = time.monotonic()
        _log(f"일시정지: {reason}")

    def _physical_click_on_overlay(self) -> bool:
        """방금 표시창 위를 실제 마우스로 눌렀는지 (Claude의 클릭·화면 속 문구로는 못 누르게)."""
        t, x, y = self._last_human_press
        return time.monotonic() - t <= 1.5 and not (self._overlay and not self._overlay.contains(x, y))

    def _unpause(self) -> None:
        with self._lock:
            self.paused = False
            self.reason = ""
            self._active_until = 0.0   # 재개 직후 마우스를 치워도 다시 멈추지 않게
            self._move_acc = 0.0
            self._last_pos = None

    def resume(self) -> bool:
        """표시창 [재개] 버튼에서만 호출된다. 실제 마우스 클릭일 때만 풀어준다."""
        if not self._physical_click_on_overlay():
            _log("재개 거부: 실제 마우스 클릭이 아님")
            return False
        self._unpause()
        self.ended = False
        if self.lease is not None:
            self.lease.touch()  # 재개 후 이 채팅창이 이어서 할 수 있게 보유 시간을 다시 센다
        _log("재개")
        return True

    def end(self) -> bool:
        """표시창 [종료] 버튼: 정지 해제 + 조작권 즉시 반납 (다른 채팅창이 쓸 수 있게)."""
        if not self._physical_click_on_overlay():
            _log("종료 거부: 실제 마우스 클릭이 아님")
            return False
        self._unpause()
        self.ended = True  # Claude가 모르고 이어서 하지 않도록 다음 호출에서 알린다
        self.ended_at = time.time()
        if self.lease is not None:
            self.lease.release("사용자가 [종료]를 누름")
        _log("종료")
        return True

    def clear_ended(self, before: float) -> None:
        """[종료] 뒤에 사용자가 새 메시지를 보냈으면(UserPromptSubmit 훅) 종료 알림이 필요 없다."""
        with self._lock:
            # 파일 수정 시각은 Windows에서 약 15ms 단위로만 갱신돼 [종료] 직후 쓴 신호가 더 이르게 찍힐 수 있음 → 0.1초 여유
            if self.ended and self.ended_at < before + 0.1:
                self.ended = False
                cleared = True
            else:
                cleared = False
        if cleared:
            _log("종료 알림 정리: [종료] 뒤 사용자가 새로 지시함")

    def take_ended(self) -> bool:
        """[종료] 알림을 한 번만 꺼낸다."""
        with self._lock:
            ended, self.ended = self.ended, False
        return ended

    def check(self) -> None:
        if self.paused:
            raise Paused(self.reason)

    # ---------- 동작 감싸기 ----------
    @contextmanager
    def action(self):
        self.check()
        with self._lock:
            self._busy += 1
            self._move_acc = 0.0
            self._last_pos = None
        try:
            yield
        finally:
            with self._lock:
                self._busy -= 1
                self._active_until = time.monotonic() + self.cfg["active_window_sec"]
                self._last_pos = None
        self.check()  # 동작 도중 정지됐으면 Claude에게 알린다

    def sleep(self, seconds: float) -> None:
        """정지되면 즉시 깨어나는 대기."""
        end = time.monotonic() + seconds
        while time.monotonic() < end:
            self.check()
            time.sleep(min(0.05, max(0.0, end - time.monotonic())))
        self.check()

    # ---------- 입력 감시 (pynput 훅 스레드, 빠르게 끝내야 함) ----------
    # 핸드파일럿 자신의 입력은 _not_mine 필터에서 이미 걸러졌으므로, 여기 오는 입력은 injected여도 사람(마우스 공유 등)으로 본다.
    # 단 stop_on_other_input을 끄면 다른 프로그램 입력(injected)은 예전처럼 무시한다.
    def _ignored(self, injected: bool) -> bool:
        return injected and not self.cfg.get("stop_on_other_input", True)

    def on_turn_done(self) -> None:
        """핸드파일럿을 쓴 답변이 끝남(Stop 훅) → Claude 창을 맨 앞으로(focus_claude_on_done).
        그때 사람이 막(3초 안) 입력하고 있었으면 가져오지 않고 작업 표시줄만 깜빡임 — 다른 프로그램에 치던 글자가 Claude 입력창으로 가지 않게."""
        if not self.cfg.get("focus_claude_on_done", True):
            return
        try:
            hwnd = _claude_main_window()
            if not hwnd:
                return
            if time.monotonic() - self.last_human_input < 3.0:
                _flash(hwnd)
                _log("답변 끝: 사람이 입력 중이라 Claude 창은 작업 표시줄 깜빡임만")
            elif _bring_to_front(hwnd):
                _log("답변 끝: Claude 창을 맨 앞으로")
            else:
                _flash(hwnd)
                _log("답변 끝: Claude 창을 앞으로 가져오지 못해 작업 표시줄 깜빡임", "warn")
        except Exception as e:
            _log(f"Claude 창 앞으로 실패: {e!r}", "warn")

    def _on_move(self, x, y, injected=False):
        if not self._ignored(injected):
            self.last_human_input = time.monotonic()
        if self.paused or not self.watching() or self._ignored(injected):
            self._last_pos = (x, y)
            self._move_acc = 0.0
            return
        if self._last_pos is not None:
            self._move_acc += math.hypot(x - self._last_pos[0], y - self._last_pos[1])
            if self._move_acc >= self.cfg["move_threshold_px"]:
                self.pause("사용자가 마우스를 움직임")
        self._last_pos = (x, y)

    def _on_click(self, x, y, button, pressed, injected=False):
        if not pressed or self._ignored(injected):
            return
        self.last_human_input = time.monotonic()
        self._last_human_press = (time.monotonic(), x, y)
        if not self.paused and self.watching():
            self.pause("사용자가 마우스를 클릭함")

    def _on_scroll(self, x, y, dx, dy, injected=False):
        if not self._ignored(injected):
            self.last_human_input = time.monotonic()
        if not self.paused and self.watching() and not self._ignored(injected):
            self.pause("사용자가 스크롤함")

    def _on_press(self, key, injected=False):
        if self._ignored(injected):
            return
        self.last_human_input = time.monotonic()
        if self.paused:
            return
        esc = self._esc is not None and key == self._esc
        holding = self.lease is not None and self.lease.held  # 이 채팅창이 핸드파일럿을 쓰는 중(답변 중)
        if self.watching() or (esc and holding and self.cfg.get("esc_stop", True)):
            self.pause("사용자가 Esc를 누름" if esc else "사용자가 키를 누름")


class Overlay:
    """작동 중 / 일시정지 표시창. 자체 스레드에서 tkinter를 돌린다."""

    BG_WORK, BG_HOLD, BG_PAUSE, FG = "#1f2937", "#4b5563", "#b45309", "#ffffff"

    def __init__(self, guard: Guard):
        self.guard = guard
        self._rect = (0, 0, 0, 0)
        self._shown = None

    def start(self) -> None:
        threading.Thread(target=self._run, name="handpilot-overlay", daemon=True).start()

    def contains(self, x: int, y: int) -> bool:
        l, t, r, b = self._rect
        return l <= x < r and t <= y < b

    def _run(self) -> None:
        try:
            import tkinter as tk

            root = self.root = tk.Tk()
            root.withdraw()
            root.title("핸드파일럿 표시창")
            root.overrideredirect(True)
            root.attributes("-topmost", True)
            root.attributes("-toolwindow", True)  # tkinter 쪽에도 '도구 창'(작업 표시줄에 안 뜸)을 알려 둠
            font = ("Malgun Gothic", 10, "bold")
            self.frame = tk.Frame(root, bg=self.BG_WORK, padx=10, pady=6)
            self.frame.pack()
            self.label = tk.Label(self.frame, font=font, fg=self.FG, bg=self.BG_WORK)
            self.label.pack(side="left")
            btn = dict(font=font, bg="#ffffff", fg=self.BG_PAUSE, relief="flat", padx=10, cursor="hand2")
            self.button = tk.Button(self.frame, text="재개", command=self._on_resume, **btn)
            self.end_button = tk.Button(self.frame, text="종료", command=self._on_end, **btn)
            root.attributes("-alpha", 0.0)
            root.update_idletasks()
            self.hwnd = 0
            self._own_window(True)
            user32.ShowWindow(self.hwnd, SW_SHOWNOACTIVATE)
            self._tick()
            root.mainloop()
        except Exception as e:  # 표시창이 실패해도 정지 감시는 계속 동작해야 한다
            _log(f"표시창 실행 실패: {e!r}", "error")

    def _own_window(self, click_through: bool) -> None:
        """창 속성을 tkinter 설정 '다음에' 입힌다 — tkinter가 투명도 등을 바꿀 때 우리 속성을 덮어써서
        작업 표시줄에 이름 없는 'tk'(파이썬 깃털)로 뜨던 문제(0.1.3~0.4.0) 방지. tkinter가 창을 다시 만들면 새 창에 다시 적용."""
        hwnd = user32.GetAncestor(self.root.winfo_id(), GA_ROOT)
        if hwnd != self.hwnd:
            self.hwnd = hwnd
            if not user32.SetWindowDisplayAffinity(hwnd, WDA_EXCLUDEFROMCAPTURE):
                _log("표시창 캡처 제외 실패: 스크린샷에 찍힐 수 있음", "warn")
        style = user32.GetWindowLongW(hwnd, GWL_EXSTYLE) | WS_EX_TOOLWINDOW | WS_EX_NOACTIVATE | WS_EX_LAYERED
        style = style | WS_EX_TRANSPARENT if click_through else style & ~WS_EX_TRANSPARENT
        user32.SetWindowLongW(hwnd, GWL_EXSTYLE, style)

    def _text(self, state: str) -> str:
        lease = self.guard.lease
        name = f" 「{lease.label.get()}」" if lease is not None else ""
        if state == "paused":
            return f"⏸ 핸드파일럿 일시정지됨{name} "
        if state == "holding":
            if lease.turn_active:
                return f"◌ 핸드파일럿 조작권 보유{name} · 답변이 끝나면 반납"
            return f"◌ 핸드파일럿 조작권 보유{name} · {int(lease.remaining()) + 1}초 후 반납"
        return f"● 핸드파일럿 작동 중{name} · " + ("멈추려면 Esc" if self.guard.cfg.get("esc_stop", True) else "마우스를 움직이면 정지")

    def _tick(self) -> None:
        state = self.guard.state()
        try:
            text = self._text(state) if state != "idle" else ""
        except Exception:
            text = ""
        if (state, text) != self._shown:
            self._render(state, text)
            self._shown = (state, text)
        self.root.after(100, self._tick)

    def _render(self, state: str, text: str) -> None:
        if state == "paused":                    # [재개]/[종료]를 누를 수 있게
            bg = self.BG_PAUSE
            self.button.pack(side="left")
            self.end_button.pack(side="left", padx=(6, 0))
        else:                                    # 클릭은 아래 창으로 통과
            bg = self.BG_HOLD if state == "holding" else self.BG_WORK
            self.button.pack_forget()
            self.end_button.pack_forget()
        self.label.config(text=text)
        self.frame.config(bg=bg)
        self.label.config(bg=bg)
        self._place()
        alpha = {"idle": 0.0, "holding": 0.75}.get(state, 0.92)
        self.root.attributes("-alpha", alpha)
        self._own_window(click_through=state != "paused")

    def _place(self) -> None:
        root, cfg = self.root, self.guard.cfg
        root.update_idletasks()
        w, h = root.winfo_reqwidth(), root.winfo_reqheight()
        sw, sh = root.winfo_screenwidth(), root.winfo_screenheight()
        pos = cfg["overlay_position"]
        mx, my = cfg["overlay_margin_x"], cfg["overlay_margin_y"]
        x = sw - w - mx if "right" in pos else mx
        y = sh - h - my if "bottom" in pos else my
        root.geometry(f"{w}x{h}+{x}+{y}")
        self._rect = (x, y, x + w, y + h)

    def _on_resume(self) -> None:
        self.guard.resume()

    def _on_end(self) -> None:
        self.guard.end()
