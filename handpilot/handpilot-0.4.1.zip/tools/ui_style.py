"""핸드파일럿 창 공통 모양 — 관리 창(settings.pyw)·업데이트 설치 창(update_prompt.pyw).

일부러 표준 라이브러리(tkinter)만 쓴다. 업데이트 설치 창도 이 파일을 불러오기 때문(설치 중 파일 잠김 방지, D16).
ttk 'clam' 테마 위에 색·글꼴·여백을 직접 입힌다(추가 테마 라이브러리 없음, D20).
"""

import ctypes
import tkinter as tk
from pathlib import Path
from tkinter import ttk

FAMILY = "Malgun Gothic"
FONT = (FAMILY, 10)
FONT_SMALL = (FAMILY, 9)
FONT_B = (FAMILY, 10, "bold")
FONT_H2 = (FAMILY, 11, "bold")
FONT_H1 = (FAMILY, 14, "bold")
FONT_BIG = (FAMILY, 16, "bold")

BG = "#f3f5f9"          # 창 바탕
CARD = "#ffffff"        # 카드 바탕
BORDER = "#dde2ea"
BUTTON_BORDER = "#c3ccd8"  # 버튼은 카드 테두리보다 조금 진하게(흰 바탕에서도 보이게)
TEXT = "#0f172a"
MUTED = "#64748b"
SUBTLE = "#94a3b8"
ACCENT = "#2563eb"
ACCENT_HOVER = "#1d4ed8"
ACCENT_SOFT = "#dbeafe"
HOVER = "#eef2f7"

# 상태별 (글자색, 옅은 바탕색) — 키는 doctor.OK/WARN/FAIL/INFO 와 같음
TONE = {
    "ok": ("#15803d", "#dcfce7"),
    "warn": ("#b45309", "#fef3c7"),
    "fail": ("#b91c1c", "#fee2e2"),
    "info": ("#0369a1", "#e0f2fe"),
    "neutral": (MUTED, "#eef1f5"),
}


def scale(widget) -> float:
    """화면 배율(100% = 1.0). 픽셀로 그리는 것(스위치 등)에 곱한다."""
    try:
        return max(1.0, widget.winfo_fpixels("1i") / 96)
    except Exception:
        return 1.0


def fit_window(win, width: int, height: int, min_w: int, min_h: int) -> None:
    """창 크기를 화면 배율에 맞춘다(값은 배율 100% 기준). 화면보다 크면 화면에 맞춤.
    배율이 큰 PC(150%·200%)에서 글자만 커지고 창은 그대로라 아래 버튼이 잘리던 문제 방지."""
    k = scale(win)
    sw, sh = win.winfo_screenwidth(), win.winfo_screenheight()
    w, h = min(int(width * k), int(sw * 0.92)), min(int(height * k), int(sh * 0.88))
    win.geometry(f"{w}x{h}")
    win.minsize(min(int(min_w * k), w), min(int(min_h * k), h))


_IMAGES = []  # 체크 상자 그림 — tkinter 그림은 참조가 없으면 지워지므로 붙잡아 둔다


def _check_image(root, n: int, gap: int, top: int, fill: str, border: str, mark: str | None) -> tk.PhotoImage:
    """체크 상자 그림: n×n 둥근 네모(테두리·채움), 켜졌으면 ✓. 위 top·오른쪽 gap 픽셀은 투명(글자와 줄 맞춤·간격).
    clam 테마는 켜짐을 X로 그려 '안 함'처럼 보여서 직접 그린다(2026-10-14 사용자 지적)."""
    img = tk.PhotoImage(master=root, width=n + gap, height=n + top)
    r, bw = max(2, n // 6), max(1, round(n / 14))

    def inside(x, y, inset):
        lo, hi = inset, n - 1 - inset
        if not (lo <= x <= hi and lo <= y <= hi):
            return False
        rr = max(0, r - inset)
        cx, cy = min(max(x, lo + rr), hi - rr), min(max(y, lo + rr), hi - rr)
        return (x - cx) ** 2 + (y - cy) ** 2 <= rr * rr + rr

    for y in range(n):
        for x in range(n):
            if inside(x, y, bw):
                img.put(fill, (x, y + top))
            elif inside(x, y, 0):
                img.put(border, (x, y + top))
    if mark:  # ✓: 왼쪽 가운데 → 아래 → 오른쪽 위, 굵기는 크기에 비례
        t = max(2, round(n * 0.14))
        pts = [(0.24, 0.52), (0.43, 0.71), (0.77, 0.31)]
        for (ax, ay), (bx, by) in zip(pts, pts[1:]):
            steps = n * 2
            for i in range(steps + 1):
                px, py = (ax + (bx - ax) * i / steps) * n, (ay + (by - ay) * i / steps) * n
                x0, y0 = int(round(px - t / 2)), int(round(py - t / 2)) + top
                img.put(mark, to=(x0, y0, x0 + t, y0 + t))
    _IMAGES.append(img)
    return img


def _checkbutton_style(root, s: ttk.Style) -> None:
    """ttk 체크 상자의 표시를 X 대신 ✓로(설치 창 '바로 교체', 관리 창 로그 '오류·주의만' 등 모든 ttk.Checkbutton)."""
    if "HP.Checkbutton.indicator" not in s.element_names():
        k = scale(root)
        n, gap, top = int(14 * k), int(7 * k), int(2 * k)
        img = lambda fill, border, mark=None: _check_image(root, n, gap, top, fill, border, mark)  # noqa: E731
        s.element_create("HP.Checkbutton.indicator", "image", img(CARD, BUTTON_BORDER),
                         ("disabled", "selected", img("#a9c1f5", "#a9c1f5", "#ffffff")),
                         ("disabled", img(BG, "#dfe4ea")),
                         ("active", "selected", img(ACCENT_HOVER, ACCENT_HOVER, "#ffffff")),
                         ("selected", img(ACCENT, ACCENT, "#ffffff")),
                         ("active", img(CARD, ACCENT)), sticky="n")
    s.layout("TCheckbutton", [("Checkbutton.padding", {"sticky": "nswe", "children": [
        ("HP.Checkbutton.indicator", {"side": "left", "sticky": "n"}),
        ("Checkbutton.focus", {"side": "left", "sticky": "w", "children": [("Checkbutton.label", {"sticky": "nswe"})]})]})])


ICON = Path(__file__).with_name("handpilot-icon.png")  # 파란 바탕 손 모양(64px)


def _app_icon(root) -> None:
    """작업 표시줄·제목줄 아이콘을 파이썬 깃털 대신 핸드파일럿 아이콘으로, 다른 파이썬 프로그램과 따로 묶이게(2026-11-10 사용자 지적).
    작업 표시줄 묶음 이름은 창이 화면에 나오기 전에 정해야 해서 apply()(tk.Tk() 직후)에서 한다."""
    try:
        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID("Handpilot.Manager")
    except Exception:
        pass
    if ICON.exists():
        try:
            big = tk.PhotoImage(master=root, file=str(ICON))
            small = big.subsample(2)
            _IMAGES.extend((big, small))
            root.iconphoto(True, big, small)
        except tk.TclError:
            pass


def apply(root: tk.Misc) -> ttk.Style:
    """창 전체에 공통 모양을 입힌다. tk.Tk() 직후 한 번."""
    _app_icon(root)
    root.configure(background=BG)
    root.option_add("*TCombobox*Listbox.font", FONT)
    root.option_add("*TCombobox*Listbox.selectBackground", ACCENT_SOFT)
    root.option_add("*TCombobox*Listbox.selectForeground", TEXT)
    # 스크롤하다 실수로 값이 바뀌지 않게: 숫자 칸·고르기 칸의 마우스 휠 동작을 끈다
    for cls in ("TSpinbox", "TCombobox"):
        root.unbind_class(cls, "<MouseWheel>")
    s = ttk.Style(root)
    s.theme_use("clam")
    s.configure(".", font=FONT, background=BG, foreground=TEXT, bordercolor=BORDER, lightcolor=CARD,
                darkcolor=BORDER, troughcolor=BG, focuscolor=ACCENT, selectbackground=ACCENT_SOFT,
                selectforeground=TEXT, fieldbackground=CARD, insertcolor=TEXT)
    s.configure("TFrame", background=BG)
    s.configure("TLabel", background=BG, foreground=TEXT)

    # 버튼: 기본(흰 바탕 테두리) / Accent(파란 바탕) / Danger 없음 — 되돌리기 어려운 동작은 확인 창으로
    s.configure("TButton", background=CARD, foreground=TEXT, bordercolor=BUTTON_BORDER, lightcolor=CARD,
                darkcolor=CARD, padding=(12, 5), focusthickness=1, focuscolor=ACCENT)
    s.map("TButton", background=[("disabled", BG), ("pressed", "#e2e8f0"), ("active", HOVER)],
          foreground=[("disabled", SUBTLE)], bordercolor=[("focus", ACCENT)],
          lightcolor=[("pressed", "#e2e8f0"), ("active", HOVER)], darkcolor=[("pressed", "#e2e8f0"), ("active", HOVER)])
    s.configure("Accent.TButton", background=ACCENT, foreground="#ffffff", bordercolor=ACCENT, lightcolor=ACCENT,
                darkcolor=ACCENT, font=FONT_B)
    s.map("Accent.TButton", background=[("disabled", "#a9c1f5"), ("pressed", "#1e40af"), ("active", ACCENT_HOVER)],
          foreground=[("disabled", "#eef3fe")], bordercolor=[("disabled", "#a9c1f5"), ("focus", "#1e3a8a")],
          lightcolor=[("disabled", "#a9c1f5"), ("pressed", "#1e40af"), ("active", ACCENT_HOVER)],
          darkcolor=[("disabled", "#a9c1f5"), ("pressed", "#1e40af"), ("active", ACCENT_HOVER)])
    s.configure("Link.TButton", background=CARD, foreground=ACCENT, bordercolor=CARD, lightcolor=CARD, darkcolor=CARD,
                padding=(4, 2))
    s.map("Link.TButton", foreground=[("active", ACCENT_HOVER), ("disabled", SUBTLE)],
          background=[("active", CARD)], bordercolor=[("focus", ACCENT)])

    # 입력 칸
    for name in ("TSpinbox", "TCombobox", "TEntry"):
        s.configure(name, fieldbackground=CARD, background=CARD, bordercolor=BORDER, lightcolor=CARD,
                    darkcolor=CARD, arrowcolor=MUTED, padding=(6, 3), arrowsize=13)
        s.map(name, bordercolor=[("focus", ACCENT), ("hover", "#b8c2d1")], lightcolor=[("focus", ACCENT)],
              fieldbackground=[("readonly", CARD), ("disabled", BG)], foreground=[("disabled", SUBTLE)],
              arrowcolor=[("disabled", SUBTLE)])
    s.map("TCombobox", selectbackground=[("readonly", CARD)], selectforeground=[("readonly", TEXT)])

    s.configure("TCheckbutton", background=BG, foreground=TEXT, indicatorbackground=CARD, indicatorforeground=ACCENT,
                upperbordercolor=BUTTON_BORDER, lowerbordercolor=BUTTON_BORDER, focuscolor=ACCENT,
                indicatorsize=int(14 * scale(root)), indicatormargin=(0, 0, 6, 0))
    s.map("TCheckbutton", background=[("active", BG)], indicatorbackground=[("pressed", ACCENT_SOFT)])
    s.configure("Card.TCheckbutton", background=CARD)
    s.map("Card.TCheckbutton", background=[("active", CARD)])
    _checkbutton_style(root, s)

    # 표(점검 목록·로그)
    s.configure("Treeview", background=CARD, fieldbackground=CARD, foreground=TEXT, bordercolor=BORDER,
                lightcolor=BORDER, darkcolor=BORDER, rowheight=int(30 * scale(root)), font=FONT)
    s.map("Treeview", background=[("selected", ACCENT_SOFT)], foreground=[("selected", TEXT)])
    s.configure("Treeview.Heading", background="#f8fafc", foreground=MUTED, bordercolor=BORDER, lightcolor="#f8fafc",
                darkcolor=BORDER, relief="flat", font=FONT_B, padding=(6, 5))
    s.map("Treeview.Heading", background=[("active", HOVER)])
    s.configure("Flat.Treeview", bordercolor=CARD, lightcolor=CARD, darkcolor=CARD)  # 카드 안에 넣을 때(테두리 겹침 방지)

    s.configure("Vertical.TScrollbar", background="#cfd6e0", troughcolor=BG, bordercolor=BG, lightcolor="#cfd6e0",
                darkcolor="#cfd6e0", arrowcolor=MUTED, gripcount=0, arrowsize=12)
    s.map("Vertical.TScrollbar", background=[("active", "#b3bdcb")])
    return s


# ---------------------------------------------------------------- 작은 부품


def card(parent, padding: int = 16, **kw) -> tk.Frame:
    """흰 카드(옅은 테두리)."""
    return tk.Frame(parent, background=CARD, highlightthickness=1, highlightbackground=BORDER,
                    highlightcolor=BORDER, padx=padding, pady=padding, **kw)


def label(parent, text: str = "", *, font=FONT, fg: str = TEXT, **kw) -> tk.Label:
    """부모 바탕색을 그대로 쓰는 글자."""
    return tk.Label(parent, text=text, font=font, foreground=fg, background=parent.cget("background"),
                    anchor="w", justify="left", **kw)


def muted(parent, text: str = "", **kw) -> tk.Label:
    kw.setdefault("font", FONT_SMALL)
    return label(parent, text, fg=MUTED, **kw)


def pill(parent, text: str = "", tone: str = "neutral", **kw) -> tk.Label:
    """상태 꼬리표(둥근 모서리 대신 옅은 바탕 + 진한 글자)."""
    fg, bg = TONE[tone]
    return tk.Label(parent, text=text, font=(FAMILY, 9, "bold"), foreground=fg, background=bg, padx=8, pady=2, **kw)


def set_pill(w: tk.Label, text: str, tone: str):
    fg, bg = TONE[tone]
    w.config(text=text, foreground=fg, background=bg)


class Switch(tk.Canvas):
    """켜짐/꺼짐 스위치. BooleanVar와 묶이고 클릭·Space로 바뀐다.

    before(새 값) 가 False를 돌려주면 바뀌지 않는다(확인 창을 띄울 때). command 는 바뀐 뒤 불린다.
    """

    def __init__(self, parent, variable: tk.BooleanVar | None = None, command=None, before=None):
        k = scale(parent)
        self._sw, self._sh, self._sm = int(40 * k), int(22 * k), max(2, int(3 * k))
        super().__init__(parent, width=self._sw + 4, height=self._sh + 4, background=parent.cget("background"),
                         highlightthickness=0, borderwidth=0, takefocus=1, cursor="hand2")
        self.var = variable if variable is not None else tk.BooleanVar(value=False)
        self.command, self.before = command, before
        self.enabled = True
        self.bind("<Button-1>", self.toggle)
        self.bind("<space>", self.toggle)
        self.bind("<FocusIn>", lambda e: self._draw())
        self.bind("<FocusOut>", lambda e: self._draw())
        self.var.trace_add("write", lambda *a: self._draw())
        self._draw()

    def _draw(self):
        self.delete("all")
        on = bool(self.var.get())
        w, h, m, x, y = self._sw, self._sh, self._sm, 2, 2
        if self.enabled:
            fill = ACCENT if on else "#c3cbd6"
        else:
            fill = "#a9c1f5" if on else "#dfe4ea"
        r = h / 2
        self.create_oval(x, y, x + h, y + h, fill=fill, outline=fill)
        self.create_oval(x + w - h, y, x + w, y + h, fill=fill, outline=fill)
        self.create_rectangle(x + r, y, x + w - r, y + h, fill=fill, outline=fill)
        kx = x + w - h + m if on else x + m
        self.create_oval(kx, y + m, kx + h - 2 * m, y + h - m, fill="#ffffff", outline="#ffffff")
        try:
            focused = self.focus_get() is self
        except (KeyError, tk.TclError):
            focused = False
        if focused:
            self.create_rectangle(0, 0, w + 3, h + 3, outline=ACCENT, dash=(2, 2))

    def toggle(self, _=None):
        if not self.enabled:
            return
        self.focus_set()
        new = not bool(self.var.get())
        if self.before is not None and self.before(new) is False:
            return
        self.var.set(new)
        if self.command:
            self.command()

    def set_enabled(self, on: bool):
        self.enabled = on
        self.configure(cursor="hand2" if on else "arrow", takefocus=1 if on else 0)
        self._draw()


class ScrollFrame(tk.Frame):
    """세로 스크롤 영역. 내용은 .body 에 넣는다. 마우스가 이 영역 위에 있을 때만 휠로 스크롤된다."""

    def __init__(self, parent, background: str = BG):
        super().__init__(parent, background=background)
        self.canvas = tk.Canvas(self, background=background, highlightthickness=0, borderwidth=0,
                                yscrollincrement=int(20 * scale(parent)))
        self.sb = ttk.Scrollbar(self, orient="vertical", command=self.canvas.yview)
        self.body = tk.Frame(self.canvas, background=background)
        self._win = self.canvas.create_window(0, 0, window=self.body, anchor="nw")
        self.canvas.configure(yscrollcommand=self.sb.set)
        self.canvas.pack(side="left", fill="both", expand=True)
        self.body.bind("<Configure>", self._update)
        self.canvas.bind("<Configure>", self._update)
        self.bind_all("<MouseWheel>", self._wheel, add="+")

    def _update(self, _=None):
        self.canvas.itemconfigure(self._win, width=self.canvas.winfo_width())
        self.canvas.configure(scrollregion=(0, 0, self.body.winfo_reqwidth(), self.body.winfo_reqheight()))
        need = self.body.winfo_reqheight() > self.canvas.winfo_height() + 1
        shown = bool(self.sb.winfo_manager())  # 탭이 숨어 있으면 ismapped는 늘 False라 manager로 본다
        if need and not shown:
            self.sb.pack(side="right", fill="y", before=self.canvas)
        elif not need and shown:
            self.sb.pack_forget()
            self.canvas.yview_moveto(0)

    def _wheel(self, e):
        try:
            w = self.winfo_containing(e.x_root, e.y_root)
        except (KeyError, tk.TclError):  # 펼친 고르기 목록 등 tkinter가 모르는 창
            return
        while w is not None and w is not self:
            w = w.master
        if w is self and self.sb.winfo_ismapped():
            self.canvas.yview_scroll(int(-e.delta / 120) * 3, "units")


def autohide_scrollbar(parent: tk.Widget, widget) -> ttk.Scrollbar:
    """widget(표·글 상자)을 parent 안에 grid로 놓고, 내용이 넘칠 때만 오른쪽 스크롤바를 보인다.
    parent 에는 다른 것을 pack 하지 말 것(grid 전용)."""
    sb = ttk.Scrollbar(parent, orient="vertical", command=widget.yview)

    def setter(lo, hi):
        if float(lo) <= 0.0 and float(hi) >= 1.0:
            sb.grid_remove()
        else:
            sb.grid()
        sb.set(lo, hi)
    widget.configure(yscrollcommand=setter)
    parent.rowconfigure(0, weight=1)
    parent.columnconfigure(0, weight=1)
    widget.grid(row=0, column=0, sticky="nsew")
    sb.grid(row=0, column=1, sticky="ns")
    return sb
